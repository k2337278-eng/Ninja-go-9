class_name CutsceneDefsF
extends RefCounted
## v8 scenes (chapters 6-8 after the STORY_SPEC v2 review, plus the new supporting characters). Original wording.
## VERIFY items are marked in the subtitles and in docs/CUTSCENE_HOOKS.md.

const D = CutsceneDefs

static func build() -> Dictionary:
	var out := {}
	var cfg_chen := {"suit": Color(0.45, 0.15, 0.5), "style": "bare", "hair": Color(0.1, 0.1, 0.1), "scale": 1.25}
	var cfg_eye := {"suit": CharacterDB.DATA["eyezor"]["suit"], "style": "ninja", "scale": 1.25}
	var cfg_kap := {"suit": CharacterDB.DATA["kapau"]["suit"], "style": "ninja", "scale": 1.2}
	var cfg_cho := {"suit": CharacterDB.DATA["chope"]["suit"], "style": "bare", "hair": Color(0.15, 0.1, 0.05), "scale": 1.3}
	var cfg_sky := {"suit": CharacterDB.DATA["skylor"]["suit"], "style": "ninja", "weapon": "fan"}
	var cfg_guard := {"suit": Color(0.25, 0.25, 0.3), "style": "bare", "hair": Color(0.1, 0.1, 0.1)}
	var cfg_ana := {"suit": Color(0.3, 0.12, 0.4), "style": "ninja", "hat": Color(0.15, 0.4, 0.15)}
	var cfg_arc := {"suit": Color(0.2, 0.45, 0.3), "style": "ninja", "scale": 1.5, "hat": Color(0.1, 0.3, 0.1)}
	var cfg_garm := {"suit": Color(0.15, 0.1, 0.15), "style": "bare", "hair": Color(0.1, 0.05, 0.05), "scale": 1.3}

	out["ch06_chen_chases_nya"] = {"mood": "gloom", "music": "tense", "cast": [
		D.ch("kai", "kai", Vector3(24, 0.2, 10), Vector3(36, 0.2, -8)), D.fig("sky", cfg_sky, Vector3(27, 0.2, 11), Vector3(36, 0.2, -8)),
		D.fig("eye", cfg_eye, Vector3(36, 0.2, -6), Vector3(26, 0.2, 10)), D.fig("kap", cfg_kap, Vector3(39, 0.2, -10), Vector3(26, 0.2, 10)),
		D.fig("cho", cfg_cho, Vector3(34, 0.2, -12), Vector3(26, 0.2, 10))], "shots": [
		D.sh(Vector3(30, 9, 22), Vector3(30, 1.5, 0), 6.0, "crane", 58, {"t": Vector3(30, 5, 16), "fx": "fade_in", "say": [
			D.Q("narrator", "Chen lures the contestants into hunting Nya, who carries proof of his plan.", "يغري تشِن المتسابقين بمطاردة نيا، التي تحمل دليلًا على خطته.")]}),
		D.sh(Vector3(33, 1.8, -2), Vector3(36, 1.6, -8), 5.0, "hand", 42, {"act": [D.walk("eye", Vector3(32, 0.2, -2), 4.0), D.walk("kap", Vector3(35, 0.2, -4), 4.0), D.walk("cho", Vector3(31, 0.2, -6), 4.0)], "say": [
			D.Q("eyezor", "The winners of this hunt skip a round. Do not disappoint the master.", "فائزو هذه المطاردة يتخطّون جولة. لا تخذلوا السيد.")]}),
		D.sh(Vector3(21, 1.6, 8), Vector3(24, 1.5, 10), 4.5, "static", 45, {"say": [
			D.Q("kai", "A prize for catching a friend. Chen really does like his games.", "جائزة لمن يمسك صديقة. تشِن يحب ألعابه فعلًا.")]}),
		D.sh(Vector3(27, 1.6, 14), Vector3(27, 1.5, 11), 4.5, "dolly", 42, {"t": Vector3(27, 1.6, 12.5), "say": [
			D.Q("skylor", "Then we find her first. I know where she would hide.", "إذن نجدها قبلهم. أعرف أين قد تختبئ.")]})]}

	out["ch06_kai_skylor_search"] = {"mood": "dawn", "music": "mystery", "cast": [
		D.ch("kai", "kai", Vector3(24, 0.2, 18), Vector3(26, 0.2, 6)), D.fig("sky", cfg_sky, Vector3(27, 0.2, 18), Vector3(26, 0.2, 6))], "shots": [
		D.sh(Vector3(20, 5, 24), Vector3(26, 1.5, 14), 5.0, "crane", 55, {"t": Vector3(20, 3, 20), "fx": "fade_in", "say": [
			D.Q("narrator", "Kai and Skylor slip into the woods together, with the same goal and different loyalties.", "يتسلّل كاي وسكايلور إلى الغابة معًا، بالهدف نفسه وبولاءين مختلفين.")]}),
		D.sh(Vector3(24, 1.6, 22), Vector3(26, 1.5, 12), 5.5, "hand", 42, {"act": [D.walk("kai", Vector3(24, 0.2, 8), 5.0), D.walk("sky", Vector3(27, 0.2, 8), 5.0)], "say": [
			D.Q("skylor", "Keep to the roots. The hunters walk on the open ground.", "ابقَ قرب الجذور. الصيادون يمشون في العراء.")]}),
		D.sh(Vector3(30, 2.0, 6), Vector3(26, 1.5, 8), 4.5, "static", 45, {"say": [
			D.Q("kai", "Why are you helping me, really?", "لماذا تساعدينني، حقًّا؟")]}),
		D.sh(Vector3(26, 1.8, 4), Vector3(27, 1.6, 8), 4.5, "dolly", 40, {"t": Vector3(26.5, 1.8, 5.4), "say": [
			D.Q("skylor", "Because some things matter more than who my father is.", "لأن هناك أشياء أهم من هوية أبي.")]})]}

	out["ch06_db_express_seized"] = {"mood": "dusk", "music": "action", "cast": [
		D.ch("kai", "kai", Vector3(40, 0.2, -14), Vector3(32, 0.2, -22)), D.fig("sky", cfg_sky, Vector3(42, 0.2, -13), Vector3(32, 0.2, -22)),
		D.fig("eye", cfg_eye, Vector3(32, 0.2, -26), Vector3(40, 0.2, -14)), D.fig("g1", cfg_guard, Vector3(29, 0.2, -22), Vector3(40, 0.2, -14)),
		D.fig("g2", cfg_guard, Vector3(35, 0.2, -22), Vector3(40, 0.2, -14)),
		D.glow([Vector3(32, 0.8, -21), Vector3(32, 0.8, -22), Vector3(32, 0.8, -23)], 0.7, Color(0.9, 0.5, 0.2))], "shots": [
		D.sh(Vector3(44, 4, -8), Vector3(32, 1.0, -22), 5.0, "dolly", 55, {"t": Vector3(42, 3, -12), "fx": "fade_in", "say": [
			D.Q("narrator", "Chen's men have the D.B. Express surrounded.", "رجال تشِن يحاصرون دي بي إكسبرس.")]}),
		D.sh(Vector3(36, 1.8, -17), Vector3(32, 1.6, -26), 5.0, "hand", 42, {"say": [
			D.Q("eyezor", "Orders are orders. The vehicle belongs to the master now.", "الأوامر أوامر. المركبة ملك السيد الآن.")]}),
		D.sh(Vector3(40, 1.6, -11), Vector3(40, 1.5, -14), 4.0, "static", 42, {"say": [
			D.Q("kai", "We are too late.", "تأخرنا.")]}),
		D.sh(Vector3(26, 5, -14), Vector3(32, 1.0, -22), 4.0, "crane", 58, {"t": Vector3(24, 8, -10), "fx": "shake"})]}

	out["ch06_arcturus_flashback"] = {"mood": "dusk", "music": "action", "cast": [
		D.fig("arc", cfg_arc, Vector3(30, 0.2, -22), Vector3(30, 0.2, -10)), D.fig("a1", cfg_ana, Vector3(26, 0.2, -20), Vector3(30, 0.2, -10)),
		D.fig("a2", cfg_ana, Vector3(34, 0.2, -20), Vector3(30, 0.2, -10)), D.fig("a3", cfg_ana, Vector3(28, 0.2, -26), Vector3(30, 0.2, -10)),
		D.fig("a4", cfg_ana, Vector3(32, 0.2, -26), Vector3(30, 0.2, -10)), D.fig("gm", cfg_garm, Vector3(30, 0.2, -8), Vector3(30, 0.2, -22)),
		D.fig("ch", cfg_chen, Vector3(26, 0.2, -8), Vector3(30, 0.2, -22))], "shots": [
		D.sh(Vector3(30, 10, -2), Vector3(30, 1.5, -20), 6.0, "crane", 60, {"t": Vector3(30, 5, -6), "fx": "fade_in", "say": [
			D.Q("narrator", "Long ago, in the war of the Anacondrai, one general stood above the rest.", "منذ زمن بعيد، في حرب الأناكوندراي، علا جنرال واحد فوق الجميع.")]}),
		D.sh(Vector3(30, 1.4, -17), Vector3(30, 2.4, -22), 5.0, "dolly", 55, {"t": Vector3(30, 1.4, -19.5), "say": [
			D.Q("arcturus", "Hold your ground. Nothing here is ours unless we take it.", "اثبتوا في مكانكم. لا شيء هنا لنا ما لم نأخذه.")]}),
		D.sh(Vector3(24, 2.2, -6), Vector3(28, 1.6, -8), 4.5, "hand", 42, {"say": [
			D.Q("narrator", "On the other side stood young Garmadon and Chen. (VERIFY: look and details.)", "وعلى الجهة المقابلة وقف غارمادون وتشِن شابّين. (VERIFY: الشكل والتفاصيل.)")]}),
		D.sh(Vector3(30, 12, -14), Vector3(30, 1.5, -16), 4.0, "orbit", 62, {"arc": 70.0, "fx": "fade_out"})]}

	out["ch06_skylor_reveal"] = {"mood": "gloom", "music": "sad", "cast": [
		D.fig("sky", cfg_sky, Vector3(26, 0.2, -18), Vector3(24, 0.2, -14)), D.ch("kai", "kai", Vector3(24, 0.2, -14), Vector3(26, 0.2, -18))], "shots": [
		D.sh(Vector3(21, 1.8, -20), Vector3(26, 1.6, -18), 5.0, "dolly", 44, {"t": Vector3(22, 1.7, -19.5), "fx": "fade_in", "say": [
			D.Q("narrator", "Skylor stops, as if she has carried this for a long time.", "تتوقف سكايلور، كأنها تحمل هذا منذ زمن طويل.")]}),
		D.sh(Vector3(28, 1.6, -16), Vector3(26, 1.6, -18), 5.0, "hand", 40, {"say": [
			D.Q("skylor", "Chen is not just the master of this tournament. He is my father.", "تشِن ليس مجرد سيد هذه البطولة. إنه أبي.")]}),
		D.sh(Vector3(22, 1.6, -12), Vector3(24, 1.6, -14), 5.0, "static", 42, {"act": [D.anim("kai", "stagger", 0.8)], "say": [
			D.Q("kai", "You let me trust you while you hid it. I need to be alone.", "تركتِني أثق بكِ وأنتِ تخفين هذا. أحتاج أن أكون وحدي.")]}),
		D.sh(Vector3(26, 7, -8), Vector3(24, 1.4, -16), 4.0, "crane", 55, {"t": Vector3(26, 10, -6), "act": [D.walk("sky", Vector3(32, 0.2, -18), 3.5)]})]}

	out["ch07_chen_needs_lloyd"] = {"mood": "dusk", "music": "tense", "cast": [
		D.ch("lloyd", "lloyd", Vector3(-3, 0.2, 2), Vector3(0, 8, -42)), D.ch("jay", "jay", Vector3(2, 0.2, 3), Vector3(0, 8, -42))], "shots": [
		D.sh(Vector3(0, 3, 10), Vector3(0, 8, -20), 5.5, "crane", 58, {"t": Vector3(0, 8, -4), "fx": "fade_in", "say": [
			D.Q("narrator", "Chen has taken what he needs from the others. One power is left.", "أخذ تشِن ما يحتاجه من الآخرين. بقيت قوة واحدة.")]}),
		D.sh(Vector3(0, 11, -36), Vector3(0, 11.2, -42.5), 5.5, "dolly", 45, {"t": Vector3(0, 11, -38), "say": [
			D.Q("chen", "Not the elements, not the tournament. Just the green ninja.", "لا العناصر ولا البطولة. فقط النينجا الأخضر.")]}),
		D.sh(Vector3(-2, 1.6, 6), Vector3(-3, 1.5, 2), 5.0, "hand", 40, {"say": [
			D.Q("lloyd", "I figured. Everyone wants that power in the end.", "توقّعت ذلك. في النهاية الكل يريد تلك القوة.")]})]}

	out["ch07_chen_secret"] = {"mood": "gloom", "music": "mystery", "cast": [
		D.ch("kai", "kai", Vector3(-2, 0.2, -38), Vector3(2, 0.2, -38)), D.fig("sky", cfg_sky, Vector3(2, 0.2, -38), Vector3(-2, 0.2, -38))], "shots": [
		D.sh(Vector3(6, 3, -30), Vector3(0, 1.5, -38), 5.5, "dolly", 52, {"t": Vector3(5, 2.4, -33), "fx": "fade_in", "say": [
			D.Q("narrator", "Skylor finds Kai alone and brings a message from her father.", "تجد سكايلور كاي وحيدًا وتحمل إليه رسالة من أبيها.")]}),
		D.sh(Vector3(-1, 1.6, -35.5), Vector3(2, 1.7, -38), 5.0, "hand", 38, {"say": [
			D.Q("skylor", "He says he knows what happened to your parents. He will tell you.", "يقول إنه يعرف ما حدث لوالديك. وسيخبرك.")]}),
		D.sh(Vector3(3, 1.6, -35.5), Vector3(-2, 1.5, -38), 5.5, "hand", 38, {"say": [
			D.Q("kai", "What does it cost?", "وما الثمن؟"),
			D.Q("narrator", "(VERIFY: the secrets are not stated in the spec.)", "(VERIFY: الأسرار غير مذكورة في المواصفات.)")]})]}

	out["ch07_final_match"] = {"mood": "night", "music": "action", "cast": [
		D.ch("lloyd", "lloyd", Vector3(-4, 0.2, -2), Vector3(4, 0.2, -2)), D.fig("chen", cfg_chen, Vector3(4, 0.2, -2), Vector3(-4, 0.2, -2)),
		D.glow([Vector3(5, 3.2, -2)], 0.5, Color(1.0, 0.85, 0.3)), D.ch("jay", "jay", Vector3(14, 0.2, 4), Vector3(0, 0.2, -2))], "shots": [
		D.sh(Vector3(0, 3, 10), Vector3(0, 8, -20), 5.5, "crane", 60, {"t": Vector3(0, 9, -6), "fx": "fade_in", "say": [
			D.Q("narrator", "The Staff of Elements glows in Chen's hand. Every stolen power answers it.", "تتوهج عصا العناصر في يد تشِن. وكل قوة مسروقة تستجيب لها.")]}),
		D.sh(Vector3(-9, 1.6, -5), Vector3(4, 1.5, -2), 5.0, "orbit", 50, {"arc": 60.0, "fx": "flash", "say": [
			D.Q("chen", "Fire, ice, lightning. Which will you face first?", "نار وجليد وبرق. أيها تواجه أولًا؟")]}),
		D.sh(Vector3(-4, 1.5, 0), Vector3(-4, 1.5, -2), 4.0, "hand", 38, {"say": [
			D.Q("lloyd", "All of them, if that is what it takes.", "كلها، إن كان هذا ما يلزم.")]}),
		D.sh(Vector3(14, 1.6, 6), Vector3(14, 1.5, 3), 3.5, "static", 45, {"fx": "shake"})]}

	out["ch07_masters_control"] = {"mood": "dawn", "music": "hope", "cast": [
		D.ch("kai", "kai", Vector3(0, 0.2, 2), Vector3(0, 0.2, 14)), D.ch("jay", "jay", Vector3(-3, 0.2, 4), Vector3(0, 0.2, 14)),
		D.ch("cole", "cole", Vector3(3, 0.2, 4), Vector3(0, 0.2, 14)), D.fig("sky", cfg_sky, Vector3(0, 0.2, 6), Vector3(0, 0.2, 14)),
		D.fig("g1", cfg_guard, Vector3(-6, 0.2, 14), Vector3(0, 0.2, 40)), D.fig("g2", cfg_guard, Vector3(6, 0.2, 14), Vector3(0, 0.2, 40))], "shots": [
		D.sh(Vector3(0, 10, 24), Vector3(0, 1, 6), 6.0, "crane", 58, {"t": Vector3(0, 5, 18), "fx": "fade_in", "say": [
			D.Q("narrator", "With their powers back, the Masters take the island.", "وقد عادت قواهم، يسيطر الماسترز على الجزيرة.")]}),
		D.sh(Vector3(-4, 1.8, 10), Vector3(0, 1.5, 14), 5.5, "hand", 42, {"act": [D.walk("g1", Vector3(-4, 0.2, 30), 4.5), D.walk("g2", Vector3(4, 0.2, 30), 4.5)], "say": [
			D.Q("cole", "Chen's followers are marching to the cells. Doors this time are on our side.", "أتباع تشِن يُساقون إلى الزنازين. والأبواب هذه المرة في صفّنا.")]}),
		D.sh(Vector3(3, 1.6, 0), Vector3(0, 1.6, 4), 5.0, "static", 42, {"say": [
			D.Q("jay", "Does this mean I get a trophy?", "هل يعني هذا أنني أحصل على كأس؟")]})]}

	out["ch08_chen_discovers"] = {"mood": "gloom", "music": "tense", "cast": [
		D.fig("chen", cfg_chen, Vector3(-48, 0.2, -8), Vector3(-52, 0.2, -12)), D.fig("sky", cfg_sky, Vector3(-52, 0.2, -12), Vector3(-48, 0.2, -8)),
		D.glow([Vector3(-56, 1.5, -8), Vector3(-56, 2.6, -12), Vector3(-56, 1.5, -16), Vector3(-44, 2.0, -16)], 0.5, Color(0.7, 0.3, 1.0))], "shots": [
		D.sh(Vector3(-44, 4, -6), Vector3(-52, 1.4, -12), 5.5, "crane", 55, {"t": Vector3(-46, 2.6, -8), "fx": "fade_in", "say": [
			D.Q("narrator", "In the crystal chamber Chen studies his daughter, and sees a missing piece.", "في غرفة البلّور يتأمل تشِن ابنته، فيرى قطعة ناقصة.")]}),
		D.sh(Vector3(-46, 1.7, -10), Vector3(-48, 1.7, -8), 4.5, "hand", 40, {"say": [
			D.Q("chen", "Your power was always the last ingredient.", "قوتك كانت دائمًا العنصر الأخير.")]}),
		D.sh(Vector3(-50, 1.6, -10), Vector3(-52, 1.6, -12), 4.5, "hand", 38, {"say": [
			D.Q("skylor", "Then I was never your daughter. Only your tool.", "إذن لم أكن ابنتك يومًا. فقط أداتك.")]}),
		D.sh(Vector3(-40, 6, -4), Vector3(-52, 1.5, -12), 4.0, "crane", 55, {"t": Vector3(-40, 9, -2)})]}

	out["ch08_skylor_sos"] = {"mood": "night", "music": "tense", "cast": [
		D.fig("sky", cfg_sky, Vector3(-30, 0.2, 2), Vector3(-30, 8, 2)),
		D.glow([Vector3(-30, 1.5, 2), Vector3(-30, 3.0, 2), Vector3(-30, 4.5, 2), Vector3(-30, 6.0, 2), Vector3(-30, 8.0, 2), Vector3(-30, 10.0, 2)], 0.6, Color(1.0, 0.8, 0.2), 0.5)], "shots": [
		D.sh(Vector3(-24, 1.8, 6), Vector3(-30, 1.6, 2), 5.5, "hand", 42, {"fx": "fade_in", "say": [
			D.Q("skylor", "If anyone can hear this, please come. He is going to finish the spell.", "إن كان أحد يسمع هذا، أرجوكم تعالوا. سيُكمل التعويذة.")]}),
		D.sh(Vector3(-30, 1.0, 8), Vector3(-30, 10, 2), 6.0, "crane", 70, {"t": Vector3(-30, 3, 7), "fx": "flash", "say": [
			D.Q("narrator", "A beam of light rises from the cave: an SOS for the ninja.", "شعاع ضوء يرتفع من الكهف: نداء استغاثة للنينجا.")]}),
		D.sh(Vector3(-20, 12, 14), Vector3(-30, 4, 2), 5.0, "orbit", 60, {"arc": 70.0, "fx": "fade_out"})]}

	out["ch08_rescue_convoy"] = {"mood": "dusk", "music": "action", "cast": [
		D.ch("lloyd", "lloyd", Vector3(0, 0.2, 40), Vector3(-30, 0, 6)), D.ch("jay", "jay", Vector3(2, 0.2, 41), Vector3(-30, 0, 6)),
		D.ch("cole", "cole", Vector3(-2, 0.2, 41), Vector3(-30, 0, 6)),
		D.glow([Vector3(-6, 0.7, 42), Vector3(-6, 0.7, 43), Vector3(-6, 0.7, 44), Vector3(6, 0.7, 42), Vector3(6, 0.7, 43)], 0.6, Color(0.5, 0.8, 1.0))], "shots": [
		D.sh(Vector3(0, 8, 56), Vector3(0, 1, 40), 5.5, "crane", 58, {"t": Vector3(0, 4, 48), "fx": "fade_in", "say": [
			D.Q("narrator", "Everyone who can answer the SOS sets out together. (VERIFY: vehicles.)", "كل من يستطيع تلبية النداء ينطلق معًا. (VERIFY: المركبات.)")]}),
		D.sh(Vector3(0, 1.8, 46), Vector3(0, 1.5, 38), 5.5, "hand", 55, {"act": [
			D.walk("lloyd", Vector3(-8, 0.2, 24), 5.0), D.walk("jay", Vector3(-6, 0.2, 26), 5.0), D.walk("cole", Vector3(-10, 0.2, 26), 5.0)], "say": [
			D.Q("lloyd", "Faster! Whatever he has planned, it starts when we are late.", "أسرع! مهما خطط، فهو يبدأ حين نتأخر.")]}),
		D.sh(Vector3(-20, 2, 14), Vector3(-10, 1.5, 24), 5.0, "dolly", 60, {"t": Vector3(-22, 2, 10)})]}

	out["ch08_spell_begins"] = {"mood": "dusk", "music": "tense", "cast": [
		D.fig("kap", cfg_kap, Vector3(0, 0.2, -20), Vector3(0, 0.2, 0)),
		D.glow(D.chain(Vector3(0, 0, -20), 4.0, 14, 2.5), 0.4, Color(0.8, 0.3, 1.0), 0.5)], "shots": [
		D.sh(Vector3(-6, 12, -26), Vector3(0, 10.5, -42), 5.5, "dolly", 52, {"t": Vector3(-4, 11, -30), "fx": "fade_in", "say": [
			D.Q("narrator", "Kapau raises the old words and the crystals begin to hum.", "يرفع كاباو الكلمات القديمة وتبدأ البلّورات بالطنين.")]}),
		D.sh(Vector3(8, 2.4, -6), Vector3(0, 2, -20), 5.5, "orbit", 55, {"arc": 90.0, "fx": "shake", "say": [
			D.Q("kapau", "Once it starts, nothing stops it.", "ما إن تبدأ، لا شيء يوقفها.")]}),
		D.sh(Vector3(0, 1.6, 8), Vector3(0, 2, -14), 5.0, "dolly", 50, {"t": Vector3(0, 1.6, 4)})]}

	out["ch08_transformation"] = {"mood": "night", "music": "action", "cast": [
		D.fig("cho", cfg_cho, Vector3(0, 0.2, -20), Vector3(0, 0.2, 0)), D.fig("f1", cfg_guard, Vector3(-6, 0.2, -12), Vector3(0, 0.2, 0)),
		D.fig("f2", cfg_guard, Vector3(0, 0.2, -14), Vector3(0, 0.2, 0)), D.fig("f3", cfg_guard, Vector3(6, 0.2, -12), Vector3(0, 0.2, 0)),
		D.glow(D.chain(Vector3(0, 0, -16), 5.0, 18, 3.0), 0.9, Color(0.7, 0.2, 0.9), 0.4)], "shots": [
		D.sh(Vector3(0, 14, 10), Vector3(0, 6, -16), 5.5, "crane", 62, {"t": Vector3(0, 6, 2), "fx": "flash", "say": [
			D.Q("narrator", "Chope speaks the last word of the spell.", "ينطق تشوب الكلمة الأخيرة من التعويذة.")]}),
		D.sh(Vector3(10, 3, -6), Vector3(0, 2, -13), 5.5, "orbit", 60, {"arc": -80.0, "fx": "shake", "act": [D.anim("f1", "stagger", 1.0), D.anim("f2", "stagger", 1.0), D.anim("f3", "stagger", 1.0)], "say": [
			D.Q("narrator", "Chen's followers shudder, and one by one become Anacondrai. (VERIFY: look.)", "يرتجف أتباع تشِن، ويتحولون واحدًا تلو الآخر إلى أناكوندراي. (VERIFY: الشكل.)")]}),
		D.sh(Vector3(0, 1.4, 6), Vector3(0, 4, -14), 5.0, "dolly", 70, {"t": Vector3(0, 1.4, 2), "say": [
			D.Q("chope", "Now the army is complete.", "والآن اكتمل الجيش.")]})]}

	out["ch08_zane_dragon"] = {"mood": "gloom", "music": "hope", "cast": [
		D.ch("zane", "zane", Vector3(48, 0.2, -2), Vector3(48, 6, -10)), D.glow(D.chain(Vector3(48, 0, -2), 6.0, 18, 4.5), 0.85, Color(0.8, 0.85, 0.95), 0.6)], "shots": [
		D.sh(Vector3(43, 1.6, 2), Vector3(48, 1.6, -2), 4.5, "hand", 42, {"fx": "fade_in", "say": [
			D.Q("pixal", "Breathe, Zane. Two voices argue in you. Let them both speak.", "تنفّس يا زين. صوتان يتجادلان فيك. دعهما يتكلمان معًا.")]}),
		D.sh(Vector3(48, 15, 10), Vector3(48, 4, -2), 6.0, "orbit", 62, {"arc": 100.0, "fx": "flash", "say": [
			D.Q("narrator", "A dragon of titanium uncoils above the temple, bright as a mirror.", "ينفلت تنين من التيتانيوم فوق المعبد، لامعًا كمرآة.")]}),
		D.sh(Vector3(48, 1.5, 0), Vector3(48, 7, -4), 4.5, "crane", 72, {"t": Vector3(48, 3, 1)}),
		D.sh(Vector3(54, 2, 4), Vector3(48, 1.6, -2), 3.5, "static", 48, {"say": [
			D.Q("zane", "Thank you, P.I.X.A.L. I could not have done it alone.", "شكرًا يا بيكسال. ما كنت لأفعلها وحدي.")]})]}

	out["ch08_dragons_escape"] = {"mood": "dusk", "music": "hope", "cast": [
		D.glow(D.chain(Vector3(0, 0, 8), 8.0, 16, 8.0), 0.8, Color(1.0, 0.45, 0.1), 0.6),
		D.glow(D.chain(Vector3(-4, 0, 14), 7.0, 14, 11.0), 0.7, Color(0.8, 0.85, 0.95), 0.6),
		D.glow(D.chain(Vector3(4, 0, 18), 7.0, 14, 14.0), 0.7, Color(0.4, 1.0, 0.5), 0.6)], "shots": [
		D.sh(Vector3(0, 22, 40), Vector3(0, 8, 10), 6.0, "crane", 65, {"t": Vector3(0, 12, 30), "fx": "fade_in", "say": [
			D.Q("narrator", "One by one the Masters open their dragons and rise over the island.", "واحدًا تلو الآخر يفتح الماسترز تنانينهم ويرتفعون فوق الجزيرة.")]}),
		D.sh(Vector3(20, 14, 20), Vector3(0, 10, 12), 5.5, "orbit", 62, {"arc": 100.0, "say": [
			D.Q("narrator", "Behind them, Chen's new army pours out of the caves.", "وخلفهم، يتدفق جيش تشِن الجديد من الكهوف.")]}),
		D.sh(Vector3(0, 6, 50), Vector3(0, 10, 0), 5.0, "dolly", 60, {"t": Vector3(0, 10, 60), "fx": "fade_out"})]}
	return out
