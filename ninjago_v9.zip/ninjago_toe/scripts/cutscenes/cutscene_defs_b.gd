class_name CutsceneDefsB
extends RefCounted
## Scenes for chapter 3 (Versus). Original wording. Digiverse look = VERIFY (neon-teal placeholder).

const D = CutsceneDefs

static func build() -> Dictionary:
	var out := {}
	var cfg_ash := {"suit": Color(0.55, 0.2, 0.15), "style": "ninja", "scale": 1.15}

	out["ch03_ash_intro"] = {"mood": "", "music": "action", "cast": [
		D.ch("kai", "kai", Vector3(-4, 0.2, -2), Vector3(4, 0.2, -2)), D.fig("ash", cfg_ash, Vector3(4, 0.2, -2), Vector3(-4, 0.2, -2)),
		D.ch("jay", "jay", Vector3(-14, 0.2, 4), Vector3(0, 0.2, -2)), D.ch("lloyd", "lloyd", Vector3(-12, 0.2, 6), Vector3(0, 0.2, -2))], "shots": [
		D.sh(Vector3(0, 3, 8), Vector3(0, 9, -42), 5.0, "crane", 60, {"t": Vector3(0, 8, -4), "fx": "fade_in", "say": [
			D.Q("narrator", "The match board is posted. The crowd leans in.", "تُعلَّق لوحة المباريات. ويميل الحشد إلى الأمام.")]}),
		D.sh(Vector3(0, 11, -36), Vector3(0, 11.2, -42.5), 4.0, "static", 45, {"say": [
			D.Q("chen", "Next match: Kai against Ash. Fight well, both of you.", "المباراة التالية: كاي ضد آش. قاتلا جيدًا، كلاكما.")]}),
		D.sh(Vector3(-8, 1.6, -4), Vector3(4, 1.4, -2), 5.0, "orbit", 48, {"arc": 60.0, "say": [
			D.Q("ash", "Show me something that is not luck.", "أرني شيئًا لا يعتمد على الحظ.")]}),
		D.sh(Vector3(-4, 1.5, 0), Vector3(-4, 1.5, -2), 3.5, "hand", 38)]}

	out["ch03_cole_yields"] = {"mood": "dawn", "music": "hope", "cast": [
		D.ch("jay", "jay", Vector3(0, 0.2, -8), Vector3(0, 0.2, -12)), D.ch("cole", "cole", Vector3(0, 0.2, -12), Vector3(0, 0.2, -8)),
		D.ch("kai", "kai", Vector3(10, 0.2, 6), Vector3(0, 0.2, -10)), D.ch("lloyd", "lloyd", Vector3(12, 0.2, 7), Vector3(0, 0.2, -10))], "shots": [
		D.sh(Vector3(4, 1.8, -5), Vector3(0, 1.4, -10), 5.0, "orbit", 48, {"arc": 70.0, "fx": "fade_in", "say": [
			D.Q("narrator", "Jay raises his weapon for the final blow, and Cole does not move.", "يرفع جاي سلاحه للضربة الأخيرة، ولا يتحرك كول.")]}),
		D.sh(Vector3(-2, 1.5, -9.5), Vector3(0, 1.6, -12), 4.5, "hand", 40, {"act": [D.walk("cole", Vector3(0, 0.2, -13.5), 1.5)], "say": [
			D.Q("cole", "Take it. You earned it, and I owe you.", "خذها. تستحقها، وأنا مدين لك.")]}),
		D.sh(Vector3(2, 1.5, -6.5), Vector3(0, 1.6, -8), 4.0, "hand", 40, {"say": [
			D.Q("jay", "You let me win? You big... thank you.", "تركتني أفوز؟ أيها الكبير... شكرًا.")]}),
		D.sh(Vector3(0, 3.5, -2), Vector3(0, 1.4, -10), 5.0, "dolly", 55, {"t": Vector3(0, 2.2, -5), "act": [D.walk("jay", Vector3(0, 0.2, -11), 2.5)], "say": [
			D.Q("narrator", "Two old friends meet in the middle of the arena.", "صديقان قديمان يلتقيان في منتصف الساحة.")]})]}

	out["ch03_zane_dream"] = {"mood": "snow", "music": "mystery", "cast": [
		D.ch("zane", "zane", Vector3(30, 0.2, -26), Vector3(34, 0.2, -36)),
		D.glow(D.chain(Vector3(34, 0, -38), 6.0, 16, 5.0), 0.9, Color(0.85, 0.95, 1.0), 0.6)], "shots": [
		D.sh(Vector3(20, 3, -14), Vector3(30, 1.5, -26), 5.0, "dolly", 55, {"t": Vector3(24, 3, -18), "fx": "fade_in", "say": [
			D.Q("narrator", "In his cell, Zane sleeps and dreams of a blizzard.", "في زنزانته، ينام زين ويحلم بعاصفة ثلجية.")]}),
		D.sh(Vector3(26, 12, -30), Vector3(34, 5, -38), 6.0, "orbit", 65, {"arc": 90.0, "say": [
			D.Q("narrator", "A dragon of pale metal coils above him in the snow.", "تنين من معدن شاحب يلتف فوقه في الثلج.")]}),
		D.sh(Vector3(28, 1.6, -29), Vector3(30, 1.7, -26), 5.0, "hand", 42, {"say": [
			D.Q("zane", "I know this shape. I have seen it before.", "أعرف هذا الشكل. رأيته من قبل.")]}),
		D.sh(Vector3(34, 2, -26), Vector3(34, 7, -38), 4.0, "crane", 60, {"t": Vector3(34, 6, -28), "fx": "flash"})]}

	out["ch03_dragon_light"] = {"mood": "snow", "music": "mystery", "cast": [
		D.ch("zane", "zane", Vector3(34, 0.2, -26), Vector3(34, 0.2, -32)),
		D.glow([Vector3(34, 0.4, -30), Vector3(16, 0.4, -34), Vector3(28, 0.4, -44), Vector3(40, 0.4, -22)], 0.5, Color(0.7, 0.9, 1.0))], "shots": [
		D.sh(Vector3(26, 8, -12), Vector3(34, 1, -30), 6.0, "crane", 60, {"t": Vector3(30, 4, -20), "fx": "fade_in", "say": [
			D.Q("narrator", "Small sparks of light flicker across the snow, like a trail.", "شرارات صغيرة من الضوء تومض عبر الثلج، كأنها أثر.")]}),
		D.sh(Vector3(32, 1.2, -28), Vector3(34, 0.6, -30), 5.5, "dolly", 38, {"t": Vector3(33, 0.9, -29), "say": [
			D.Q("zane", "This light is not random. It is leading me somewhere.", "هذا الضوء ليس عشوائيًّا. إنه يقودني إلى مكان ما.")]}),
		D.sh(Vector3(30, 1.7, -24), Vector3(34, 1.5, -26), 5.0, "hand", 42, {"say": [
			D.Q("zane", "Then I will follow every spark.", "إذن سأتبع كل شرارة.")]})]}

	out["ch03_dragon_meet"] = {"mood": "snow", "music": "hope", "cast": [
		D.ch("zane", "zane", Vector3(28, 0.2, -32), Vector3(28, 0.2, -38)),
		D.glow(D.chain(Vector3(28, 0, -40), 4.0, 14, 3.0), 0.8, Color(0.85, 0.95, 1.0), 0.6)], "shots": [
		D.sh(Vector3(24, 2.4, -28), Vector3(28, 2.0, -38), 5.5, "orbit", 48, {"arc": 60.0, "fx": "fade_in", "say": [
			D.Q("narrator", "The dragon lowers its head, and the snow stops falling.", "ينخفض رأس التنين، ويتوقف تساقط الثلج.")]}),
		D.sh(Vector3(26, 1.6, -34), Vector3(28, 1.7, -37), 5.0, "hand", 38, {"fx": "flash", "act": [D.anim("zane", "cast", 1.0)]}),
		D.sh(Vector3(30, 1.5, -35), Vector3(28, 1.7, -37), 5.5, "dolly", 40, {"t": Vector3(29.4, 1.6, -35.4), "say": [
			D.Q("zane", "I am not afraid of you. I think we were meant to meet.", "لا أخافك. أظننا كنا مقدَّرين أن نلتقي.")]})]}
	return out
