class_name CutsceneDefsC
extends RefCounted
## Scenes for chapters 4-5. Original wording. VERIFY items are listed in docs/CUTSCENE_HOOKS.md.

const D = CutsceneDefs

static func build() -> Dictionary:
	var out := {}
	var cfg_chamille := {"suit": Color(0.3, 0.4, 0.6), "style": "ninja", "scale": 1.2}
	var cfg_guard := {"suit": Color(0.25, 0.25, 0.3), "style": "bare", "hair": Color(0.1, 0.1, 0.1)}
	var cfg_clouse := {"suit": Color(0.35, 0.2, 0.4), "style": "bare", "hair": Color(0.1, 0.1, 0.12), "scale": 1.4}
	var cfg_skylor := {"suit": CharacterDB.DATA["skylor"]["suit"], "style": "ninja", "weapon": "fan"}
	var cfg_chen := {"suit": Color(0.45, 0.15, 0.5), "style": "bare", "hair": Color(0.1, 0.1, 0.1), "scale": 1.5}
	var cfg_c1 := {"suit": Color(0.5, 0.3, 0.3), "style": "bare", "hair": Color(0.2, 0.1, 0.1)}
	var cfg_c2 := {"suit": Color(0.3, 0.45, 0.35), "style": "bare", "hair": Color(0.3, 0.2, 0.1)}
	var cfg_c3 := {"suit": Color(0.4, 0.4, 0.55), "style": "bare", "hair": Color(0.15, 0.15, 0.2)}

	out["ch04_round_intro"] = {"mood": "gloom", "music": "action", "cast": [
		D.ch("lloyd", "lloyd", Vector3(-4, 0.2, -2), Vector3(4, 0.2, -2)), D.fig("chamille", cfg_chamille, Vector3(4, 0.2, -2), Vector3(-4, 0.2, -2)),
		D.ch("kai", "kai", Vector3(-14, 0.2, 4), Vector3(0, 0.2, -2)), D.ch("jay", "jay", Vector3(-12, 0.2, 6), Vector3(0, 0.2, -2))], "shots": [
		D.sh(Vector3(0, 11, -34), Vector3(0, 11.2, -42.5), 4.5, "dolly", 45, {"t": Vector3(0, 11, -37), "fx": "fade_in", "say": [
			D.Q("chen", "The Thunderblade round begins. Lloyd, meet Chamille.", "تبدأ جولة Thunderblade. لويد، قابل شاميل.")]}),
		D.sh(Vector3(-9, 1.6, -5), Vector3(4, 1.4, -2), 5.0, "orbit", 50, {"arc": 60.0, "say": [
			D.Q("chamille", "Let us see how long you last.", "لنرَ كم ستصمد.")]}),
		D.sh(Vector3(-4, 1.5, 0), Vector3(-4, 1.5, -2), 4.0, "hand", 38, {"say": [
			D.Q("lloyd", "Longer than you think.", "أطول مما تظن.")]}),
		D.sh(Vector3(0, 2, 6), Vector3(0, 6, -10), 3.5, "crane", 60, {"t": Vector3(0, 4, 2), "fx": "shake"})]}

	out["ch04_nya_infiltrates"] = {"mood": "night", "music": "tense", "cast": [
		D.ch("nya", "nya", Vector3(-22, 0.2, 57), Vector3(-14, 0.2, 58)), D.fig("g1", cfg_guard, Vector3(-9, 0.2, 56), Vector3(-14, 0.2, 52)),
		D.fig("g2", cfg_guard, Vector3(-14, 0.2, 50), Vector3(-9, 0.2, 56))], "shots": [
		D.sh(Vector3(-30, 8, 70), Vector3(-14, 1.5, 60), 5.0, "crane", 55, {"t": Vector3(-24, 3, 64), "fx": "fade_in", "say": [
			D.Q("narrator", "Night falls over the dock. A ferry waits, lit and guarded.", "يحلّ الليل على الرصيف. عبّارة تنتظر، مضاءة ومحروسة.")]}),
		D.sh(Vector3(-24, 1.6, 59), Vector3(-22, 1.4, 57), 5.0, "hand", 40, {"act": [D.walk("nya", Vector3(-17, 0.2, 58), 4.0)], "say": [
			D.Q("nya", "Two guards. One ferry. Plenty of shadows.", "حارسان. عبّارة واحدة. وظلال كثيرة.")]}),
		D.sh(Vector3(-11, 1.8, 54), Vector3(-9, 1.5, 56), 4.0, "static", 45),
		D.sh(Vector3(-20, 1.5, 55), Vector3(-17, 1.4, 58), 4.0, "dolly", 38, {"t": Vector3(-19, 1.5, 56.5), "say": [
			D.Q("nya", "Do not breathe. Do not blink.", "لا تتنفسي. لا ترمشي.")]})]}

	out["ch04_nya_aboard"] = {"mood": "night", "music": "mystery", "cast": [
		D.ch("nya", "nya", Vector3(0, 0.2, 38), Vector3(0, 0.2, 30))], "shots": [
		D.sh(Vector3(3, 2.4, 44), Vector3(0, 1.4, 36), 6.0, "dolly", 50, {"t": Vector3(2, 2, 42), "fx": "fade_in", "act": [D.walk("nya", Vector3(0, 0.2, 33), 4.5)], "say": [
			D.Q("narrator", "Nobody saw her step off the ferry.", "لم يرها أحد وهي تنزل من العبّارة.")]}),
		D.sh(Vector3(0, 1.6, 30), Vector3(0, 1.5, 34), 5.5, "hand", 40, {"say": [
			D.Q("nya", "I am in. Now to find out what Chen is really hiding.", "دخلت. الآن لأعرف ما الذي يخفيه تشِن حقًّا.")]}),
		D.sh(Vector3(6, 7, 48), Vector3(0, 3, 24), 5.0, "crane", 60, {"t": Vector3(6, 11, 52)})]}

	out["ch04_escape_plan"] = {"mood": "gloom", "music": "tense", "cast": [
		D.ch("cole", "cole", Vector3(-50, 0.2, -12), Vector3(-48, 0.2, -10)), D.ch("zane", "zane", Vector3(-48, 0.2, -10), Vector3(-50, 0.2, -12)),
		D.fig("c1", cfg_c1, Vector3(-52, 0.2, -8), Vector3(-50, 0.2, -11)), D.fig("c2", cfg_c2, Vector3(-46, 0.2, -14), Vector3(-49, 0.2, -11)),
		D.fig("c3", cfg_c3, Vector3(-54, 0.2, -12), Vector3(-50, 0.2, -11))], "shots": [
		D.sh(Vector3(-44, 4, -8), Vector3(-50, 1.4, -11), 5.0, "orbit", 55, {"arc": 70.0, "fx": "fade_in", "say": [
			D.Q("narrator", "In the cells, the losers have stopped waiting to be rescued.", "في الزنازين، توقف الخاسرون عن انتظار من ينقذهم.")]}),
		D.sh(Vector3(-52, 1.6, -9), Vector3(-50, 1.6, -12), 4.5, "hand", 38, {"say": [
			D.Q("cole", "Keep it low. They count heads at the change of shifts.", "اخفضوا أصواتكم. يعدّون الرؤوس عند تبدّل المناوبات.")]}),
		D.sh(Vector3(-46, 1.6, -8), Vector3(-48, 1.6, -10), 4.5, "static", 40, {"say": [
			D.Q("zane", "I have mapped the patrol gaps. We have eleven seconds.", "رسمت ثغرات الدوريات. لدينا إحدى عشرة ثانية.")]}),
		D.sh(Vector3(-50, 5, -16), Vector3(-50, 1, -11), 4.0, "crane", 55, {"t": Vector3(-50, 8, -11), "fx": "fade_out"})]}

	out["ch05_spy_among_them"] = {"mood": "", "music": "mystery", "cast": [
		D.ch("nya", "nya", Vector3(24, 0.2, -10), Vector3(20, 0.2, -12)), D.fig("c1", cfg_c1, Vector3(20, 0.2, -8), Vector3(24, 0.2, -10)),
		D.fig("c2", cfg_c2, Vector3(28, 0.2, -12), Vector3(24, 0.2, -10)), D.fig("c3", cfg_c3, Vector3(22, 0.2, -15), Vector3(24, 0.2, -10))], "shots": [
		D.sh(Vector3(30, 5, 0), Vector3(24, 1.5, -10), 6.0, "crane", 55, {"t": Vector3(29, 3, -4), "fx": "fade_in", "say": [
			D.Q("narrator", "Nya blends in with the contestants, an ordinary face in the crowd.", "تندمج نيا بين المتسابقين، وجهًا عاديًّا في الزحام.")]}),
		D.sh(Vector3(26, 1.7, -7), Vector3(24, 1.5, -10), 5.5, "hand", 40, {"act": [D.walk("nya", Vector3(21, 0.2, -13), 4.0)], "say": [
			D.Q("nya", "Smile. Nod. Look bored.", "ابتسمي. أومئي. تظاهري بالملل.")]}),
		D.sh(Vector3(14, 2, -26), Vector3(0, 9, -45), 5.5, "dolly", 55, {"t": Vector3(14, 2.4, -30), "say": [
			D.Q("narrator", "Whatever Chen hides, it is behind those walls.", "مهما يخفي تشِن، فهو خلف تلك الجدران.")]})]}

	out["ch05_spell_found"] = {"mood": "gloom", "music": "mystery", "cast": [
		D.ch("nya", "nya", Vector3(0, 0.2, -38), Vector3(0, 2, -44)),
		D.glow([Vector3(0, 1.8, -44)], 0.45, Color(0.7, 0.3, 1.0))], "shots": [
		D.sh(Vector3(0, 6, -28), Vector3(0, 2, -44), 6.0, "crane", 60, {"t": Vector3(0, 3, -34), "fx": "fade_in", "say": [
			D.Q("narrator", "A scroll glows faintly beyond the window.", "لفافة تتوهج بخفوت خلف النافذة.")]}),
		D.sh(Vector3(0, 1.8, -41.5), Vector3(0, 1.8, -44), 5.0, "dolly", 35, {"t": Vector3(0, 1.8, -42.5), "say": [
			D.Q("nya", "A spell of transformation... and a lot of names crossed out.", "تعويذة تحوّل... وأسماء كثيرة مشطوبة.")]}),
		D.sh(Vector3(3, 1.6, -38), Vector3(0, 1.6, -40), 5.0, "hand", 40, {"act": [D.walk("nya", Vector3(0, 0.2, -42), 2.5)], "say": [
			D.Q("nya", "This comes with me.", "هذه تأتي معي.")]})]}

	out["ch05_clouse_intro"] = {"mood": "gloom", "music": "tense", "cast": [
		D.ch("nya", "nya", Vector3(3, 0.2, -38), Vector3(-3, 0.2, -38)), D.fig("clouse", cfg_clouse, Vector3(-3, 0.2, -38), Vector3(3, 0.2, -38))], "shots": [
		D.sh(Vector3(-3, 0.8, -34), Vector3(-3, 2.2, -38), 5.5, "dolly", 55, {"t": Vector3(-3, 1.0, -35), "fx": "fade_in", "say": [
			D.Q("narrator", "A heavy figure steps out of the shadows and blocks the corridor.", "شخص ضخم يخرج من الظلال ويسدّ الممر.")]}),
		D.sh(Vector3(5, 1.6, -34), Vector3(3, 1.5, -38), 5.0, "hand", 40, {"say": [
			D.Q("nya", "Wrong way to the kitchen, I think.", "أظنني ضللت الطريق إلى المطبخ.")]}),
		D.sh(Vector3(0, 6, -30), Vector3(0, 1.4, -38), 5.5, "orbit", 55, {"arc": 70.0, "say": [
			D.Q("clouse", "You are not a contestant. You are a thief.", "أنتِ لستِ متسابقة. أنتِ لصة.")]})]}

	out["ch05_escape"] = {"mood": "dusk", "music": "action", "cast": [
		D.ch("nya", "nya", Vector3(0, 0.2, -34), Vector3(0, 0.2, -10)), D.fig("g1", cfg_guard, Vector3(-4, 0.2, -38), Vector3(0, 0.2, -10)),
		D.fig("g2", cfg_guard, Vector3(4, 0.2, -38), Vector3(0, 0.2, -10))], "shots": [
		D.sh(Vector3(8, 6, -30), Vector3(0, 1, -36), 5.0, "crane", 60, {"t": Vector3(6, 3, -30), "fx": "fade_in", "say": [
			D.Q("narrator", "An alarm bell tears through the island.", "جرس إنذار يمزّق هدوء الجزيرة.")]}),
		D.sh(Vector3(0, 2.4, -42), Vector3(0, 1.4, -26), 6.0, "hand", 55, {"act": [
			D.walk("nya", Vector3(0, 0.2, -18), 4.0), D.walk("g1", Vector3(-1, 0.2, -26), 4.2), D.walk("g2", Vector3(1, 0.2, -26), 4.2)], "say": [
			D.Q("nya", "Run first, plan later!", "اركضي أولًا، وخططي لاحقًا!")]}),
		D.sh(Vector3(10, 3, -10), Vector3(0, 1.4, -18), 5.5, "dolly", 60, {"t": Vector3(8, 2.5, -4)})]}

	out["ch05_skylor_spy"] = {"mood": "gloom", "music": "tense", "cast": [
		D.fig("chen", cfg_chen, Vector3(0, 0.2, -52), Vector3(0, 0.2, -44)), D.fig("sky", cfg_skylor, Vector3(0, 0.2, -44), Vector3(0, 0.2, -52)),
		D.fig("clo", cfg_clouse, Vector3(6, 0.2, -50), Vector3(0, 0.2, -46))], "shots": [
		D.sh(Vector3(-8, 6, -34), Vector3(0, 2, -50), 5.0, "crane", 58, {"t": Vector3(-4, 4, -40), "fx": "fade_in", "say": [
			D.Q("narrator", "Deep in Chen's palace, someone is reporting on the secret alliance of contestants.", "في عمق قصر تشِن، يقدّم أحدهم تقريرًا عن تحالف المتسابقين السري.")]}),
		D.sh(Vector3(-3, 1.7, -42), Vector3(0, 1.7, -44), 5.0, "hand", 40, {"say": [
			D.Q("skylor", "They meet after dark. The ninja, the masters, all of them. I have every name.", "يجتمعون بعد حلول الظلام. النينجا والماسترز، كلهم. معي كل الأسماء.")]}),
		D.sh(Vector3(4, 1.8, -47), Vector3(0, 2.2, -52), 5.0, "dolly", 42, {"t": Vector3(2, 1.9, -49), "say": [
			D.Q("chen", "Good. Keep smiling, and keep them trusting you.", "جيد. استمري في الابتسام، واجعليهم يثقون بك.")]}),
		D.sh(Vector3(0, 3, -40), Vector3(0, 1.6, -44), 4.0, "static", 55, {"say": [
			D.Q("narrator", "The spy hidden among the alliance is Skylor.", "الجاسوسة المتخفية داخل التحالف هي سكايلور.")]})]}

	out["ch05_jay_foot"] = {"mood": "", "music": "sad", "cast": [
		D.ch("jay", "jay", Vector3(0, 0.2, 0), Vector3(4, 0.2, 4)), D.ch("lloyd", "lloyd", Vector3(4, 0.2, 2), Vector3(0, 0.2, 0))], "shots": [
		D.sh(Vector3(6, 4, 8), Vector3(0, 1, 0), 5.5, "crane", 55, {"t": Vector3(5, 2.5, 6), "fx": "fade_in", "act": [D.anim("jay", "stagger", 1.0)], "say": [
			D.Q("narrator", "Jay stumbles off the arena floor, favoring one foot.", "يترنح جاي بعيدًا عن أرض الساحة وهو يتّكئ على قدم واحدة.")]}),
		D.sh(Vector3(-2, 1.6, 2), Vector3(0, 1.3, 0), 5.5, "hand", 40, {"say": [
			D.Q("jay", "Ow. Ow. Okay. Ow.", "آه. آه. حسنًا. آه.")]}),
		D.sh(Vector3(6, 1.6, 4), Vector3(4, 1.5, 2), 5.0, "static", 42, {"say": [
			D.Q("lloyd", "Sit. Do not argue. We will manage.", "اجلس. لا تجادل. سنتدبّر الأمر.")]})]}

	out["ch05_kai_skylor"] = {"mood": "dawn", "music": "hope", "cast": [
		D.ch("kai", "kai", Vector3(6, 0.2, 4), Vector3(9, 0.2, 2)), D.fig("skylor", cfg_skylor, Vector3(9, 0.2, 2), Vector3(6, 0.2, 4))], "shots": [
		D.sh(Vector3(2, 2.4, 8), Vector3(7.5, 1.4, 3), 5.0, "orbit", 48, {"arc": -60.0, "fx": "fade_in", "say": [
			D.Q("narrator", "For a moment the tournament feels very far away.", "لوهلة تبدو البطولة بعيدة جدًّا.")]}),
		D.sh(Vector3(8, 1.6, 6), Vector3(6, 1.6, 4), 4.0, "hand", 38, {"say": [
			D.Q("kai", "I did not expect to like anyone on this island.", "لم أتوقع أن يعجبني أحد على هذه الجزيرة.")]}),
		D.sh(Vector3(7, 1.5, 0), Vector3(9, 1.6, 2), 4.5, "hand", 38, {"say": [
			D.Q("skylor", "Keep that to yourself. I have a reputation.", "احتفظ بذلك لنفسك. لي سمعة أحافظ عليها.")]}),
		D.sh(Vector3(3, 6, 12), Vector3(7.5, 1.4, 3), 4.0, "crane", 55, {"t": Vector3(3, 9, 16)})]}
	return out
