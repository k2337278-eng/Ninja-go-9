class_name CutsceneDefsA
extends RefCounted

const D = CutsceneDefs
## Scenes for chapters 1-2. Original wording. VERIFY items are listed in docs/CUTSCENE_HOOKS.md.

static func build() -> Dictionary:
	var out := {}
	var statue := Vector3(5, 1.0, 46)
	var cfg_stat := {"suit": Color(0.85, 0.87, 0.92), "style": "ninja", "scale": 1.4}
	var cfg_msg := {"suit": Color(0.5, 0.35, 0.2), "style": "bare", "hair": Color(0.2, 0.15, 0.1)}
	var cfg_ctn := {"suit": Color(0.4, 0.4, 0.45), "style": "bare", "hair": Color(0.1, 0.1, 0.1)}
	var cfg_karlof := {"suit": Color(0.45, 0.3, 0.15), "style": "bare", "hair": Color(0.15, 0.1, 0.05), "scale": 1.45}
	var cfg_skylor := {"suit": CharacterDB.DATA["skylor"]["suit"], "style": "ninja", "weapon": "fan"}

	out["ch01_mourning"] = {"mood": "gloom", "music": "sad", "cast": [
		D.fig("statue", cfg_stat, statue, Vector3(5, 1, 60)),
		D.ch("kai", "kai", Vector3(2, 0.2, 50), statue), D.ch("jay", "jay", Vector3(4, 0.2, 51), statue),
		D.ch("cole", "cole", Vector3(6.5, 0.2, 50.5), statue), D.ch("lloyd", "lloyd", Vector3(8.5, 0.2, 49), statue),
		D.ch("nya", "nya", Vector3(0, 0.2, 52), statue)], "shots": [
		D.sh(Vector3(-2, 7, 60), Vector3(5, 2.5, 46), 6.0, "crane", 55, {"t": Vector3(-2, 2.6, 55), "fx": "fade_in",
			"say": [D.Q("narrator", "Days have passed since Zane disappeared. The courtyard is quiet.", "مرّت أيام منذ اختفى زين. والساحة هادئة.")]}),
		D.sh(Vector3(-3, 2.2, 54), Vector3(5, 1.5, 50), 6.0, "orbit", 50, {"arc": 55.0, "say": [
			D.Q("jay", "I keep waiting for him to walk in and fix something.", "ما زلت أنتظر أن يدخل ويصلح شيئًا ما.")]}),
		D.sh(Vector3(1, 1.8, 53.5), Vector3(2, 1.6, 50), 5.0, "hand", 45, {"say": [
			D.Q("kai", "He never asked for thanks. That is what hurts.", "لم يطلب الشكر يومًا. وهذا ما يؤلم.")]}),
		D.sh(Vector3(11, 1.7, 52), Vector3(8.5, 1.6, 49), 5.0, "dolly", 45, {"t": Vector3(10, 1.7, 51), "say": [
			D.Q("lloyd", "We can grieve and still move. He would want that.", "نستطيع أن نحزن ونتحرك معًا. هذا ما كان سيريده.")]}),
		D.sh(Vector3(5, 5, 54), Vector3(5, 1.5, 48), 5.0, "crane", 60, {"t": Vector3(5, 14, 64), "fx": "fade_out"})]}

	out["ch01_invitation"] = {"mood": "", "music": "mystery", "cast": [
		D.fig("msg", cfg_msg, Vector3(14, 0.2, 58), Vector3(6, 0.2, 51)),
		D.ch("kai", "kai", Vector3(4, 0.2, 51), Vector3(8, 0.2, 52)), D.ch("jay", "jay", Vector3(6, 0.2, 50), Vector3(8, 0.2, 52)),
		D.ch("cole", "cole", Vector3(2, 0.2, 53), Vector3(8, 0.2, 52)), D.ch("lloyd", "lloyd", Vector3(5, 0.2, 54), Vector3(8, 0.2, 52)),
		D.ch("nya", "nya", Vector3(7, 0.2, 54), Vector3(8, 0.2, 52))], "shots": [
		D.sh(Vector3(12, 3, 62), Vector3(7, 1.2, 53), 5.0, "dolly", 55, {"t": Vector3(10, 2.4, 58), "fx": "fade_in",
			"act": [D.walk("msg", Vector3(8, 0.2, 52), 4.0)], "say": [
			D.Q("narrator", "A stranger crosses the courtyard carrying a sealed envelope.", "يعبر غريب الساحة وفي يده مظروف مختوم.")]}),
		D.sh(Vector3(10, 1.7, 55), Vector3(8, 1.4, 52), 4.5, "hand", 45, {"act": [D.anim("msg", "light1", 0.6)], "say": [
			D.Q("narrator", "The seal bears the mark of a tournament island.", "يحمل الختم علامة جزيرة بطولة.")]}),
		D.sh(Vector3(3, 1.6, 55), Vector3(4, 1.5, 51), 4.5, "static", 50, {"say": [
			D.Q("jay", "A tournament? For us?", "بطولة؟ لنا؟")]}),
		D.sh(Vector3(8, 1.5, 50.5), Vector3(8, 1.3, 52), 5.0, "dolly", 40, {"t": Vector3(8, 1.35, 51.2), "say": [
			D.Q("narrator", "Master Chen invites the elemental masters to compete on his island.", "يدعو الماستر تشِن أسياد العناصر للتنافس على جزيرته.")]})]}

	out["ch01_voyage"] = {"mood": "dusk", "music": "hope", "cast": [
		D.ch("kai", "kai", Vector3(-14, 1.0, 60), Vector3(0, 1, 20)), D.ch("jay", "jay", Vector3(-12.5, 1.0, 61), Vector3(0, 1, 20)),
		D.ch("cole", "cole", Vector3(-15.5, 1.0, 61), Vector3(0, 1, 20))], "shots": [
		D.sh(Vector3(-34, 9, 84), Vector3(-14, 1.5, 60), 6.0, "crane", 55, {"t": Vector3(-24, 3.5, 72), "fx": "fade_in", "say": [
			D.Q("narrator", "The ferry leaves the shore behind.", "تترك العبّارة الشاطئ خلفها.")]}),
		D.sh(Vector3(-17, 1.8, 63), Vector3(-14, 1.6, 60), 5.0, "hand", 45, {"say": [
			D.Q("cole", "Calm water. I hate calm water.", "ماء هادئ. أكره الماء الهادئ.")]}),
		D.sh(Vector3(-14, 1.8, 64), Vector3(0, 3, 20), 6.0, "dolly", 50, {"t": Vector3(-14, 1.9, 66), "say": [
			D.Q("kai", "There it is. Whatever Chen wants, we will see it first.", "ها هي. مهما يريد تشِن، سنراه أولًا."),
			D.Q("narrator", "Chen's island rises out of the dusk.", "ترتفع جزيرة تشِن من الغروب.")]}),
		D.sh(Vector3(-20, 6, 76), Vector3(-6, 2, 40), 4.0, "crane", 60, {"t": Vector3(-14, 11, 84), "fx": "fade_out"})]}

	out["ch01_arrival"] = {"mood": "dawn", "music": "mystery", "cast": [
		D.ch("kai", "kai", Vector3(0, 0.2, 52), Vector3(0, 0.2, 40)), D.ch("jay", "jay", Vector3(2.4, 0.2, 53), Vector3(0, 0.2, 40)),
		D.ch("cole", "cole", Vector3(-2.4, 0.2, 53), Vector3(0, 0.2, 40))], "shots": [
		D.sh(Vector3(0, 13, 82), Vector3(0, 2, 45), 6.0, "crane", 60, {"t": Vector3(0, 5, 62), "fx": "fade_in", "say": [
			D.Q("narrator", "Banners, torches, and a crowd of strangers with strange powers.", "رايات ومشاعل وحشد من الغرباء بقوى غريبة.")]}),
		D.sh(Vector3(0, 2.2, 58), Vector3(0, 1.5, 46), 6.0, "hand", 50, {"act": [
			D.walk("kai", Vector3(0, 0.2, 46), 5.5), D.walk("jay", Vector3(2.4, 0.2, 47), 5.5), D.walk("cole", Vector3(-2.4, 0.2, 47), 5.5)], "say": [
			D.Q("jay", "Okay, that is a very large island.", "حسنًا، هذه جزيرة كبيرة جدًّا.")]}),
		D.sh(Vector3(7, 2, 32), Vector3(0, 2, 44), 5.0, "dolly", 55, {"t": Vector3(6, 2.5, 30), "l2": Vector3(0, 3, 30)}),
		D.sh(Vector3(0, 1.6, 40), Vector3(0, 6, 5), 4.0, "crane", 60, {"t": Vector3(0, 3, 36), "say": [
			D.Q("kai", "Eyes open. Everyone here is watching someone.", "عيون مفتوحة. كل من هنا يراقب أحدًا.")]})]}

	out["ch01_karlof_intro"] = {"mood": "", "music": "tense", "cast": [
		D.ch("kai", "kai", Vector3(0, 0.2, 32), Vector3(0, 0.2, 22)), D.ch("jay", "jay", Vector3(-3, 0.2, 36), Vector3(0, 0.2, 22)),
		D.ch("cole", "cole", Vector3(3, 0.2, 36), Vector3(0, 0.2, 22)), D.fig("karlof", cfg_karlof, Vector3(0, 0.2, 21), Vector3(0, 0.2, 32))], "shots": [
		D.sh(Vector3(0, 0.8, 27), Vector3(0, 2.1, 21), 5.0, "dolly", 55, {"t": Vector3(0, 1.0, 25), "fx": "fade_in", "say": [
			D.Q("narrator", "A mountain of a man blocks the path.", "رجل كالجبل يسدّ الطريق.")]}),
		D.sh(Vector3(5, 1.7, 28), Vector3(0, 1.4, 26), 5.0, "orbit", 45, {"arc": -40.0, "say": [
			D.Q("karlof", "Small fighter. Big attitude.", "مقاتل صغير. وغرور كبير.")]}),
		D.sh(Vector3(-3, 1.6, 30), Vector3(0, 1.5, 32), 4.0, "hand", 40, {"say": [
			D.Q("kai", "I did not come here for you.", "لم آتِ إلى هنا من أجلك.")]}),
		D.sh(Vector3(0, 2, 26), Vector3(0, 1.8, 21), 3.5, "static", 55, {"act": [D.anim("karlof", "heavy", 0.9)], "fx": "shake"})]}

	out["ch02_announcement"] = {"mood": "", "music": "mystery", "cast": [
		D.ch("kai", "kai", Vector3(5, 0.2, -2), Vector3(-5, 0.2, -2)), D.fig("karlof", cfg_karlof, Vector3(-5, 0.2, -2), Vector3(5, 0.2, -2)),
		D.ch("jay", "jay", Vector3(14, 0.2, 2), Vector3(0, 0.2, -2)), D.ch("cole", "cole", Vector3(15.5, 0.2, 4), Vector3(0, 0.2, -2)),
		D.ch("lloyd", "lloyd", Vector3(13, 0.2, 4), Vector3(0, 0.2, -2))], "shots": [
		D.sh(Vector3(0, 3, 8), Vector3(0, 6, -10), 5.0, "crane", 60, {"t": Vector3(0, 9, -10), "l2": Vector3(0, 10.5, -42), "fx": "fade_in", "say": [
			D.Q("narrator", "The crowd falls silent as Chen steps to the balcony.", "يسكت الحشد حين يخطو تشِن إلى الشرفة.")]}),
		D.sh(Vector3(0, 11, -36), Vector3(0, 11.2, -42.5), 5.0, "dolly", 45, {"t": Vector3(0, 11, -38), "say": [
			D.Q("chen", "Only one of these two will stand in the next round.", "واحد فقط من هذين سيقف في الجولة التالية.")]}),
		D.sh(Vector3(0, 1.6, -9), Vector3(0, 1.4, -2), 5.0, "orbit", 50, {"arc": 70.0}),
		D.sh(Vector3(12, 1.6, 4), Vector3(14, 1.4, 3), 3.5, "static", 45, {"say": [
			D.Q("jay", "Please, please do not lose.", "أرجوك، أرجوك لا تخسر.")]})]}

	out["ch02_unfair_win"] = {"mood": "gloom", "music": "tense", "cast": [
		D.ch("kai", "kai", Vector3(0, 0.2, -8), Vector3(0, 0.2, -12)), D.fig("karlof", cfg_karlof, Vector3(0, 0.2, -12), Vector3(0, 0.2, -8))], "shots": [
		D.sh(Vector3(5, 1.8, -2), Vector3(0, 1.3, -10), 5.5, "orbit", 50, {"arc": -60.0, "fx": "fade_in", "act": [D.anim("karlof", "stagger", 1.2)], "say": [
			D.Q("narrator", "The bell rings. Karlof is down, and the match is over.", "يرنّ الجرس. كارلوف على الأرض، وانتهت المباراة.")]}),
		D.sh(Vector3(1.5, 1.4, -6.5), Vector3(0, 1.6, -8), 5.5, "hand", 40, {"say": [
			D.Q("narrator", "Something about that finish was not fair. (VERIFY: the exact way.)", "شيء في هذه النهاية لم يكن عادلًا. (VERIFY: الطريقة بالضبط.)"),
			D.Q("kai", "That was not me. That was not a win.", "هذا لم يكن أنا. هذا لم يكن فوزًا.")]}),
		D.sh(Vector3(0, 7, 4), Vector3(0, 1, -10), 4.5, "crane", 60, {"t": Vector3(0, 10, 8)})]}

	out["ch02_skylor_hint"] = {"mood": "dusk", "music": "mystery", "cast": [
		D.fig("skylor", cfg_skylor, Vector3(10, 0.2, 4), Vector3(5, 0.2, 6)), D.ch("kai", "kai", Vector3(5, 0.2, 6), Vector3(10, 0.2, 4))], "shots": [
		D.sh(Vector3(6, 1.7, 7), Vector3(10, 1.5, 4), 5.5, "dolly", 45, {"t": Vector3(7, 1.7, 6.5), "fx": "fade_in", "say": [
			D.Q("narrator", "A contestant has been watching Kai since his match.", "متسابقة تراقب كاي منذ مباراته.")]}),
		D.sh(Vector3(9, 1.5, 7), Vector3(5, 1.5, 6), 5.0, "hand", 42, {"say": [
			D.Q("kai", "Do I know you?", "هل أعرفك؟")]}),
		D.sh(Vector3(7, 1.4, 1.5), Vector3(10, 1.5, 4), 5.5, "static", 40, {"act": [D.anim("skylor", "cast", 0.8)], "say": [
			D.Q("skylor", "Not yet. Mine is a different kind of power.", "ليس بعد. قوتي من نوع آخر."),
			D.Q("narrator", "(VERIFY: Skylor's ability is only hinted.)", "(VERIFY: قدرة سكايلور مجرد تلميح.)")]})]}

	out["ch02_discovery"] = {"mood": "gloom", "music": "tense", "cast": [
		D.fig("loser", {"suit": Color(0.45, 0.45, 0.5), "style": "bare", "hair": Color(0.3, 0.25, 0.2)}, Vector3(4, 0.2, 0), Vector3(16, 0.2, 14)),
		D.ch("kai", "kai", Vector3(-3, 0.2, -12), Vector3(4, 0.2, 0)), D.ch("jay", "jay", Vector3(-5, 0.2, -12), Vector3(4, 0.2, 0)),
		D.ch("cole", "cole", Vector3(-7, 0.2, -12), Vector3(4, 0.2, 0)), D.ch("lloyd", "lloyd", Vector3(-9, 0.2, -12), Vector3(4, 0.2, 0))], "shots": [
		D.sh(Vector3(-4, 6, -14), Vector3(4, 1.3, 0), 6.0, "dolly", 55, {"t": Vector3(-2, 5.5, -12), "fx": "fade_in", "act": [D.walk("loser", Vector3(16, 0.2, 14), 9.0)], "say": [
			D.Q("narrator", "A defeated contestant leaves the arena, slow and hollow.", "متسابق مهزوم يغادر الساحة، بطيئًا وخاويًا.")]}),
		D.sh(Vector3(-6, 1.6, -9), Vector3(-5, 1.5, -12), 4.5, "hand", 42, {"say": [
			D.Q("jay", "He looks like someone switched him off.", "يبدو كأن أحدهم أطفأه.")]}),
		D.sh(Vector3(10, 1.8, 7), Vector3(4, 1.3, 0), 5.0, "static", 45, {"say": [
			D.Q("narrator", "Chen's tournament is taking the powers of the ones who lose.", "بطولة تشِن تسلب قوى من يخسرون.")]}),
		D.sh(Vector3(-3, 1.6, -10), Vector3(-3, 1.6, -12), 4.0, "dolly", 38, {"t": Vector3(-3, 1.6, -11), "say": [
			D.Q("kai", "Then we cannot afford to lose. And we cannot leave.", "إذن لا يمكننا أن نخسر. ولا يمكننا أن نغادر.")]})]}
	return out
