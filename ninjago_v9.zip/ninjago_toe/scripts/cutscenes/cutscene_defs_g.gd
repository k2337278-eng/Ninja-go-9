class_name CutsceneDefsG
extends RefCounted
## v8 scenes for chapters 9-10: Wu, Warden Noble, Pythor's seizure, Wu's plan, Garmadon's ritual. Original wording.

const D = CutsceneDefs

static func build() -> Dictionary:
	var out := {}
	var cfg_wu := {"suit": CharacterDB.DATA["wu"]["suit"], "style": "bare", "hair": Color(0.85, 0.85, 0.85), "scale": 1.05}
	var cfg_nob := {"suit": CharacterDB.DATA["noble"]["suit"], "style": "ninja"}
	var cfg_py := {"suit": CharacterDB.DATA["pythor"]["suit"], "style": "ninja", "scale": 0.6}
	var cfg_ana := {"suit": Color(0.3, 0.12, 0.4), "style": "ninja", "hat": Color(0.15, 0.4, 0.15)}
	var cfg_garm := {"suit": CharacterDB.DATA["garmadon"]["suit"], "style": "bare", "hair": Color(0.1, 0.05, 0.05), "scale": 1.3}
	var cfg_py_big := {"suit": CharacterDB.DATA["pythor"]["suit"], "style": "ninja"}

	out["ch09_wu_meets"] = {"mood": "dawn", "music": "hope", "cast": [
		D.fig("wu", cfg_wu, Vector3(-38, 0.2, 34), Vector3(-44, 0.2, 40)), D.ch("lloyd", "lloyd", Vector3(-44, 0.2, 40), Vector3(-38, 0.2, 34)),
		D.ch("kai", "kai", Vector3(-42, 0.2, 41), Vector3(-38, 0.2, 34)), D.ch("jay", "jay", Vector3(-46, 0.2, 41), Vector3(-38, 0.2, 34))], "shots": [
		D.sh(Vector3(-34, 4, 44), Vector3(-41, 1.5, 38), 5.0, "crane", 55, {"t": Vector3(-36, 3, 42), "fx": "fade_in", "say": [
			D.Q("narrator", "On the road to the prison, an old and familiar figure steps out to meet them.", "في الطريق إلى السجن، يخرج لملاقاتهم شخص مسنّ مألوف.")]}),
		D.sh(Vector3(-40, 1.7, 37), Vector3(-38, 1.6, 34), 5.0, "hand", 42, {"act": [D.walk("wu", Vector3(-41, 0.2, 38), 3.5)], "say": [
			D.Q("wu", "You look like people who have not slept. Good. It means you are still trying.", "تبدون كمن لم ينم. جيد. هذا يعني أنكم لا تزالون تحاولون.")]}),
		D.sh(Vector3(-46, 1.6, 44), Vector3(-44, 1.5, 40), 4.5, "static", 42, {"say": [
			D.Q("lloyd", "Master Wu. We could not have asked for better timing.", "المعلّم وو. ما كنا لنطلب توقيتًا أفضل.")]}),
		D.sh(Vector3(-41, 5, 48), Vector3(-41, 1.5, 38), 4.0, "dolly", 55, {"t": Vector3(-41, 3, 44)})]}

	out["ch09_noble_gate"] = {"mood": "gloom", "music": "mystery", "cast": [
		D.fig("nob", cfg_nob, Vector3(-48, 0.2, -38), Vector3(-48, 0.2, -32)), D.fig("wu", cfg_wu, Vector3(-48, 0.2, -33), Vector3(-48, 0.2, -38)),
		D.ch("lloyd", "lloyd", Vector3(-45, 0.2, -32), Vector3(-48, 0.2, -38)), D.ch("kai", "kai", Vector3(-51, 0.2, -32), Vector3(-48, 0.2, -38))], "shots": [
		D.sh(Vector3(-42, 3, -28), Vector3(-48, 1.5, -36), 5.0, "dolly", 52, {"t": Vector3(-43, 2.6, -31), "fx": "fade_in", "say": [
			D.Q("narrator", "The Kryptarium gate. Its warden does not like visitors.", "بوابة الكريبتاريوم. ومأموها لا يحب الزوّار.")]}),
		D.sh(Vector3(-48, 1.6, -35), Vector3(-48, 1.7, -38), 5.0, "hand", 40, {"say": [
			D.Q("noble", "Every cell here is locked for a reason. I answer for each one.", "كل زنزانة هنا مغلقة لسبب. وأنا أجيب عن كل واحدة.")]}),
		D.sh(Vector3(-46, 1.6, -36), Vector3(-48, 1.6, -33), 4.5, "static", 42, {"say": [
			D.Q("wu", "Then answer this: what happens if Chen's cultists reach your prisoner first?", "إذن أجب: ماذا يحدث إن وصل أتباع تشِن إلى سجينك قبلنا؟")]}),
		D.sh(Vector3(-48, 6, -30), Vector3(-48, 1.5, -38), 4.0, "crane", 55, {"t": Vector3(-48, 9, -28)})]}

	out["ch09_pythor_seized"] = {"mood": "night", "music": "tense", "cast": [
		D.fig("py", cfg_py, Vector3(-41, 0.2, -52), Vector3(-41, 0.2, -40)),
		D.fig("a1", cfg_ana, Vector3(-44, 0.2, -50), Vector3(-41, 0.2, -52)), D.fig("a2", cfg_ana, Vector3(-38, 0.2, -50), Vector3(-41, 0.2, -52)),
		D.ch("lloyd", "lloyd", Vector3(-48, 0.2, -46), Vector3(-41, 0.2, -52))], "shots": [
		D.sh(Vector3(-38, 5, -44), Vector3(-41, 1.2, -52), 5.0, "crane", 58, {"t": Vector3(-40, 3, -47), "fx": "fade_in", "say": [
			D.Q("narrator", "The riot clears for a heartbeat, and that is when they strike.", "ينجلي الشغب للحظة، وعندها يضربون.")]}),
		D.sh(Vector3(-42, 1.4, -48), Vector3(-41, 0.9, -52), 4.5, "hand", 42, {"act": [D.walk("a1", Vector3(-40, 0.2, -46), 3.5), D.walk("a2", Vector3(-42, 0.2, -46), 3.5), D.walk("py", Vector3(-41, 0.2, -44), 3.5)], "say": [
			D.Q("pythor", "Put me down! I am small, not fragile!", "أنزلوني! أنا صغير، لا هشّ!")]}),
		D.sh(Vector3(-48, 1.6, -44), Vector3(-48, 1.5, -46), 4.5, "static", 42, {"say": [
			D.Q("lloyd", "No! Pythor!", "لا! بايثور!")]}),
		D.sh(Vector3(-41, 8, -34), Vector3(-41, 1.5, -44), 4.0, "crane", 58, {"t": Vector3(-41, 12, -30), "fx": "fade_out"})]}

	out["ch10_wu_plan"] = {"mood": "dusk", "music": "hope", "cast": [
		D.fig("wu", cfg_wu, Vector3(0, 0.2, 26), Vector3(0, 0.2, 34)), D.ch("lloyd", "lloyd", Vector3(0, 0.2, 31), Vector3(0, 0.2, 26)),
		D.ch("kai", "kai", Vector3(-3, 0.2, 32), Vector3(0, 0.2, 26)), D.ch("jay", "jay", Vector3(3, 0.2, 32), Vector3(0, 0.2, 26)),
		D.ch("cole", "cole", Vector3(-5, 0.2, 34), Vector3(0, 0.2, 26)), D.ch("zane", "zane", Vector3(5, 0.2, 34), Vector3(0, 0.2, 26))], "shots": [
		D.sh(Vector3(0, 8, 44), Vector3(0, 1.5, 28), 5.5, "crane", 58, {"t": Vector3(0, 4, 38), "fx": "fade_in", "say": [
			D.Q("narrator", "Wu gathers the friends who are left and unrolls a very old map.", "يجمع وو من بقي من الأصدقاء ويفرد خريطة قديمة جدًّا.")]}),
		D.sh(Vector3(-3, 1.8, 29), Vector3(0, 1.6, 26), 5.0, "hand", 40, {"say": [
			D.Q("wu", "The Corridor of Elders is narrow. A small army can hold it, if it is brave.", "ممر الحكماء ضيّق. جيش صغير يستطيع حمايته، إن كان شجاعًا.")]}),
		D.sh(Vector3(0, 1.6, 36), Vector3(0, 1.6, 31), 4.5, "static", 42, {"say": [
			D.Q("jay", "So we make a wall out of people. I like it.", "إذن نبني سورًا من البشر. يعجبني ذلك.")]}),
		D.sh(Vector3(8, 3, 30), Vector3(0, 1.5, 28), 4.0, "orbit", 50, {"arc": 70.0})]}

	out["ch10_garmadon_ritual"] = {"mood": "night", "music": "sad", "cast": [
		D.fig("garm", cfg_garm, Vector3(0, 0.2, 6), Vector3(0, 0.2, -4)), D.fig("py", cfg_py_big, Vector3(-4, 0.2, 8), Vector3(0, 0.2, -4)),
		D.glow(D.chain(Vector3(0, 0, -4), 4.5, 16, 0.4), 0.25, Color(0.7, 0.3, 1.0), 0.2)], "shots": [
		D.sh(Vector3(0, 8, 16), Vector3(0, 1.5, -4), 5.5, "crane", 58, {"t": Vector3(0, 5, 12), "fx": "fade_in", "say": [
			D.Q("narrator", "A circle of old light is drawn on the stone. Only one person can stand in it.", "يُرسم على الحجر دائرة من ضوء قديم. ولا يستطيع الوقوف فيها إلا شخص واحد.")]}),
		D.sh(Vector3(-4, 1.6, 10), Vector3(-4, 1.5, 8), 4.5, "hand", 40, {"say": [
			D.Q("pythor", "The words are simple. What they ask for is not.", "الكلمات بسيطة. أما ما تطلبه فليس كذلك.")]}),
		D.sh(Vector3(2, 1.6, 4), Vector3(0, 1.8, 6), 5.0, "dolly", 40, {"t": Vector3(1, 1.7, 5), "say": [
			D.Q("garmadon", "I have been the monster in too many stories. Let me be the end of this one.", "كنت الوحش في قصص كثيرة. دعني أكون نهاية هذه القصة.")]}),
		D.sh(Vector3(0, 6, -10), Vector3(0, 1.4, -4), 4.0, "orbit", 55, {"arc": 70.0})]}
	return out
