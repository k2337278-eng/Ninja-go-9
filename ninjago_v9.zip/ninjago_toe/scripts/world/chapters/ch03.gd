class_name Ch03
extends ChapterBase
## Chapter 3 - Versus (ep. 37). Spec v2: Kai vs Ash; Chen and Clouse pit Jay against Cole, who will not fight
## and finally yields (Jay gets the Jadeblade); Zane, locked up on the island, dreams of a blizzard and the
## Titanium Dragon, and his beacon alerts Nya.
## v6 beats: Kai/Ash (bell climb + guard wave + 2-phase match) -> Jay/Cole (plate gate + match) ->
## Zane's blizzard dream (ice gate lever + timed hunt for 4 sparks of light, mood "snow").
## Hooks: ch03_ash_intro, ch03_cole_yields, ch03_zane_dream, ch03_dragon_light, ch03_dragon_meet.
## VERIFY: Zane's exact situation during the dream; "gather the sparks" is a gameplay choice;
## guard waves / bell / gates are gameplay padding. (The old Digiverse / P.I.X.A.L. rescue was NOT in the spec v2.)

func _init() -> void:
	num = 3
	title = ["Versus", "المواجهة"]

func beats() -> Array:
	return [
		beat("ch03_kai_ash", "kai", ["jay", "cole", "lloyd"], Vector3(18, 0.2, 14), _b0),
		beat("ch03_jay_cole", "jay", ["kai", "lloyd", "cole"], Vector3(0, 0.2, 14), _b1),
		beat("ch03_zane_blizzard", "zane", [], Vector3(24, 0.2, -20), _b2, "snow"),
	]

func _b0() -> bool:
	await begin()
	goals([["Climb the platform and ring the arena bell", "تسلّق المنصة وادقّ جرس الساحة"],
		["Hold off the guards who crack down on a brawl", "صدّ الحراس الذين يقمعون شجارًا"],
		["Read the match board", "اقرأ لوحة المباريات"], ["Defeat Ash", "اهزم آش"],
		["Find the lost banner (optional)", "اعثر على الراية الضائعة (اختياري)"],
		["Use Chen's traps against Ash", "استخدم فخاخ تشِن ضد آش"]])
	note(Vector3(34, 0, 20), "Torn Banner", "راية ممزقة",
		"A contestant's banner, trampled in the dust. Whoever lost it left in a hurry.",
		"راية متسابق مدوسة في التراب. من فقدها غادر مسرعًا.", "ch3_banner")
	isl.hud.set_objective(L("Climb the vine wall and pull the bell lever.", "تسلّق جدار الكروم واسحب ذراع الجرس."))
	if not await climb_lever(Vector3(24, 0, 12), Vector3(0, 0, -1), 3.0):
		return false
	goal_done(0)
	checkpoint()
	await say([ln("lloyd", "The bell rang, and so did half the island. Brawl by the stands!", "رنّ الجرس ومعه نصف الجزيرة. شجار قرب المدرّجات!")])
	if not await waves([["guard", "guard"], ["guard", "grunt", "elite"]], Vector3(10, 0, 6), 8.0, "Break up the brawl", "افضّ الشجار"):
		return false
	goal_done(1)
	if flag_set("ch3_banner"):
		goal_done(4)
		side_reward("ch3_banner", "the lost banner", "الراية الضائعة")
	isl.hud.set_objective(L("Head to the arena.", "توجّه إلى الساحة."))
	if not await wait_near(Vector3(0, 0, 10), 5.0):
		return false
	await hook("ch03_ash_intro",
		"The board lists the next matches. Kai faces a fighter named Ash.",
		"تُعلَن المباريات التالية. كاي يواجه مقاتلًا اسمه آش.",
		Vector3(-6, 12, -26), Vector3(0, 10.5, -42))
	goal_done(2)
	await say([
		ln("ash", "Everyone says you won ugly last round. I want to see if that was luck.", "الكل يقول إنك فزت بشكل قبيح في الجولة السابقة. أريد أن أعرف إن كان حظًّا."),
		me("Luck or not, I am not losing here.", "حظ أو لا، لن أخسر هنا."),
	])
	if not await trap_duel("ash", Vector3(0, 0.3, -12), ARENA_TRAPS, ARENA_BUTTONS, "Defeat Ash!", "اهزم آش!", 0.0, 5):
		return false
	goal_done(3)
	GameState.award("ash_beaten")
	GameState.points += 250
	await say([
		ln("ash", "Fine. You earned that one.", "حسنًا. استحققتها."),
		ln("lloyd", "Good. One down. Jay, you are next, and Cole is waiting.", "جيد. واحدة انتهت. جاي، دورك، وكول ينتظر."),
		ln("jay", "Cole. Of course it is Cole.", "كول. بالطبع هو كول."),
	])
	goals_clear()
	return isl._alive()

func _b1() -> bool:
	goals([["Open the training yard gate (crate on the plate)", "افتح بوابة ساحة التدريب (صندوق على اللوح)"],
		["Talk it out with Cole", "تحدّث مع كول"], ["Dodge Chen's traps for three rounds, keeping Cole safe", "تفادَ فخاخ تشِن لثلاث جولات مع إبقاء كول بأمان"],
		["Accept Cole's concession", "اقبل تنازل كول"]])
	await say([
		ln("cole", "Chen picked this bracket, Jay, not me. For the record.", "تشِن هو من اختار هذا الجدول يا جاي، لا أنا. للتوضيح."),
		me("For the record, I will not hit you either. Chen will not like that.", "للتوضيح، أنا لن أضربك أيضًا. وتشِن لن يحب هذا."),
	])
	await say([ln("kai", "Guards are rushing the yard. Cover Jay while he sorts out the gate.", "الحراس يهجمون على الساحة. غطّوا جاي بينما يتدبّر البوابة.")])
	if not await survive(25.0, "guard", Vector3(0, 0, 18), 3, "Hold the yard", "احمِ الساحة"):
		return false
	isl.hud.set_objective(L("The yard gate is shut: push a crate onto the plate.", "بوابة الساحة مغلقة: ادفع صندوقًا فوق اللوح."))
	if not await plate_door(Vector3(0, 0, 6), Vector3(8, 4, 1), Vector3(-9, 0, 12), [Vector3(6, 0.7, 14), Vector3(-6, 0.7, 16)]):
		return false
	goal_done(0)
	goal_done(1)
	checkpoint()
	if not await _no_hit_match():
		return false
	var cs := place_stone(Vector3(0, 0, -8), Color(0.9, 0.7, 0.3), "Accept Cole's concession", "اقبل تنازل كول")
	isl.hud.set_objective(L("Cole steps back. Accept his concession (USE).", "كول يتراجع. اقبل تنازله (USE)."))
	if not await wait_stone(cs):
		return false
	goal_done(2)
	goal_done(3)
	await hook("ch03_cole_yields",
		"Cole lowers his guard and lets Jay win. The old friendship is mended.",
		"يخفض كول حذره ويترك جاي يفوز. وتعود الصداقة القديمة.",
		Vector3(0, 5, 4), Vector3(0, 1.5, -8))
	GameState.award("friends_again")
	jade(3, "Cole's Jadeblade (VERIFY)", "قطعة كول من Jadeblades (VERIFY)")
	GameState.points += 250
	await say([
		ln("cole", "You win. And I should have said sorry a long time ago.", "أنت فزت. وكان عليّ أن أعتذر منذ زمن."),
		me("Same here. Let us just be friends again and pretend this match was a handshake.", "وأنا كذلك. لنعد أصدقاء ونعتبر هذه المباراة مصافحة."),
		ln("kai", "Sweet. Now someone please explain how we find Zane.", "رائع. الآن ليشرح أحدكم كيف نجد زين."),
	])
	goals_clear()
	return isl._alive()

# Jay vs Cole with no punches: both refuse, Chen's buttons fire the traps, and the player dodges for three rounds
# while keeping Cole safe. Falling too low only repeats the round (both are healed).
func _no_hit_match() -> bool:
	var info := hazard_field(ARENA_TRAPS, [])
	var cole: Companion = isl.comp_by_id("cole")
	var rd := 0
	while rd < 3:
		await isl.hud.banner(L("Round %d / 3: dodge the traps!", "الجولة %d / 3: تفادَ الفخاخ!") % (rd + 1), 1.0)
		var t := 0.0
		var fire_t := 1.5
		var interval: float = [3.4, 2.6, 2.0][rd]
		var failed := false
		while t < 15.0:
			await isl.get_tree().create_timer(0.2).timeout
			if not ok_alive():
				hazards_free(info)
				return false
			t += 0.2
			fire_t -= 0.2
			if fire_t <= 0.0:
				fire_t = interval
				var hz: Array = info["hazards"]
				(hz[randi() % hz.size()] as Hazard).fire(2.4)
				if rd == 2:
					(hz[randi() % hz.size()] as Hazard).fire(2.4)
			var low := isl.player.health / isl.player.max_health < 0.3
			if cole != null and (cole.downed or cole.health / cole.max_health < 0.3):
				low = true
			if low:
				failed = true
				break
			isl.hud.set_objective(L("Round %d / 3 - %d s. Keep Cole out of the traps.", "الجولة %d / 3 - %d ث. أبعد كول عن الفخاخ.") % [rd + 1, int(ceil(15.0 - t))])
		if failed:
			await isl.hud.banner(L("Careful! Both of you are healed. Round again.", "انتبه! شُفي كلاكما. أعد الجولة."), 1.2)
			isl.player.health = isl.player.max_health
			isl.player.health_changed.emit(isl.player)
			if cole != null:
				cole.health = cole.max_health
				cole.downed = false
		else:
			rd += 1
			checkpoint()
	hazards_free(info)
	return isl._alive()

# Zane's dream: pale blizzard sky (mood "snow"). The 4 sparks of light are the Titanium Dragon's glow.
func _b2() -> bool:
	goals([["Follow the light through the storm", "اتبع الضوء عبر العاصفة"], ["Open the ice gate (lever)", "افتح بوابة الجليد (الذراع)"],
		["Gather the 4 sparks of light before time runs out", "اجمع شرارات الضوء الأربع قبل انتهاء الوقت"],
		["Meet the Titanium Dragon", "قابل تنين التيتانيوم"], ["Read the frozen note (optional)", "اقرأ المذكرة المتجمدة (اختياري)"]])
	note(Vector3(20, 0, -26), "Frozen Note", "مذكرة متجمدة",
		"Words scratched into the ice by a metal finger: 'Hold on. They are looking for you.'",
		"كلمات خُدشت على الجليد بإصبع من معدن: 'اصمد. إنهم يبحثون عنك.'", "ch3_memory")
	await say([nr("Locked in a cell on Chen's island, Zane sleeps and dreams of a blizzard.", "محبوسًا في زنزانة على جزيرة تشِن، ينام زين ويحلم بعاصفة ثلجية.")])
	await hook("ch03_zane_dream",
		"Zane walks through a blizzard, until a dragon of pale metal glows in the snow.",
		"يمشي زين في عاصفة ثلجية، حتى يتوهج في الثلج تنين من معدن شاحب.",
		Vector3(18, 6, -10), Vector3(30, 4, -30))
	await say([
		me("A dragon made of metal and light... Why does it feel like a memory?", "تنين من معدن وضوء... لماذا يبدو كذكرى؟"),
		me("Something glimmers inside the storm. A trail I can follow.", "شيء يلمع داخل العاصفة. أثر أستطيع أن أتبعه."),
	])
	goal_done(0)
	await hook("ch03_dragon_light",
		"Faint sparks of light flicker across the snow, as if the dragon is calling him.",
		"شرارات ضوء خافتة تومض عبر الثلج، كأن التنين يناديه.",
		Vector3(26, 7, -12), Vector3(34, 1, -30))
	isl.hud.set_objective(L("An ice gate blocks the way: pull the lever.", "بوابة جليد تسدّ الطريق: اسحب الذراع."))
	if not await lever_door(Vector3(28, 0, -38), Vector3(9, 4, 1), Vector3(22, 0, -32)):
		return false
	goal_done(1)
	checkpoint()
	isl.hud.set_objective(L("Climb the frozen ledge and pull the lever.", "تسلّق الحافة المتجمدة واسحب الذراع."))
	if not await climb_lever(Vector3(14, 0, -22), Vector3(0, 0, -1), 3.0):
		return false
	var pts: Array = [Vector3(34, 0, -30), Vector3(16, 0, -34), Vector3(28, 0, -44), Vector3(40, 0, -22)]
	if not await checkpoints(pts, "Gather the sparks of light", "اجمع شرارات الضوء", 90.0, Color(0.7, 0.9, 1.0), Vector3(24, 0.2, -20)):
		return false
	goal_done(2)
	if flag_set("ch3_memory"):
		goal_done(4)
		side_reward("ch3_memory", "the frozen note", "المذكرة المتجمدة")
	await hook("ch03_dragon_meet",
		"The Titanium Dragon lowers its head toward Zane, and the snow stops falling.",
		"يخفض تنين التيتانيوم رأسه نحو زين، ويتوقف تساقط الثلج.",
		Vector3(24, 4, -26), Vector3(28, 1.5, -34))
	goal_done(3)
	GameState.award("titanium_dream")
	await say([
		me("I was not afraid. I think I was meant to see you.", "لم أكن خائفًا. أظنني كنت مقدَّرًا أن أراك."),
		nr("Far from the island, in the outlands, a forgotten beacon begins to blink.", "بعيدًا عن الجزيرة، في الأراضي النائية، يبدأ مصباح إشارة منسي بالوميض."),
	])
	goals_clear()
	return await finish(900.0)
