class_name Ch10
extends ChapterBase
## Chapter 10 - The Corridor of Elders (ep. 44), per STORY_SPEC v2: Wu's plan to make the last stand here; the Serpentine
## and the citizens join; Pythor arrives with the Book of Spells; the spell needs Garmadon to banish himself to the Cursed
## Realm, which brings back the original Anacondrai generals, who curse the cultists (Chen included) and banish them; a
## statue of Garmadon is raised; Lloyd burns the book; Skylor leaves for now.
## v8 beats: rally the allies (three short missions) -> defend the Corridor (stations) -> Chen (3 phases) -> play
## Garmadon's last moments (ritual circle) -> the aftermath.
## Hooks: ch10_wu_plan, ch10_army, ch10_allies, ch10_pythor_idea, ch10_garmadon_ritual, ch10_garmadon, ch10_victory,
## ch10_skylor_leaves, ch10_ending.
## VERIFY: which Serpentine / generals appear (generic placeholders; only General Arcturus is confirmed as a spirit);
## Pythor's exact words; how Skylor leaves; how Garmadon performs the spell (a ritual circle here); the three ally groups
## and the 3-gate defense are gameplay stand-ins; all waves/gates/climbs are padding with the cultists (Anacondrai).

func _init() -> void:
	num = 10
	title = ["The Corridor of Elders", "ممر الحكماء"]

func beats() -> Array:
	var party: Array = ["kai", "jay", "cole", "zane", "skylor"]
	return [
		beat("ch10_rally", "lloyd", party, Vector3(0, 0.2, 30), _b0, "dusk"),
		beat("ch10_defense", "lloyd", party, Vector3(0, 0.2, 8), _b1, "dusk"),
		beat("ch10_chen", "lloyd", party, Vector3(0, 0.2, 8), _b2, "dusk"),
		beat("ch10_garmadon", "garmadon", ["pythor"], Vector3(0, 0.2, 6), _b3, "dusk"),
		beat("ch10_ending", "lloyd", party, Vector3(0, 0.2, 8), _b4, "dusk"),
	]

func _ally_kinds() -> Array:
	var c: Array = []
	if flag_set("ch10_ally_citizens"):
		c.append("citizens")
	if flag_set("ch10_ally_serpentine"):
		c.append("serpentine")
	if flag_set("ch10_ally_masters"):
		c.append("masters")
	if c.is_empty():
		c = ["citizens", "serpentine", "masters"]
	return c

# Three short missions, one per ally group (each ally gives a different bonus at the defense).
func _b0() -> bool:
	await begin()
	goals([["Hear Wu's plan", "اسمع خطة وو"], ["Bring the citizens to the Corridor", "أحضر المواطنين إلى الممر"],
		["Win the Serpentine over", "اكسب السيربنتين"], ["Rally the Masters", "اجمع الماسترز"],
		["Read the soldier's letter (optional)", "اقرأ رسالة الجندي (اختياري)"], ["Find the teacup (optional)", "اعثر على فنجان الشاي (اختياري)"]])
	note(Vector3(14, 0, 26), "Soldier's Letter", "رسالة جندي",
		"A letter begun and never sent: 'I do not know why we are fighting. I only know I cannot stop.'",
		"رسالة بدأت ولم تُرسَل: 'لا أعرف لماذا نقاتل. أعرف فقط أنني لا أستطيع التوقف.'", "ch10_letter")
	note(Vector3(-16, 0, 22), "Teacup", "فنجان شاي",
		"A single teacup left on the ground, still warm. Someone fled in a hurry.",
		"فنجان شاي واحد تُرك على الأرض، ما زال دافئًا. هرب أحدهم مسرعًا.", "ch10_cup")
	await hook("ch10_wu_plan",
		"Wu lays out his plan: gather everyone who will stand with them and make the last stand at the Corridor of Elders.",
		"يعرض وو خطته: أن يجمعوا كل من يقف معهم ويخوضوا المواجهة الأخيرة في ممر الحكماء.",
		Vector3(0, 6, 40), Vector3(0, 1.5, 30))
	await say([
		ln("wu", "We cannot beat Chen's army alone. We must be many, and we must choose our ground.", "لا نستطيع هزيمة جيش تشِن وحدنا. يجب أن نكون كثيرين، وأن نختار أرضنا."),
		me("The Corridor of Elders. Then let us bring the people there.", "ممر الحكماء. إذن لنُحضر الناس إلى هناك."),
	])
	goal_done(0)
	# 1) citizens: escort the villagers
	var vil := Minifig.new()
	isl.add_child(vil)
	vil.build({"suit": Color(0.6, 0.5, 0.3), "style": "bare", "hair": Color(0.2, 0.15, 0.1)})
	vil.position = Vector3(-30, 0.2, 34)
	if not await escort(vil, [Vector3(-20, 0, 28), Vector3(-8, 0, 22), Vector3(0, 0, 16)], "anacondrai", "Escort the villagers", "رافق القرويين", 100.0):
		return false
	vil.queue_free()
	GameState.flags["ch10_ally_citizens"] = true
	goal_done(1)
	isl.hud.toast(L("The citizens will rebuild the barricades.", "سيعيد المواطنون بناء الحواجز."))
	checkpoint()
	# 2) Serpentine: a lever gate and a quiet approach, then ask them (stone)
	isl.hud.set_objective(L("The serpent gate is shut: pull the lever.", "بوابة الثعابين مغلقة: اسحب الذراع."))
	if not await lever_door(Vector3(-56, 0, -34), Vector3(9, 4, 1), Vector3(-62, 0, -32)):
		return false
	var w: Array = [{"c": Vector3(-56, 0, -42), "amp": Vector3(5, 0, 0), "speed": 1.3, "r": 3.2}, {"c": Vector3(-50, 0, -48), "amp": Vector3(0, 0, 4), "speed": 1.7, "r": 3.0}]
	if not await stealth([Vector3(-54, 0, -40), Vector3(-48, 0, -46)], w, Vector3(-56, 0.2, -36), "Approach the Serpentine quietly", "اقترب من السيربنتين بهدوء"):
		return false
	var st := place_stone(Vector3(-48, 0, -50), Color(0.4, 0.9, 0.3), "Ask the Serpentine for help", "اطلب العون من السيربنتين")
	if not await wait_stone(st):
		return false
	GameState.flags["ch10_ally_serpentine"] = true
	goal_done(2)
	isl.hud.toast(L("The Serpentine will poison the cultists' advance.", "سيُعيق السيربنتين تقدّم الأتباع بسمّهم."))
	checkpoint()
	# 3) Masters: a gate, a skirmish, then ask them
	isl.hud.set_objective(L("The Masters are pinned down: open the gate (crate on the plate).", "الماسترز محاصَرون: افتح البوابة (صندوق على اللوح)."))
	if not await plate_door(Vector3(36, 0, -20), Vector3(8, 4, 1), Vector3(30, 0, -14), [Vector3(40, 0.7, -12), Vector3(32, 0.7, -24)]):
		return false
	if not await waves([["anacondrai", "anacondrai"], ["anacondrai", "elite"]], Vector3(36, 0, -26), 7.0, "Break the siege", "اكسر الحصار"):
		return false
	var st2 := place_stone(Vector3(36, 0, -28), Color(1.0, 0.8, 0.3), "Rally the Masters", "اجمع الماسترز")
	if not await wait_stone(st2):
		return false
	GameState.flags["ch10_ally_masters"] = true
	goal_done(3)
	if flag_set("ch10_letter"):
		goal_done(4)
		side_reward("ch10_letter", "the soldier's letter", "رسالة الجندي")
	if flag_set("ch10_cup"):
		goal_done(5)
		side_reward("ch10_cup", "the teacup", "فنجان الشاي")
	goals_clear()
	return isl._alive()

func _defend_wave(points: Array, w: int) -> int:
	var sizes: Array = [2, 2, 3, 3]
	var foes: Array = []
	for p in points:
		var pp := p as DefensePoint
		for k in int(sizes[w]):
			var kind := "elite" if (w >= 2 and k == 0) else "anacondrai"
			foes.append(isl.spawn_enemy(kind, pp.global_position + Vector3(randf_range(-3.0, 3.0), 0.3, -7.0)))
	while ok_alive():
		await isl.get_tree().create_timer(0.25).timeout
		if not ok_alive():
			return -1
		for p in points:
			if (p as DefensePoint).hp <= 0.0:
				return 0
		var left := 0
		for f in foes:
			if is_instance_valid(f) and (f as Fighter).state != Fighter.S.DEAD:
				left += 1
		if left == 0:
			return 1
	return -1

# Station the allies at three gates, then hold the Corridor for four waves. A lost gate only repeats that wave.
func _b1() -> bool:
	goals([["Station allies at the three gates (USE the gold pads)", "عيّن الحلفاء على البوابات الثلاث (USE على الألواح الذهبية)"],
		["Start the defense", "ابدأ الدفاع"], ["Hold the Corridor for four waves", "احمِ الممر لأربع موجات"], ["Keep every gate standing", "أبقِ كل بوابة صامدة"]])
	await hook("ch10_army",
		"Chen's army of Anacondrai gathers at the mouth of the Corridor of Elders for the last battle.",
		"يحتشد جيش الأناكوندراي التابع لتشِن عند مدخل ممر الحكماء للمعركة الأخيرة.",
		Vector3(0, 12, 22), Vector3(0, 3, -10))
	await say([
		ln("kai", "This is it. Everything we fought for.", "هذه هي. كل ما قاتلنا من أجله."),
		me("Together. Nobody falls behind. Nobody fights alone.", "معًا. لا أحد يتأخر. لا أحد يقاتل وحده."),
	])
	var kinds := _ally_kinds()
	var pos: Array = [Vector3(-14, 0, -4), Vector3(0, 0, -14), Vector3(14, 0, -4)]
	var names: Array = [["Left gate", "البوابة اليسرى"], ["Center gate", "البوابة الوسطى"], ["Right gate", "البوابة اليمنى"]]
	var points: Array = []
	var slots: Array = []
	for i in 3:
		var dp := DefensePoint.new()
		dp.label_en = str(names[i][0])
		dp.label_ar = str(names[i][1])
		dp.position = pos[i]
		isl.add_child(dp)
		points.append(dp)
		var sl := DefenseSlot.new()
		sl.point = dp
		sl.choices = kinds
		sl.position = (pos[i] as Vector3) + Vector3(0, 0, 3.5)
		isl.add_child(sl)
		slots.append(sl)
	isl.hud.set_objective(L("Station an ally group at each gate (USE the gold pads), then start the defense.", "عيّن مجموعة حلفاء عند كل بوابة (USE على الألواح الذهبية)، ثم ابدأ الدفاع."))
	var go := place_stone(Vector3(0, 0, 6), Color(1.0, 0.6, 0.2), "Start the defense", "ابدأ الدفاع")
	if not await wait_stone(go):
		return false
	goal_done(0)
	goal_done(1)
	for s in slots:
		(s as DefenseSlot).locked = true
	var w := 0
	while w < 4:
		await isl.hud.banner(L("Wave %d / 4", "الموجة %d / 4") % (w + 1), 1.0)
		var r := await _defend_wave(points, w)
		if r < 0:
			return false
		if r == 0:
			isl.clear_enemies()
			await isl.hud.banner(L("A gate fell! Regroup and repeat the wave.", "سقطت بوابة! أعيدوا التجمع وكرروا الموجة."), 1.4)
			for p in points:
				(p as DefensePoint).reset_hp()
			continue
		w += 1
		checkpoint()
	goal_done(2)
	var all_ok := true
	for p in points:
		if (p as DefensePoint).hp < (p as DefensePoint).max_hp * 0.5:
			all_ok = false
	if all_ok:
		goal_done(3)
		side_reward("ch10_gates", "all gates held", "صمدت كل البوابات")
	for p in points:
		(p as DefensePoint).queue_free()
	for s in slots:
		(s as DefenseSlot).queue_free()
	goals_clear()
	return isl._alive()

func _b2() -> bool:
	goals([["Defeat Master Chen", "اهزم الماستر تشِن"], ["Hold on until help arrives (phase 2)", "اصمد حتى يصل العون (المرحلة 2)"],
		["Hold Chen back while the spell is prepared (phase 3)", "اصمدوا أمام تشِن بينما تُجهَّز التعويذة (المرحلة 3)"]])
	await say([ln("chen", "You have beaten my soldiers. Now meet what they were guarding.", "هزمتم جنودي. والآن واجهوا ما كانوا يحرسونه.")])
	isl.chen.visible = false
	var b: Boss = isl.spawn_boss("chen", Vector3(0, 0.3, -16))
	await isl.hud.banner(b.display_name, 1.6)
	isl.hud.set_objective(L("Defeat Master Chen!", "اهزم الماستر تشِن!"))
	var allies := false
	var idea := false
	while true:
		await isl.get_tree().create_timer(0.2).timeout
		if not ok_alive():
			return false
		if not is_instance_valid(b) or b.state == Fighter.S.DEAD:
			break
		if b.phase >= 2 and not allies:
			allies = true
			goal_done(0)
			freeze_foes(true)
			await hook("ch10_allies",
				"The old Serpentine tribes arrive to stand with the people of Ninjago against Chen's army.",
				"تصل قبائل السيربنتين القديمة لتقف مع أهل نينجاجو ضد جيش تشِن.",
				Vector3(0, 7, 14), Vector3(0, 2, -4))
			freeze_foes(false)
			isl.add_companion("general", Vector3(6, 0.3, 4))
			isl.add_companion("general_b", Vector3(0, 0.3, 8))
			isl.hud.toast(L("Allies joined the fight!", "انضم الحلفاء إلى المعركة!"))
			goal_done(1)
		if b.phase >= 3 and not idea:
			idea = true
			freeze_foes(true)
			await hook("ch10_pythor_idea",
				"Pythor arrives with the Book of Spells: one spell could end the war, but Garmadon must banish himself to the Cursed Realm to call back the first Anacondrai generals.",
				"يصل بايثور بكتاب التعاويذ: تعويذة واحدة قد تنهي الحرب، لكن على غارمادون أن ينفي نفسه إلى عالم اللعنة ليستدعي جنرالات الأناكوندراي الأوائل.",
				Vector3(-8, 4, 8), Vector3(0, 1.5, -2))
			freeze_foes(false)
			isl.add_companion("pythor", Vector3(-6, 0.3, 4))
	isl.clear_enemies()
	goal_done(2)
	GameState.skill_points += 3
	GameState.points += 1000
	GameState.add_xp(400)
	checkpoint()
	return isl._alive()

# Garmadon's last moments: he must stay inside the spell circle while the cultists try to break it.
func _b3() -> bool:
	goals([["Step into the circle", "ادخل الدائرة"], ["Hold the circle until the spell is read", "اثبت في الدائرة حتى تُقرأ التعويذة"],
		["Complete the banishment", "أكمل النفي"]])
	await hook("ch10_garmadon_ritual",
		"Pythor opens the Book of Spells. Garmadon steps into the circle: the spell needs him to banish himself.",
		"يفتح بايثور كتاب التعاويذ. يخطو غارمادون إلى الدائرة: التعويذة تحتاج إلى أن ينفي نفسه.",
		Vector3(0, 6, 14), Vector3(0, 1.5, -4))
	await say([
		ln("pythor", "It must be someone who carries the curse and chooses it. It must be you.", "يجب أن يكون من يحمل اللعنة ويختارها. يجب أن تكون أنت."),
		me("Then I choose it. Keep them off me while I read.", "إذن أختارها. أبعدوهم عني بينما أقرأ."),
	])
	goal_done(0)
	if not await ritual(Vector3(0, 0, -4), 4.5, 40.0, "anacondrai", "Hold the circle", "اثبت في الدائرة"):
		return false
	goal_done(1)
	checkpoint()
	await hook("ch10_garmadon",
		"Garmadon reads the spell and banishes himself. The spirits of the first Anacondrai generals rise, curse Chen's cultists and drag them into the Cursed Realm.",
		"يقرأ غارمادون التعويذة وينفي نفسه. ترتفع أرواح جنرالات الأناكوندراي الأوائل، فتلعن أتباع تشِن وتجرّهم إلى عالم اللعنة.",
		Vector3(0, 8, 18), Vector3(0, 3, -12))
	goal_done(2)
	goals_clear()
	return isl._alive()

func _b4() -> bool:
	goals([["See the cursed army taken away", "شاهد الجيش الملعون يُقتاد"], ["Share the victory", "شاركوا النصر"], ["Say goodbye to Skylor", "ودّع سكايلور"], ["See the island at dawn", "شاهد الجزيرة عند الفجر"]])
	await hook("ch10_victory",
		"The cursed army is gone. A statue of Garmadon is raised in the Corridor, and Lloyd burns the Book of Spells.",
		"اختفى الجيش الملعون. يُنصب تمثال لغارمادون في الممر، ويحرق لويد كتاب التعاويذ.",
		Vector3(-8, 6, 12), Vector3(0, 2, -8))
	GameState.award("chen_defeated")
	await say([
		ln("kai", "It is really over. I can hardly believe it.", "انتهى الأمر فعلًا. بالكاد أصدق."),
		ln("jay", "I want it on record that I was very brave and also very scared.", "أريد أن يُسجَّل أنني كنت شجاعًا جدًّا وخائفًا جدًّا."),
		ln("cole", "Noted. Both are true.", "مُسجَّل. كلاهما صحيح."),
		ln("zane", "P.I.X.A.L. and I are already planning the cleanup. Everything must be accounted for.", "بيكسال وأنا نخطط للتنظيف بالفعل. يجب إحصاء كل شيء."),
	])
	goal_done(1)
	await hook("ch10_skylor_leaves",
		"Skylor says goodbye and leaves the island, to find her own way after all that happened.",
		"تودّع سكايلور الجميع وتغادر الجزيرة لتجد طريقها بعد كل ما حدث.",
		Vector3(6, 3, 6), Vector3(0, 1.5, 0))
	await say([
		ln("skylor", "I have to go. I need to learn who I am when I am not Chen's daughter.", "يجب أن أذهب. أحتاج أن أعرف من أكون حين لا أكون ابنة تشِن."),
		ln("kai", "Then go. And come back when you know.", "إذن اذهبي. وعودي حين تعرفين."),
	])
	goal_done(2)
	isl.remove_companion("skylor")
	await hook("ch10_ending",
		"Dawn over the island. The ninja leave together, with one empty seat they intend to fill.",
		"فجر فوق الجزيرة. يغادر النينجا معًا، ومقعد فارغ ينوون ملأه.",
		Vector3(0, 14, 40), Vector3(0, 3, -10))
	goal_done(3)
	await say([nr("And so the Tournament of Elements came to an end.", "وهكذا انتهت بطولة العناصر.")])
	await isl.hud.banner(L("THE END", "النهاية"), 3.0)
	GameState.chapter_done = true
	var lines: Array = [L("Thank you for playing!", "شكرًا للعب!"), L("Total points: %d", "مجموع النقاط: %d") % GameState.points]
	jade_if(10, ["ch10_letter", "ch10_cup"], "The Corridor of Elders", "ممر الحكماء")
	goals_clear()
	return await finish(1500.0, lines)
