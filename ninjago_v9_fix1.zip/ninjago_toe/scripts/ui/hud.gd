class_name Hud
extends CanvasLayer
## In-game HUD: health, level, coins, objective, banners, enemy bars,
## touch controls, dialogue, pause menu and defeat screen.

var controls: TouchControls
var dialogue: DialogueBox
var player: Fighter
var hud_root: Control
var modal_root: Control
var hp_bar: ProgressBar
var name_lbl: Label
var obj_lbl: Label
var goals_lbl: Label
var coin_lbl: Label
var banner_lbl: Label
var pause_panel: Control
var defeat_panel: Control
var quality_btn: Button
var enemy_bars := {}

func _ready() -> void:
	layer = 10
	process_mode = Node.PROCESS_MODE_ALWAYS
	hud_root = _full_rect()
	add_child(hud_root)
	controls = TouchControls.new()
	hud_root.add_child(controls)
	hp_bar = ProgressBar.new()
	hp_bar.position = Vector2(110, 22)
	hp_bar.size = Vector2(300, 26)
	hp_bar.show_percentage = false
	var fill := StyleBoxFlat.new()
	fill.bg_color = Color(0.2, 0.8, 0.3)
	hp_bar.add_theme_stylebox_override("fill", fill)
	hud_root.add_child(hp_bar)
	name_lbl = _label(26)
	name_lbl.position = Vector2(110, 52)
	hud_root.add_child(name_lbl)
	coin_lbl = _label(28)
	coin_lbl.anchor_left = 1.0
	coin_lbl.anchor_right = 1.0
	coin_lbl.offset_left = -320
	coin_lbl.offset_right = -20
	coin_lbl.offset_top = 20
	coin_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	hud_root.add_child(coin_lbl)
	obj_lbl = _label(26)
	obj_lbl.anchor_left = 0.3
	obj_lbl.anchor_right = 0.75
	obj_lbl.offset_top = 70
	obj_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	obj_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	hud_root.add_child(obj_lbl)
	goals_lbl = _label(22)
	goals_lbl.position = Vector2(110, 96)
	goals_lbl.size = Vector2(430, 200)
	goals_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	goals_lbl.visible = false
	hud_root.add_child(goals_lbl)
	modal_root = _full_rect()
	add_child(modal_root)
	dialogue = DialogueBox.new()
	modal_root.add_child(dialogue)
	banner_lbl = _label(56)
	banner_lbl.anchor_right = 1.0
	banner_lbl.anchor_top = 0.28
	banner_lbl.anchor_bottom = 0.45
	banner_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	banner_lbl.visible = false
	modal_root.add_child(banner_lbl)
	_build_pause()
	_build_defeat()
	_build_extras()

func _full_rect() -> Control:
	var c := Control.new()
	c.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return c

func _label(size: int) -> Label:
	var l := Label.new()
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_constant_override("outline_size", 6)
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l

func _panel(title: String) -> Array:
	var holder := CenterContainer.new()
	holder.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	holder.visible = false
	var pc := PanelContainer.new()
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.05, 0.05, 0.1, 0.94)
	sb.set_corner_radius_all(16)
	sb.set_content_margin_all(24)
	pc.add_theme_stylebox_override("panel", sb)
	holder.add_child(pc)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 12)
	pc.add_child(vb)
	var t := _label(40)
	t.text = title
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	vb.add_child(t)
	modal_root.add_child(holder)
	return [holder, vb]

func _btn(parent: Control, text: String, cb: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(380, 70)
	b.add_theme_font_size_override("font_size", 30)
	b.pressed.connect(cb)
	parent.add_child(b)
	return b

func _quality_text() -> String:
	return Loc.t("quality") % Loc.t("q%d" % int(GameState.settings["quality"]))

func _build_pause() -> void:
	var r := _panel(Loc.t("pause"))
	pause_panel = r[0]
	var vb: Control = r[1]
	_btn(vb, Loc.t("resume"), close_pause)
	_btn(vb, Loc.t("upgrades"), open_upgrades)
	_btn(vb, Loc.t("map"), open_map)
	_btn(vb, Loc.t("inventory"), open_inventory)
	_btn(vb, Loc.t("save"), func():
		GameState.save_game()
		banner(Loc.t("saved"), 0.8))
	quality_btn = _btn(vb, _quality_text(), func():
		GameState.settings["quality"] = (int(GameState.settings["quality"]) + 1) % 3
		GameState.save_settings()
		quality_btn.text = _quality_text()
		var sc := get_tree().current_scene
		if sc != null and sc.has_method("apply_quality"):
			sc.apply_quality())
	vb.add_child(AudioSettings.new())
	_btn(vb, Loc.t("menu"), func():
		GameState.save_game()
		get_tree().paused = false
		get_tree().change_scene_to_file("res://scenes/main_menu.tscn"))

func _build_defeat() -> void:
	var r := _panel(Loc.t("defeat"))
	defeat_panel = r[0]
	var vb: Control = r[1]
	_btn(vb, Loc.t("retry"), func():
		get_tree().paused = false
		get_tree().reload_current_scene())
	_btn(vb, Loc.t("menu"), func():
		get_tree().paused = false
		get_tree().change_scene_to_file("res://scenes/main_menu.tscn"))

func bind(p: Fighter) -> void:
	player = p
	controls.player = p

func open_pause() -> void:
	if get_tree().paused or defeat_panel.visible:
		return
	get_tree().paused = true
	controls.set_enabled(false)
	pause_panel.visible = true

func close_pause() -> void:
	pause_panel.visible = false
	get_tree().paused = false
	controls.set_enabled(true)

func show_defeat() -> void:
	controls.set_enabled(false)
	defeat_panel.visible = true

func set_gameplay_visible(on: bool) -> void:
	hud_root.visible = on
	controls.set_enabled(on)

func set_objective(t: String) -> void:
	obj_lbl.text = t

## Objective list on screen: items = [{"t": text, "done": bool}, ...] (empty hides it).
func set_goals(items: Array) -> void:
	var s := ""
	for it in items:
		s += ("[x] " if bool(it["done"]) else "[ ] ") + str(it["t"]) + "\n"
	goals_lbl.text = s.strip_edges()
	goals_lbl.visible = not items.is_empty()

func banner(text: String, secs := 2.0) -> void:
	banner_lbl.text = text
	banner_lbl.modulate.a = 0.0
	banner_lbl.visible = true
	var tw := create_tween()
	tw.tween_property(banner_lbl, "modulate:a", 1.0, 0.25)
	tw.tween_interval(secs)
	tw.tween_property(banner_lbl, "modulate:a", 0.0, 0.35)
	await tw.finished
	banner_lbl.visible = false

func _process(_d: float) -> void:
	if player != null and is_instance_valid(player):
		hp_bar.max_value = player.max_health
		hp_bar.value = player.health
		name_lbl.text = "%s  %s" % [player.display_name, Loc.t("level") % GameState.level]
	coin_lbl.text = "%d  |  %d pts" % [GameState.coins, GameState.points]
	_update_enemy_bars()
	_update_extras()

func _update_enemy_bars() -> void:
	var cam := get_viewport().get_camera_3d()
	if cam == null or not hud_root.visible:
		for b in enemy_bars.values():
			b.visible = false
		return
	var seen := {}
	for n in get_tree().get_nodes_in_group("enemies"):
		var e := n as Fighter
		if e == null or e is Boss:
			continue
		var id := e.get_instance_id()
		seen[id] = true
		var bar: ProgressBar = enemy_bars.get(id)
		if bar == null:
			bar = ProgressBar.new()
			bar.show_percentage = false
			bar.size = Vector2(80, 8)
			bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
			var fill := StyleBoxFlat.new()
			fill.bg_color = Color(0.9, 0.2, 0.2)
			bar.add_theme_stylebox_override("fill", fill)
			hud_root.add_child(bar)
			enemy_bars[id] = bar
		var wp := e.global_position + Vector3(0, 2.1, 0)
		bar.visible = not cam.is_position_behind(wp)
		bar.position = cam.unproject_position(wp) - Vector2(40, 0)
		bar.max_value = e.max_health
		bar.value = e.health
	for id in enemy_bars.keys():
		if not seen.has(id):
			enemy_bars[id].queue_free()
			enemy_bars.erase(id)

# ---------------------------------------------------------------- v2 -------
signal results_closed

var prompt_lbl: Label
var toast_lbl: Label
var boss_bar: ProgressBar
var boss_lbl: Label
var fade_rect: ColorRect
var boss: Fighter
var _toast_tw: Tween

func _build_extras() -> void:
	prompt_lbl = _label(30)
	prompt_lbl.anchor_left = 0.28
	prompt_lbl.anchor_right = 0.62
	prompt_lbl.anchor_top = 0.74
	prompt_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	prompt_lbl.add_theme_color_override("font_color", Color(1, 0.9, 0.3))
	prompt_lbl.visible = false
	hud_root.add_child(prompt_lbl)
	boss_lbl = _label(28)
	boss_lbl.anchor_left = 0.25
	boss_lbl.anchor_right = 0.75
	boss_lbl.offset_top = 104
	boss_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	boss_lbl.visible = false
	hud_root.add_child(boss_lbl)
	boss_bar = ProgressBar.new()
	boss_bar.anchor_left = 0.25
	boss_bar.anchor_right = 0.75
	boss_bar.offset_top = 140
	boss_bar.custom_minimum_size = Vector2(0, 22)
	boss_bar.show_percentage = false
	boss_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var fill := StyleBoxFlat.new()
	fill.bg_color = Color(0.8, 0.1, 0.5)
	boss_bar.add_theme_stylebox_override("fill", fill)
	boss_bar.visible = false
	hud_root.add_child(boss_bar)
	toast_lbl = _label(26)
	toast_lbl.anchor_left = 0.2
	toast_lbl.anchor_right = 0.8
	toast_lbl.offset_top = 176
	toast_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	toast_lbl.visible = false
	modal_root.add_child(toast_lbl)
	fade_rect = ColorRect.new()
	fade_rect.color = Color(0, 0, 0, 0)
	fade_rect.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	fade_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	modal_root.add_child(fade_rect)
	GameState.achievement_unlocked.connect(func(id: String):
		toast(Loc.pick(["Achievement: ", "إنجاز: "]) + Loc.pick(AchievementDB.DATA[id]["name"])))

func toast(text: String) -> void:
	toast_lbl.text = text
	toast_lbl.modulate.a = 1.0
	toast_lbl.visible = true
	if _toast_tw != null:
		_toast_tw.kill()
	_toast_tw = create_tween()
	_toast_tw.tween_interval(2.4)
	_toast_tw.tween_property(toast_lbl, "modulate:a", 0.0, 0.5)

func set_prompt(t: String) -> void:
	prompt_lbl.text = ("USE: " + t) if t != "" else ""
	prompt_lbl.visible = t != ""

func set_boss(b: Fighter) -> void:
	boss = b
	boss_lbl.text = b.display_name if b != null else ""

func fade(a: float, secs: float) -> void:
	var tw := create_tween()
	tw.tween_property(fade_rect, "color:a", a, secs)
	await tw.finished

func _update_extras() -> void:
	var show := boss != null and is_instance_valid(boss) and boss.state != Fighter.S.DEAD and hud_root.visible
	boss_bar.visible = show
	boss_lbl.visible = show
	if show:
		boss_bar.max_value = boss.max_health
		boss_bar.value = boss.health

func show_results(title: String, lines: Array) -> void:
	var r := _panel(title)
	var holder: Control = r[0]
	var vb: Control = r[1]
	for l in lines:
		var lb := _label(28)
		lb.text = str(l)
		vb.add_child(lb)
	_btn(vb, Loc.t("ok"), func(): results_closed.emit())
	controls.set_enabled(false)
	holder.visible = true
	await results_closed
	holder.queue_free()
	controls.set_enabled(hud_root.visible)

func open_upgrades() -> void:
	var up := UpgradeScreen.new()
	modal_root.add_child(up)
	up.open(player)
	await up.closed
	up.queue_free()

func open_map() -> void:
	var mp := MapScreen.new()
	modal_root.add_child(mp)
	mp.open(get_tree().current_scene)
	await mp.closed
	mp.queue_free()

func open_inventory() -> void:
	var inv := InventoryScreen.new()
	modal_root.add_child(inv)
	inv.open(get_tree().current_scene)
	await inv.closed
	inv.queue_free()
