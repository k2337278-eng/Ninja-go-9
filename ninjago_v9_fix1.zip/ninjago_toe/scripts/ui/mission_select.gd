extends Control
## Replay any unlocked chapter. Shows best rating per chapter.

func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var bg := ColorRect.new()
	bg.color = Color(0.07, 0.07, 0.14)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	var vb := VBoxContainer.new()
	vb.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	vb.offset_left = 40
	vb.offset_right = -40
	vb.offset_top = 20
	vb.offset_bottom = -20
	vb.add_theme_constant_override("separation", 8)
	add_child(vb)
	var title := Label.new()
	title.text = Loc.t("missions")
	title.add_theme_font_size_override("font_size", 40)
	vb.add_child(title)
	var sc := ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vb.add_child(sc)
	var list := VBoxContainer.new()
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list.add_theme_constant_override("separation", 8)
	sc.add_child(list)
	var firsts: Array = Chapters.first_steps()
	var names: Array = Chapters.chapter_names()
	for i in firsts.size():
		var first: int = firsts[i]
		var unlocked := GameState.max_step >= first
		var b := Button.new()
		var rating := str(GameState.ratings.get(str(i + 1), "-"))
		b.text = "%d. %s   [%s]" % [i + 1, Loc.pick(names[i]), rating if unlocked else "X"]
		b.custom_minimum_size = Vector2(0, 66)
		b.add_theme_font_size_override("font_size", 26)
		b.disabled = not unlocked
		b.pressed.connect(func():
			GameState.story_step = first
			GameState.save_game()
			get_tree().change_scene_to_file("res://scenes/island.tscn"))
		list.add_child(b)
	var back := Button.new()
	back.text = Loc.t("back")
	back.custom_minimum_size = Vector2(0, 60)
	back.add_theme_font_size_override("font_size", 26)
	back.pressed.connect(func(): get_tree().change_scene_to_file("res://scenes/main_menu.tscn"))
	vb.add_child(back)
