class_name TouchControls
extends Control
## Virtual joystick (left), camera-drag (right), action buttons, pause.
## Uses raw screen-touch events so several fingers work at once. On desktop,
## project setting emulate_touch_from_mouse lets the mouse drive it.

signal action_pressed(action: String)
signal action_released(action: String)
signal look(delta: Vector2)

const JOY_R := 90.0

var enabled := true
var player: Fighter
var move_vector := Vector2.ZERO
var _joy_id := -1
var _joy_origin := Vector2.ZERO
var _joy_pos := Vector2.ZERO
var _look_id := -1
var _btn_touch := {}
var _buttons: Array = []
var _pause_pos := Vector2(60, 60)
var _last_size := Vector2.ZERO
var _joy_default := Vector2(180, 550)

func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE

func _layout() -> void:
	var s := get_viewport_rect().size
	_last_size = s
	var ins := _insets()
	var sx := s.x - ins.y
	_pause_pos = Vector2(60.0 + ins.x, 60.0)
	_joy_default = Vector2(180.0 + ins.x, s.y - 170.0)
	# thumb arc around the big attack button (right side); sizes are generous for fat thumbs
	_buttons = [
		{"id": "light", "label": "ATK", "pos": Vector2(sx - 150, s.y - 150), "r": 82.0, "cd": "", "col": Color(0.95, 0.3, 0.25)},
		{"id": "jump", "label": "JMP", "pos": Vector2(sx - 125, s.y - 310), "r": 62.0, "cd": "", "col": Color(0.35, 0.85, 0.4)},
		{"id": "dodge", "label": "DGE", "pos": Vector2(sx - 295, s.y - 245), "r": 58.0, "cd": "dodge", "col": Color(0.35, 0.65, 1.0)},
		{"id": "heavy", "label": "HVY", "pos": Vector2(sx - 310, s.y - 100), "r": 58.0, "cd": "", "col": Color(1.0, 0.65, 0.2)},
		{"id": "power", "label": "PWR", "pos": Vector2(sx - 440, s.y - 175), "r": 56.0, "cd": "ability", "col": Color(0.75, 0.4, 1.0)},
		{"id": "spin", "label": "SPN", "pos": Vector2(sx - 420, s.y - 305), "r": 50.0, "cd": "spin", "col": Color(0.3, 0.9, 0.85)},
		{"id": "block", "label": "BLK", "pos": Vector2(sx - 455, s.y - 66), "r": 46.0, "cd": "", "col": Color(0.7, 0.72, 0.78)},
		{"id": "lock", "label": "LCK", "pos": Vector2(sx - 270, s.y - 385), "r": 46.0, "cd": "", "col": Color(1.0, 1.0, 1.0)},
		{"id": "tag", "label": "TAG", "pos": Vector2(sx - 445, s.y - 425), "r": 46.0, "cd": "tag", "col": Color(0.4, 0.9, 0.8)},
		{"id": "interact", "label": "USE", "pos": Vector2(sx - 110, s.y - 430), "r": 48.0, "cd": "", "col": Color(1.0, 0.9, 0.3)},
	]

func reset() -> void:
	for id in _btn_touch.keys():
		action_released.emit(_btn_touch[id])
	_btn_touch.clear()
	_joy_id = -1
	_look_id = -1
	move_vector = Vector2.ZERO

func set_enabled(on: bool) -> void:
	enabled = on
	if not on:
		reset()

func _input(event: InputEvent) -> void:
	if not enabled or not is_visible_in_tree():
		return
	if event is InputEventScreenTouch:
		var e := event as InputEventScreenTouch
		if e.pressed:
			_press(e.index, e.position)
		else:
			_release(e.index)
	elif event is InputEventScreenDrag:
		var d := event as InputEventScreenDrag
		_drag(d.index, d.position, d.relative)

func _press(idx: int, pos: Vector2) -> void:
	if pos.distance_to(_pause_pos) < 46.0:
		action_pressed.emit("pause")
		return
	for b in _buttons:
		if pos.distance_to(b["pos"]) <= float(b["r"]) * 1.15:
			_btn_touch[idx] = b["id"]
			Input.vibrate_handheld(18)
			action_pressed.emit(b["id"])
			return
	if pos.x < _last_size.x * 0.42 and _joy_id == -1:
		_joy_id = idx
		_joy_origin = pos
		_joy_pos = pos
	elif _look_id == -1:
		_look_id = idx

func _release(idx: int) -> void:
	if _btn_touch.has(idx):
		action_released.emit(_btn_touch[idx])
		_btn_touch.erase(idx)
	if idx == _joy_id:
		_joy_id = -1
		move_vector = Vector2.ZERO
	if idx == _look_id:
		_look_id = -1

func _drag(idx: int, pos: Vector2, rel: Vector2) -> void:
	if idx == _joy_id:
		_joy_pos = pos
		var v := (pos - _joy_origin).limit_length(JOY_R)
		move_vector = Vector2.ZERO if v.length() < 12.0 else v / JOY_R
	elif idx == _look_id:
		look.emit(rel)

func _process(_d: float) -> void:
	if get_viewport_rect().size != _last_size:
		_layout()
	queue_redraw()

func _draw() -> void:
	if not is_visible_in_tree():
		return
	var font := ThemeDB.fallback_font
	var s := _last_size
	var base := _joy_origin if _joy_id != -1 else _joy_default
	var knob := _joy_pos if _joy_id != -1 else base
	draw_circle(base, JOY_R, Color(1, 1, 1, 0.12))
	draw_arc(base, JOY_R, 0, TAU, 32, Color(1, 1, 1, 0.35), 3.0)
	draw_circle(base + (knob - base).limit_length(JOY_R), 38.0, Color(1, 1, 1, 0.3))
	draw_circle(_pause_pos, 36.0, Color(0, 0, 0, 0.35))
	draw_string(font, _pause_pos + Vector2(-36, 9), "II", HORIZONTAL_ALIGNMENT_CENTER, 72.0, 26)
	var held: Array = _btn_touch.values()
	for b in _buttons:
		var c: Vector2 = b["pos"]
		var r: float = b["r"]
		var col: Color = b["col"]
		var is_held: bool = held.has(b["id"])
		var locked_on: bool = b["id"] == "lock" and _lock_active()
		# dark backing + tinted fill + clear white ring so the buttons read on any background
		draw_circle(c, r, Color(0, 0, 0, 0.42))
		draw_circle(c, r - 4.0, Color(col.r, col.g, col.b, 0.62 if (is_held or locked_on) else 0.30))
		draw_arc(c, r, 0, TAU, 40, Color(1, 1, 1, 0.85), 4.0)
		var lbl: String = b["label"]
		var stolen: bool = player != null and player.power_stolen
		if stolen and b["id"] == "power":
			lbl = "FCS"
		_draw_icon(b["id"], c, r, lbl, font)
		if stolen and b["id"] == "spin":
			draw_circle(c, r - 3.0, Color(0, 0, 0, 0.55))
			draw_line(c + Vector2(-r * 0.5, -r * 0.5), c + Vector2(r * 0.5, r * 0.5), Color(1, 0.3, 0.3), 5.0)
			draw_line(c + Vector2(-r * 0.5, r * 0.5), c + Vector2(r * 0.5, -r * 0.5), Color(1, 0.3, 0.3), 5.0)
		if player != null and b["cd"] != "":
			var f := player.cd_frac(b["cd"])
			if f > 0.0:
				draw_circle(c, r - 3.0, Color(0, 0, 0, 0.5))
				draw_arc(c, r - 4.0, -PI / 2.0, -PI / 2.0 + TAU * f, 32, Color(1, 0.8, 0.2, 0.9), 6.0)

## Simple vector icons for the main buttons; the others show a short label.
func _draw_icon(id: String, c: Vector2, r: float, lbl: String, font: Font) -> void:
	var w := Color(1, 1, 1, 0.95)
	var k := r * 0.45
	match id:
		"light":
			draw_line(c + Vector2(-k, k), c + Vector2(k, -k), w, 6.0)
			draw_line(c + Vector2(-k * 0.2, k * 0.2) + Vector2(-k * 0.45, -k * 0.45), c + Vector2(-k * 0.2, k * 0.2) + Vector2(k * 0.45, k * 0.45), w, 5.0)
		"jump":
			draw_line(c + Vector2(-k, k * 0.3), c + Vector2(0, -k * 0.7), w, 6.0)
			draw_line(c + Vector2(k, k * 0.3), c + Vector2(0, -k * 0.7), w, 6.0)
		"dodge":
			draw_line(c + Vector2(-k, -k * 0.6), c + Vector2(0, 0), w, 5.0)
			draw_line(c + Vector2(-k, k * 0.6), c + Vector2(0, 0), w, 5.0)
			draw_line(c + Vector2(0, -k * 0.6), c + Vector2(k, 0), w, 5.0)
			draw_line(c + Vector2(0, k * 0.6), c + Vector2(k, 0), w, 5.0)
		_:
			draw_string(font, c + Vector2(-r, 9), lbl, HORIZONTAL_ALIGNMENT_CENTER, r * 2.0, 26)

func _lock_active() -> bool:
	var rigs := get_tree().get_nodes_in_group("camera_rig")
	if rigs.is_empty():
		return false
	var rig = rigs[0]
	return rig != null and rig.lock_target != null

## Left/right unsafe margins (notch / rounded corners) converted to viewport units.
func _insets() -> Vector2:
	var win := Vector2(DisplayServer.window_get_size())
	if win.x <= 0.0:
		return Vector2.ZERO
	var sa := DisplayServer.get_display_safe_area()
	var k := get_viewport_rect().size.x / win.x
	return Vector2(maxf(0.0, float(sa.position.x)) * k, maxf(0.0, win.x - float(sa.end.x)) * k)
