class_name InventoryScreen
extends Control
## Inventory: party status, resources, stolen powers, relics, scrolls (re-readable), ratings.

signal closed

const RELICS := [
	["Fire Shrine", "مزار النار"], ["Lightning Shrine", "مزار البرق"], ["Earth Shrine", "مزار الأرض"],
	["Ice Shrine", "مزار الجليد"], ["Energy Shrine", "مزار الطاقة"], ["Ruins Vault", "قبو الأطلال"],
	["Fire Alcove", "تجويف النار"], ["Cliff Top", "قمة الجرف"], ["Hidden Grotto", "الكهف الخفي"],
	["Serpent Ruins", "أطلال الثعابين"], ["Beach Rocks", "صخور الشاطئ"], ["Temple Roof", "سطح المعبد"]]

var isl: Node3D
var content: VBoxContainer
var reader: Label

func open(island: Node3D) -> void:
	isl = island
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var bg := ColorRect.new()
	bg.color = Color(0.03, 0.03, 0.08, 0.97)
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	var vb := VBoxContainer.new()
	vb.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	vb.offset_left = 30
	vb.offset_right = -30
	vb.offset_top = 16
	vb.offset_bottom = -16
	vb.add_theme_constant_override("separation", 8)
	add_child(vb)
	vb.add_child(_lbl(Loc.t("inventory"), 38))
	var sc := ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vb.add_child(sc)
	content = VBoxContainer.new()
	content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	content.add_theme_constant_override("separation", 6)
	sc.add_child(content)
	reader = _lbl("", 24)
	reader.add_theme_color_override("font_color", Color(1, 0.9, 0.5))
	vb.add_child(reader)
	var close := Button.new()
	close.text = Loc.t("close")
	close.custom_minimum_size = Vector2(0, 60)
	close.add_theme_font_size_override("font_size", 26)
	close.pressed.connect(func(): closed.emit())
	vb.add_child(close)
	_build()

func _lbl(text: String, size := 24) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return l

func _head(t: String) -> void:
	var l := _lbl(t, 30)
	l.add_theme_color_override("font_color", Color(1, 0.85, 0.3))
	content.add_child(l)

func _build() -> void:
	_head(Loc.pick(["Party", "الفريق"]))
	var members: Array = [isl.player]
	for c in isl.companions:
		if is_instance_valid(c):
			members.append(c)
	for f in members:
		var st := Loc.pick(["power drained", "القوة مسلوبة"]) if f.power_stolen else Loc.pick(["power ready", "القوة جاهزة"])
		content.add_child(_lbl("%s   HP %d/%d   %s" % [f.display_name, int(f.health), int(f.max_health), st]))
	_head(Loc.pick(["Resources", "الموارد"]))
	content.add_child(_lbl(Loc.pick(["Level %d | Coins %d | Points %d | Skill points %d | Weapon Lv %d", "المستوى %d | العملات %d | النقاط %d | نقاط المهارة %d | السلاح %d"]) % [GameState.level, GameState.coins, GameState.points, GameState.skill_points, GameState.weapon_level]))
	content.add_child(_lbl(Loc.pick(["Costume: ", "الزي: "]) + Loc.pick(CostumeDB.DATA[GameState.costume]["name"])))
	content.add_child(_lbl(Loc.pick(["Jadeblades: %d / 10", "قطع Jadeblades: %d / 10"]) % GameState.jade_count()))
	_head(Loc.pick(["Elemental relics", "الآثار العنصرية"]))
	for i in RELICS.size():
		var got := GameState.collected.has(100 + i)
		content.add_child(_lbl(("[x] " if got else "[ ] ") + Loc.pick(RELICS[i])))
	_head(Loc.pick(["Scrolls (tap to read)", "اللفائف (اضغط للقراءة)"]))
	var defs := IslandExtras.scroll_defs()
	for i in defs.size():
		var b := Button.new()
		var got := GameState.collected.has(200 + i)
		b.text = Loc.pick(defs[i][1]) if got else "???"
		b.disabled = not got
		b.custom_minimum_size = Vector2(0, 54)
		b.add_theme_font_size_override("font_size", 24)
		b.pressed.connect(func(): reader.text = Loc.pick(defs[i][2]))
		content.add_child(b)
	_head(Loc.pick(["Chapter ratings", "تقييم الفصول"]))
	var ch_names: Array = Chapters.chapter_names()
	for i in ch_names.size():
		content.add_child(_lbl("%d. %s   [%s]" % [i + 1, Loc.pick(ch_names[i]), str(GameState.ratings.get(str(i + 1), "-"))]))
