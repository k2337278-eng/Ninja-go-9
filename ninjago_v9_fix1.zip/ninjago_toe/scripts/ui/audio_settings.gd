class_name AudioSettings
extends VBoxContainer
## Three volume sliders (voice / music / effects). Values live in GameState.settings["voice"|"music"|"sfx"]
## (0..1, saved with the settings) and are read by Voice, Sfx.apply_music_volume and Sfx.play.

const ROWS := [["voice", "vol_voice", 1.0], ["music", "vol_music", 0.7], ["sfx", "vol_sfx", 1.0]]

func _ready() -> void:
	add_theme_constant_override("separation", 8)
	for r in ROWS:
		_row(str(r[0]), str(r[1]), float(r[2]))

func _row(key: String, loc_key: String, default_v: float) -> void:
	var lbl := Label.new()
	lbl.add_theme_font_size_override("font_size", 28)
	add_child(lbl)
	var sl := HSlider.new()
	sl.min_value = 0.0
	sl.max_value = 1.0
	sl.step = 0.05
	sl.value = float(GameState.settings.get(key, default_v))
	sl.custom_minimum_size = Vector2(440, 52)
	add_child(sl)
	lbl.text = Loc.t(loc_key) % int(sl.value * 100.0)
	sl.value_changed.connect(func(v: float):
		GameState.settings[key] = v
		GameState.save_settings()
		lbl.text = Loc.t(loc_key) % int(v * 100.0)
		if key == "music":
			Sfx.apply_music_volume()
		elif key == "sfx":
			Sfx.play("ui")
		else:
			Voice.stop())
