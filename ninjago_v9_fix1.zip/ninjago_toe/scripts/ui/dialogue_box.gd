class_name DialogueBox
extends Control
## Story dialogue: lines = [[speaker, text], ...]. `await play(lines)` resolves
## when the last line is dismissed by tap / Space / Enter.

signal next_pressed

var panel: PanelContainer
var name_lbl: Label
var txt: Label
var typing := false
var tw: Tween

func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	visible = false
	panel = PanelContainer.new()
	panel.anchor_left = 0.08
	panel.anchor_right = 0.92
	panel.anchor_top = 0.66
	panel.anchor_bottom = 0.96
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.05, 0.05, 0.1, 0.9)
	sb.set_corner_radius_all(14)
	sb.set_content_margin_all(18)
	panel.add_theme_stylebox_override("panel", sb)
	add_child(panel)
	var vb := VBoxContainer.new()
	panel.add_child(vb)
	name_lbl = Label.new()
	name_lbl.add_theme_font_size_override("font_size", 30)
	name_lbl.add_theme_color_override("font_color", Color(1, 0.85, 0.3))
	vb.add_child(name_lbl)
	txt = Label.new()
	txt.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	txt.size_flags_vertical = Control.SIZE_EXPAND_FILL
	txt.add_theme_font_size_override("font_size", 28)
	vb.add_child(txt)

func play(lines: Array) -> void:
	visible = true
	for l in lines:
		name_lbl.text = str(l[0])
		txt.text = str(l[1])
		if l.size() > 3:
			Voice.speak(str(l[2]), str(l[1]), str(l[3]))
		txt.visible_ratio = 0.0
		typing = true
		if tw != null:
			tw.kill()
		tw = create_tween()
		tw.tween_property(txt, "visible_ratio", 1.0, maxf(0.4, txt.text.length() / 45.0))
		tw.finished.connect(func(): typing = false)
		await next_pressed
	Voice.stop()
	visible = false

func _input(event: InputEvent) -> void:
	if not visible:
		return
	var tap := false
	if event is InputEventScreenTouch:
		tap = (event as InputEventScreenTouch).pressed
	elif event is InputEventKey:
		var k := event as InputEventKey
		tap = k.pressed and not k.echo and (k.keycode == KEY_SPACE or k.keycode == KEY_ENTER)
	if not tap:
		return
	get_viewport().set_input_as_handled()
	if typing:
		if tw != null:
			tw.kill()
		txt.visible_ratio = 1.0
		typing = false
	else:
		next_pressed.emit()
