class_name AchievementDB
extends RefCounted
## Stat-based achievements unlock automatically (GameState.stat); the others are
## awarded explicitly by story code via GameState.award(id).

const ORDER := ["first_blood", "warrior", "slayer", "perfect_guard", "spinner", "elementalist",
	"coin_collector", "relic_hunter", "scholar", "explorer", "skilled", "level5", "level10",
	"karlof_duel", "ash_beaten", "friends_again", "titanium_dream", "nya_spy", "clouse_beaten",
	"energy_dragon", "staff_broken", "fire_dragon", "ice_dragon", "pythor_found",
	"jade_master", "chen_defeated", "perfectionist", "fashionista", "completionist"]

const DATA := {
	"first_blood": {"name": ["First Victory", "أول انتصار"], "desc": ["Defeat an enemy", "اهزم عدوًا"], "stat": "kills", "need": 1},
	"warrior": {"name": ["Warrior", "محارب"], "desc": ["Defeat 25 enemies", "اهزم 25 عدوًا"], "stat": "kills", "need": 25},
	"slayer": {"name": ["Tournament Veteran", "محارب مخضرم"], "desc": ["Defeat 100 enemies", "اهزم 100 عدو"], "stat": "kills", "need": 100},
	"perfect_guard": {"name": ["Perfect Guard", "الصدّ المثالي"], "desc": ["5 perfect blocks", "5 صدّات مثالية"], "stat": "perfect_blocks", "need": 5},
	"spinner": {"name": ["Spinner", "الدوّامة"], "desc": ["Use Spinjitzu 10 times", "استخدم السبينجيتزو 10 مرات"], "stat": "spins", "need": 10},
	"elementalist": {"name": ["Elementalist", "سيد العناصر"], "desc": ["Use elemental power 25 times", "استخدم القدرة العنصرية 25 مرة"], "stat": "abilities", "need": 25},
	"coin_collector": {"name": ["Coin Collector", "جامع العملات"], "desc": ["Collect all 20 coins", "اجمع كل العملات (20)"], "stat": "coins_collected", "need": 20},
	"relic_hunter": {"name": ["Relic Hunter", "صائد الآثار"], "desc": ["Find all 12 relics", "اعثر على كل الآثار (12)"], "stat": "relics", "need": 12},
	"scholar": {"name": ["Scholar", "العالِم"], "desc": ["Read all 6 scrolls", "اقرأ كل اللفائف (6)"], "stat": "scrolls", "need": 6},
	"explorer": {"name": ["Explorer", "المستكشف"], "desc": ["Discover all 10 areas", "اكتشف كل المناطق (10)"], "stat": "zones", "need": 10},
	"skilled": {"name": ["Skilled", "ماهر"], "desc": ["Spend 5 skill points", "أنفق 5 نقاط مهارة"], "stat": "skills_spent", "need": 5},
	"level5": {"name": ["Rising Ninja", "نينجا صاعد"], "desc": ["Reach level 5", "بلغ المستوى 5"], "stat": "level", "need": 5},
	"level10": {"name": ["Elite Ninja", "نينجا نخبة"], "desc": ["Reach level 10", "بلغ المستوى 10"], "stat": "level", "need": 10},
	"chen_defeated": {"name": ["Final Victory", "النصر الأخير"], "desc": ["Defeat Master Chen", "اهزم الماستر تشِن"]},
	"karlof_duel": {"name": ["Road Fight", "قتال الطريق"], "desc": ["Face Karlof on the way to the arena", "واجه كارلوف في الطريق إلى الساحة"]},
	"ash_beaten": {"name": ["Ash Beaten", "هزمت آش"], "desc": ["Win Kai's match against Ash", "اربح مباراة كاي ضد آش"]},
	"friends_again": {"name": ["Friends Again", "أصدقاء من جديد"], "desc": ["Win Jay's match against Cole", "اربح مباراة جاي ضد كول"]},
	"titanium_dream": {"name": ["Dream of Titanium", "حلم التيتانيوم"], "desc": ["Meet the Titanium Dragon in Zane's dream", "قابل تنين التيتانيوم في حلم زين"]},
	"nya_spy": {"name": ["Spy", "الجاسوسة"], "desc": ["Sneak through the island as Nya", "تسلّل في الجزيرة بدور نيا"]},
	"clouse_beaten": {"name": ["Clouse Beaten", "هزمت كلاوس"], "desc": ["Defeat Clouse", "اهزم كلاوس"]},
	"energy_dragon": {"name": ["Energy Dragon", "تنين الطاقة"], "desc": ["Unlock Lloyd's energy dragon", "افتح تنين الطاقة للويد"]},
	"staff_broken": {"name": ["Staff Broken", "كسر العصا"], "desc": ["Break the Staff of Elements", "اكسر عصا العناصر"]},
	"fire_dragon": {"name": ["Fire Dragon", "تنين النار"], "desc": ["Summon Kai's elemental dragon", "استدعِ تنين العنصر لكاي"]},
	"ice_dragon": {"name": ["Ice Dragon", "تنين الجليد"], "desc": ["Unlock Zane's dragon", "افتح تنين زين"]},
	"pythor_found": {"name": ["The Long Race", "السباق الطويل"], "desc": ["Reach Pythor before Chen's followers", "اصل إلى بايثور قبل أتباع تشِن"]},
	"jade_master": {"name": ["Jade Master", "سيد اليشم"], "desc": ["Collect all 10 Jadeblade pieces", "اجمع قطع Jadeblades العشر"]},
	"perfectionist": {"name": ["Perfectionist", "المثالي"], "desc": ["Get an S rating", "احصل على تقييم S"]},
	"fashionista": {"name": ["New Look", "مظهر جديد"], "desc": ["Equip a costume", "ارتدِ زيًا جديدًا"]},
	"completionist": {"name": ["Completionist", "المكتمل"], "desc": ["Collect every coin, relic and scroll", "اجمع كل العملات والآثار واللفائف"]},
}
