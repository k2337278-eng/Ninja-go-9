class_name CharacterDB
extends RefCounted
## Data-driven character definitions. To add a ninja (e.g. Skylor), add an entry
## here and to ORDER. No other system needs to change.

const ORDER := ["kai", "jay", "cole", "zane", "lloyd", "nya"]
## Story-only characters (never selectable). Skylor/Pythor/general are allies at set points of the story.
const EXTRA := ["skylor", "pythor", "general", "general_b", "dareth", "wu", "eyezor", "kapau", "chope", "noble"]

## Fallback used while a ninja's elemental power is stolen (story state).
const FOCUS := {"name": ["Focus Strike", "ضربة التركيز"], "kind": "aoe", "sfx": "quake",
	"center": "self", "status": "", "damage": 10.0, "radius": 3.0, "knockback": 5.0,
	"cooldown": 6.0, "color": Color(0.7, 0.7, 0.75)}

const SPIN := {"damage": 9.0, "radius": 2.8, "duration": 1.6, "cooldown": 10.0, "tick": 0.25}

const DATA := {
	"kai": {
		"name": ["Kai", "كاي"], "element": "fire",
		"suit": Color(0.78, 0.08, 0.08),
		"hp": 120.0, "speed": 6.4, "light": 10.0, "heavy": 24.0, "poise": 0.0,
		"ability": {"name": ["Fireball", "كرة النار"], "kind": "projectile", "sfx": "fire",
			"status": "burn", "status_time": 3.0, "damage": 28.0, "range": 16.0, "speed": 18.0,
			"cooldown": 4.0, "radius": 1.0, "splash": 2.2, "pierce": false,
			"color": Color(1.0, 0.45, 0.08)},
	},
	"jay": {
		"name": ["Jay", "جاي"], "element": "lightning",
		"suit": Color(0.1, 0.3, 0.9),
		"hp": 110.0, "speed": 6.8, "light": 9.0, "heavy": 21.0, "poise": 0.0,
		"ability": {"name": ["Lightning Strike", "ضربة البرق"], "kind": "aoe", "sfx": "zap",
			"center": "self", "status": "stun", "status_time": 1.2, "damage": 24.0,
			"radius": 5.5, "knockback": 4.0, "cooldown": 5.0,
			"color": Color(0.5, 0.8, 1.0)},
	},
	"cole": {
		"name": ["Cole", "كول"], "element": "earth",
		"suit": Color(0.14, 0.14, 0.17),
		"hp": 150.0, "speed": 5.4, "light": 12.0, "heavy": 28.0, "poise": 8.0,
		"ability": {"name": ["Earthquake Slam", "ضربة الزلزال"], "kind": "aoe", "sfx": "quake",
			"center": "front", "status": "", "damage": 30.0,
			"radius": 4.2, "knockback": 12.0, "cooldown": 6.0,
			"color": Color(0.55, 0.4, 0.25)},
	},
	"zane": {
		"name": ["Zane", "زين"], "element": "ice",
		"suit": Color(0.92, 0.92, 0.96),
		"hp": 110.0, "speed": 6.6, "light": 9.0, "heavy": 20.0, "poise": 0.0,
		"ability": {"name": ["Ice Shards", "شظايا الجليد"], "kind": "projectile", "sfx": "ice",
			"status": "slow", "status_time": 3.5, "damage": 20.0, "range": 15.0, "speed": 16.0,
			"cooldown": 4.5, "radius": 1.0, "splash": 3.0, "pierce": false,
			"color": Color(0.6, 0.9, 1.0)},
	},
	"lloyd": {
		"name": ["Lloyd", "لويد"], "element": "energy",
		"suit": Color(0.1, 0.65, 0.2),
		"hp": 115.0, "speed": 6.6, "light": 10.0, "heavy": 22.0, "poise": 0.0,
		"ability": {"name": ["Energy Wave", "موجة الطاقة"], "kind": "projectile", "sfx": "energy",
			"status": "", "damage": 22.0, "range": 20.0, "speed": 22.0,
			"cooldown": 4.0, "radius": 1.4, "splash": 0.0, "pierce": true,
			"color": Color(0.4, 1.0, 0.5)},
	},
	"nya": {
		"name": ["Nya", "نيا"], "element": "water",  # VERIFY: Nya's element is a gameplay choice, the story does not depend on it
		"suit": Color(0.1, 0.55, 0.75),
		"hp": 110.0, "speed": 6.9, "light": 9.0, "heavy": 21.0, "poise": 0.0,
		"ability": {"name": ["Water Jet", "تيار الماء"], "kind": "projectile", "sfx": "ice",
			"status": "slow", "status_time": 3.0, "damage": 21.0, "range": 16.0, "speed": 17.0,
			"cooldown": 4.2, "radius": 1.1, "splash": 2.6, "pierce": false,
			"color": Color(0.3, 0.7, 1.0)},
	},
	"pythor": {
		"name": ["Pythor", "بايثور"], "element": "serpent", "playable": false,
		"suit": Color(0.25, 0.5, 0.2),
		"hp": 120.0, "speed": 6.2, "light": 9.0, "heavy": 20.0, "poise": 0.0,
		"ability": {"name": ["Serpent Coil", "التفاف الثعبان"], "kind": "aoe", "sfx": "quake",
			"center": "self", "status": "slow", "status_time": 2.5, "damage": 18.0,
			"radius": 4.5, "knockback": 6.0, "cooldown": 6.0, "color": Color(0.4, 0.8, 0.25)},
	},
	"dareth": {
		"name": ["Dareth", "داريث"], "element": "none", "playable": false,
		"suit": Color(0.45, 0.3, 0.2),
		"hp": 100.0, "speed": 5.4, "light": 8.0, "heavy": 16.0, "poise": 0.0,
		"ability": {"name": ["Karate Chop", "ضربة الكاراتيه"], "kind": "aoe", "sfx": "quake",
			"center": "self", "status": "", "damage": 12.0, "radius": 3.2, "knockback": 5.0, "cooldown": 6.0, "color": Color(0.9, 0.7, 0.3)},
	},
	# v8: real supporting characters (STORY_SPEC v2). Stats/looks are GAMEPLAY placeholders (VERIFY looks).
	"wu": {
		"name": ["Wu", "وو"], "element": "none", "playable": false,
		"suit": Color(0.85, 0.8, 0.6),
		"hp": 140.0, "speed": 5.4, "light": 10.0, "heavy": 20.0, "poise": 4.0,
		"ability": {"name": ["Elder's Palm", "راحة الحكيم"], "kind": "aoe", "sfx": "energy",
			"center": "front", "status": "", "damage": 18.0, "radius": 3.6, "knockback": 7.0, "cooldown": 5.5, "color": Color(0.4, 0.9, 0.8)},
	},
	"eyezor": {
		"name": ["Eyezor", "آيزور"], "element": "none", "playable": false,
		"suit": Color(0.25, 0.2, 0.3),
		"hp": 180.0, "speed": 5.0, "light": 11.0, "heavy": 22.0, "poise": 5.0,
		"ability": {"name": ["Enforcer's Strike", "ضربة المنفّذ"], "kind": "aoe", "sfx": "quake",
			"center": "front", "status": "", "damage": 20.0, "radius": 3.8, "knockback": 8.0, "cooldown": 6.0, "color": Color(0.9, 0.3, 0.3)},
	},
	"kapau": {
		"name": ["Kapau", "كاباو"], "element": "none", "playable": false,
		"suit": Color(0.4, 0.2, 0.45),
		"hp": 150.0, "speed": 5.0, "light": 10.0, "heavy": 20.0, "poise": 3.0,
		"ability": {"name": ["Spell Spark", "شرارة التعويذة"], "kind": "projectile", "sfx": "energy",
			"status": "", "damage": 18.0, "range": 14.0, "speed": 14.0, "cooldown": 4.0, "radius": 1.0, "splash": 2.0, "pierce": false,
			"color": Color(0.7, 0.3, 0.9)},
	},
	"chope": {
		"name": ["Chope", "تشوب"], "element": "none", "playable": false,
		"suit": Color(0.5, 0.3, 0.2),
		"hp": 170.0, "speed": 4.8, "light": 11.0, "heavy": 22.0, "poise": 5.0,
		"ability": {"name": ["Heavy Chop", "الضربة الثقيلة"], "kind": "aoe", "sfx": "quake",
			"center": "front", "status": "", "damage": 22.0, "radius": 3.8, "knockback": 8.0, "cooldown": 6.0, "color": Color(0.9, 0.6, 0.3)},
	},
	"noble": {
		"name": ["Warden Noble", "المأمور نوبل"], "element": "none", "playable": false,
		"suit": Color(0.3, 0.35, 0.45),
		"hp": 160.0, "speed": 5.0, "light": 10.0, "heavy": 20.0, "poise": 4.0,
		"ability": {"name": ["Warden's Baton", "هراوة المأمور"], "kind": "aoe", "sfx": "quake",
			"center": "front", "status": "slow", "status_time": 2.0, "damage": 16.0, "radius": 3.4, "knockback": 6.0, "cooldown": 6.0, "color": Color(0.6, 0.7, 0.9)},
	},
	"garmadon": {
		"name": ["Garmadon", "غارمادون"], "element": "none", "playable": false,
		"suit": Color(0.18, 0.1, 0.18),
		"hp": 240.0, "speed": 5.6, "light": 14.0, "heavy": 28.0, "poise": 8.0,
		"ability": {"name": ["Four-Arm Sweep", "اكتساح الأذرع الأربع"], "kind": "aoe", "sfx": "quake",
			"center": "self", "status": "", "damage": 30.0, "radius": 4.6, "knockback": 10.0, "cooldown": 4.0, "color": Color(0.6, 0.2, 0.7)},
	},
	"general": {
		"name": ["Anacondrai General", "جنرال أناكوندراي"], "element": "serpent", "playable": false,
		"suit": Color(0.35, 0.12, 0.45),
		"hp": 150.0, "speed": 5.6, "light": 12.0, "heavy": 26.0, "poise": 6.0,
		"ability": {"name": ["Venom Slam", "ضربة السم"], "kind": "aoe", "sfx": "quake",
			"center": "front", "status": "", "damage": 26.0,
			"radius": 4.0, "knockback": 9.0, "cooldown": 6.5, "color": Color(0.6, 0.2, 0.8)},
	},
	"general_b": {
		"name": ["Anacondrai General", "جنرال أناكوندراي"], "element": "serpent", "playable": false,
		"suit": Color(0.2, 0.15, 0.5),
		"hp": 150.0, "speed": 5.6, "light": 12.0, "heavy": 26.0, "poise": 6.0,
		"ability": {"name": ["Venom Slam", "ضربة السم"], "kind": "aoe", "sfx": "quake",
			"center": "front", "status": "", "damage": 26.0,
			"radius": 4.0, "knockback": 9.0, "cooldown": 6.5, "color": Color(0.6, 0.2, 0.8)},
	},
	"skylor": {
		"name": ["Skylor", "سكايلور"], "element": "absorb", "playable": false,
		"suit": Color(0.9, 0.55, 0.1),
		"hp": 115.0, "speed": 6.6, "light": 10.0, "heavy": 21.0, "poise": 0.0,
		"ability": {"name": ["Elemental Absorption", "امتصاص القوى"], "kind": "absorb", "sfx": "energy",
			"damage": 16.0, "radius": 5.0, "heal": 0.2, "status_time": 8.0, "cooldown": 8.0,
			"color": Color(1.0, 0.7, 0.1)},
	},
}

static func name_of(id: String) -> String:
	return Loc.pick(DATA[id]["name"])

static func ability_name(id: String) -> String:
	return Loc.pick(DATA[id]["ability"]["name"])
