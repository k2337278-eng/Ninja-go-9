class_name Player
extends Fighter
## The single character the player controls (chosen at New Game).

signal interact_pressed
signal feedback(text: String)
signal pause_requested

var controls: TouchControls
var cam_rig: CameraRig
var tag_t := 0.0
var tag_ally: Companion = null
var tag_my_id := ""
var input_locked := false

func _ready() -> void:
	team = "player"
	dmg_mult = GameState.damage_multiplier() * GameState.weapon_multiplier()
	super()

func bind_controls(c: TouchControls) -> void:
	controls = c
	c.action_pressed.connect(_on_action)
	c.action_released.connect(_on_release)
	if cam_rig != null:
		c.look.connect(cam_rig.rotate_view)
		c.action_pressed.connect(func(a: String) -> void:
			if a == "lock" and cam_rig != null:
				cam_rig.toggle_lock(self))

func _on_action(a: String) -> void:
	if a == "pause":
		pause_requested.emit()
		return
	if input_locked or state == S.DEAD:
		return
	match a:
		"tag":
			try_tag()
		"light":
			try_light()
		"heavy":
			try_heavy()
		"jump":
			try_jump()
		"spin":
			if power_stolen:
				feedback.emit(Loc.pick(["Spinjitzu is drained!", "قوة السبينجيتزو مسلوبة!"]))
			else:
				try_spin()
		"power":
			try_ability()
		"dodge":
			try_dodge()
		"block":
			set_blocking(true)
		"interact":
			interact_pressed.emit()

func _on_release(a: String) -> void:
	if a == "block":
		set_blocking(false)

func _unhandled_key_input(event: InputEvent) -> void:
	var k := event as InputEventKey
	if k == null or k.echo:
		return
	var a := ""
	match k.keycode:
		KEY_J:
			a = "light"
		KEY_K:
			a = "heavy"
		KEY_SPACE:
			a = "jump"
		KEY_Q:
			a = "spin"
		KEY_E:
			a = "power"
		KEY_SHIFT:
			a = "dodge"
		KEY_L:
			a = "block"
		KEY_F:
			a = "interact"
		KEY_ESCAPE:
			a = "pause"
	if a == "":
		return
	if k.pressed:
		_on_action(a)
	else:
		_on_release(a)

## Ends a tag-in: swap back looks/stats/abilities. If the ally has vanished, rebuild our own look.
func _tag_end() -> void:
	var ally := tag_ally
	tag_ally = null
	if ally != null and is_instance_valid(ally):
		swap_identity_with(ally)
		SkillTree.apply(self)
		SkillTree.apply(ally, false)
		health_changed.emit(self)
		Effects.ring(self, global_position, 3.0, Color(1.0, 1.0, 0.6))
	else:
		var keep := health / maxf(max_health, 1.0)
		setup_character(tag_my_id, true)
		var old := rig
		rig = Minifig.new()
		add_child(rig)
		rig.build(rig_cfg)
		old.queue_free()
		SkillTree.apply(self)
		health = max_health * keep
		health_changed.emit(self)

func think(delta: float) -> void:
	if tag_t > 0.0:
		tag_t -= delta
		if tag_t <= 0.0:
			_tag_end()
	aim_dir = Vector3.ZERO
	var v := Vector2.ZERO
	if not input_locked:
		if controls != null:
			v = controls.move_vector
		v += Vector2(
			float(Input.is_key_pressed(KEY_D)) - float(Input.is_key_pressed(KEY_A)),
			float(Input.is_key_pressed(KEY_S)) - float(Input.is_key_pressed(KEY_W)))
		v = v.limit_length(1.0)
	var yaw := cam_rig.yaw if cam_rig != null else 0.0
	move_input = Vector3(v.x, 0.0, v.y).rotated(Vector3.UP, yaw)

## Tag-in (docs/GAMEPLAY_DESIGN.md): the nearest ally dashes in for a cooperation strike around you and swaps places with you.
## If you landed a hit in the last 1.6 s it is a PERFECT tag: double damage, you heal 15 percent, the ally's power resets.
func try_tag() -> void:
	if float(cooldowns.get("tag", 0.0)) > 0.0 or state == S.DEAD or tag_t > 0.0:
		return
	var ally: Companion = null
	var best := 14.0
	for n in get_tree().get_nodes_in_group("fighters"):
		var c := n as Companion
		if c == null or c.downed or c.state == S.DEAD:
			continue
		var d := c.global_position.distance_to(global_position)
		if d < best:
			best = d
			ally = c
	if ally == null:
		return
	var perfect := Time.get_ticks_msec() - last_hit_ms < 1600
	cooldowns["tag"] = 7.0
	cd_max["tag"] = 7.0
	var col := Color(1.0, 1.0, 0.6)
	var ab: Dictionary = ally._active_ability()
	if ab.has("color"):
		col = ab["color"]
	var pos := global_position
	var dmg := 26.0 * (2.0 if perfect else 1.0)
	for n in get_tree().get_nodes_in_group("fighters"):
		var f := n as Fighter
		if f == null or f.team == team or f.state == S.DEAD:
			continue
		if Vector2(f.global_position.x - pos.x, f.global_position.z - pos.z).length() <= 4.8:
			f.take_damage(dmg, ally, 9.0, 0.6)
	Effects.ring(self, pos, 4.8, col)
	Effects.burst(self, pos + Vector3(0, 1.0, 0), col, 24, 7.0)
	Effects.shake(self, 0.25)
	Sfx.play("impact" if perfect else "hit")
	var ap := ally.global_position
	ally.global_position = pos
	global_position = ap
	# true swap for 18 s: we take the ally's look, stats and ability, and they take ours
	tag_my_id = char_id
	swap_identity_with(ally)
	SkillTree.apply(self)
	SkillTree.apply(ally, false)
	tag_ally = ally
	tag_t = 18.0
	health_changed.emit(self)
	if perfect:
		health = minf(max_health, health + max_health * 0.15)
		health_changed.emit(self)
		ally.cooldowns["ability"] = 0.0
		GameState.stat("perfect_tags")
