class_name Companion
extends Fighter
## AI-controlled ninja ally: follows the player, fights nearby enemies, uses its
## own elemental ability. When health hits zero it is downed and revives.

var leader: Fighter
var slot := 0
var target: Fighter
var next_attack := 0.5
var downed_t := 0.0

func on_zero_health() -> bool:
	downed = true
	downed_t = 5.0
	health = 0.0
	invuln = 5.0
	apply_stagger(5.0)
	return true

func think(delta: float) -> void:
	move_input = Vector3.ZERO
	aim_dir = Vector3.ZERO
	if downed:
		downed_t -= delta
		if downed_t <= 0.0:
			downed = false
			health = max_health * 0.6
			health_changed.emit(self)
		return
	next_attack -= delta
	if leader == null or not is_instance_valid(leader) or state != S.IDLE:
		return
	if target == null or not is_instance_valid(target) or target.state == S.DEAD \
			or target.global_position.distance_to(leader.global_position) > 18.0:
		target = nearest_foe(leader.global_position, 14.0)
	if target != null:
		var to := target.global_position - global_position
		to.y = 0.0
		var dist := to.length()
		if dist < 0.01:
			return
		var dirn := to / dist
		aim_dir = dirn
		if dist > 1.8:
			move_input = dirn
		var ab := _active_ability()
		if ab.get("kind", "") == "absorb":
			if float(cooldowns.get("ability", 0.0)) <= 0.0 and dist < float(ab["radius"]):
				try_ability()
				return
		elif float(cooldowns.get("ability", 0.0)) <= 0.0 and dist > 3.0 \
				and dist < float(ab.get("range", 6.0)) * 0.7 and randf() < 0.05:
			try_ability()
			return
		if dist <= 2.0 and next_attack <= 0.0:
			begin_attack({"anim": "light1", "dur": 0.4, "hit": 0.14, "dmg": light_dmg,
				"rng": 2.1, "arc": 110.0, "kb": 4.0, "combo": false, "stun": 0.0})
			next_attack = randf_range(0.9, 1.4)
		return
	# follow leader
	var right := leader.face_dir.cross(Vector3.UP).normalized()
	var desired := leader.global_position - leader.face_dir * 3.0 + right * (float(slot) - 1.5) * 1.8
	var off := desired - global_position
	off.y = 0.0
	if off.length() > 25.0:
		global_position = desired + Vector3(0, 0.5, 0)
		return
	if off.length() > 1.0:
		move_input = off.normalized() * clampf(off.length() / 3.0, 0.3, 1.2)
