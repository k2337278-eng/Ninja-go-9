class_name CameraRig
extends Node3D
## Third-person orbit camera driven by touch-drag (or mouse-drag on desktop).
## v7: wider vertical range (look up AND down), equal sensitivity, ground/wall collision, optional lock-on.

const PITCH_MIN := -1.35   # looking down from above
const PITCH_MAX := 0.45    # camera below the pivot, looking up at the sky
const SENS_X := 0.0055
const SENS_Y := 0.0055
const LOCK_RANGE := 22.0

var target: Node3D
var yaw := 0.0
var pitch := -0.35
var dist := 7.5
var cam: Camera3D
var shake := 0.0
var lock_target: Node3D

func _ready() -> void:
	add_to_group("camera_rig")
	cam = Camera3D.new()
	cam.fov = 65.0
	cam.far = 220.0
	add_child(cam)
	cam.position = Vector3(0, 0, dist)
	cam.current = true

func rotate_view(d: Vector2) -> void:
	if lock_target != null:
		lock_target = null   # a manual drag breaks the lock
	yaw -= d.x * SENS_X
	pitch = clampf(pitch + d.y * SENS_Y, PITCH_MIN, PITCH_MAX)

## Lock on to the nearest living enemy in front of the player, or release the lock.
func toggle_lock(from: Node3D) -> void:
	if lock_target != null:
		lock_target = null
		return
	var best: Node3D = null
	var best_d := LOCK_RANGE
	for e in get_tree().get_nodes_in_group("enemies"):
		if not is_instance_valid(e) or not (e is Node3D):
			continue
		if "state" in e and e.state == Fighter.S.DEAD:
			continue
		var dd: float = from.global_position.distance_to(e.global_position)
		if dd < best_d:
			best_d = dd
			best = e
	lock_target = best

func _process(delta: float) -> void:
	if target != null and is_instance_valid(target):
		global_position = global_position.lerp(target.global_position + Vector3(0, 1.3, 0), 1.0 - exp(-12.0 * delta))
	if lock_target != null:
		var lost := not is_instance_valid(lock_target)
		if not lost:
			var lf := lock_target as Fighter
			if lf != null and lf.state == Fighter.S.DEAD:
				lost = true
		if not lost and target != null and target.global_position.distance_to(lock_target.global_position) > LOCK_RANGE + 6.0:
			lost = true
		if lost:
			lock_target = null
		elif target != null:
			var dv: Vector3 = lock_target.global_position - target.global_position
			var want_yaw := atan2(-dv.x, -dv.z)
			yaw = lerp_angle(yaw, want_yaw, 1.0 - exp(-8.0 * delta))
			pitch = lerpf(pitch, -0.3, 1.0 - exp(-6.0 * delta))
	rotation = Vector3(pitch, yaw, 0.0)
	# keep the camera out of the ground and walls
	var from_pos: Vector3 = global_position
	var want_pos: Vector3 = global_transform * Vector3(0, 0, dist)
	var q := PhysicsRayQueryParameters3D.create(from_pos, want_pos)
	var ex: Array[RID] = []
	for f in get_tree().get_nodes_in_group("fighters"):
		if f is CollisionObject3D:
			ex.append(f.get_rid())
	q.exclude = ex
	var hit: Dictionary = get_world_3d().direct_space_state.intersect_ray(q)
	var d := dist
	if not hit.is_empty():
		var hp: Vector3 = hit["position"]
		d = clampf(from_pos.distance_to(hp) - 0.4, 1.2, dist)
	cam.position.z = lerpf(cam.position.z, d, 1.0 - exp(-14.0 * delta))
	shake = move_toward(shake, 0.0, delta * 1.5)
	cam.h_offset = randf_range(-1.0, 1.0) * shake * 0.3
	cam.v_offset = randf_range(-1.0, 1.0) * shake * 0.3
