class_name Minifig
extends Node3D
## Procedural LEGO-minifigure-style 3D model (original geometry, primitives only)
## with procedural animation. Faces -Z. This node itself is the yaw node.

const WEAPONS := {"kai": "sword", "jay": "nunchaku", "cole": "scythe", "zane": "shuriken",
	"lloyd": "sword_green", "skylor": "fan"}

const MODEL_PATH := "res://assets/models/minifig.glb"
const LOOPING := ["idle", "walk", "run", "block", "spin", "climb"]

var use_model := false
var ap: AnimationPlayer
var skel: Skeleton3D
var _clip := ""

var body: Node3D
var arm_l: Node3D
var arm_r: Node3D
var leg_l: Node3D
var leg_r: Node3D
var head: Node3D
var mats: Array = []
var cur := "idle"
var anim_t := 0.0
var anim_dur := 0.3
var phase := 0.0
var spin_angle := 0.0
var flash_t := 0.0
var warn_t := 0.0
var glow_col := Color.BLACK
var glow_e := 0.0
var _last_g := -1.0
var _last_c := Color.BLACK

func _mat(c: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.set_meta("orig", c)
	m.roughness = 0.35
	m.metallic_specular = 0.6
	mats.append(m)
	return m

func _mesh(parent: Node3D, mesh: Mesh, pos: Vector3, c: Color) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = _mat(c)
	mi.position = pos
	parent.add_child(mi)
	return mi

func _box(parent: Node3D, size: Vector3, pos: Vector3, c: Color) -> MeshInstance3D:
	var b := BoxMesh.new()
	b.size = size
	return _mesh(parent, b, pos, c)

func _cyl(parent: Node3D, rt: float, rb: float, h: float, pos: Vector3, c: Color) -> MeshInstance3D:
	var m := CylinderMesh.new()
	m.top_radius = rt
	m.bottom_radius = rb
	m.height = h
	m.radial_segments = 16
	m.rings = 1
	return _mesh(parent, m, pos, c)

func _ball(parent: Node3D, r: float, pos: Vector3, c: Color) -> MeshInstance3D:
	var m := SphereMesh.new()
	m.radius = r
	m.height = r * 2.0
	m.radial_segments = 10
	m.rings = 5
	return _mesh(parent, m, pos, c)

func _pivot(parent: Node3D, pos: Vector3) -> Node3D:
	var n := Node3D.new()
	n.position = pos
	parent.add_child(n)
	return n

func build(cfg: Dictionary) -> void:
	if _try_build_model(cfg):
		return
	var suit: Color = cfg.get("suit", Color(0.8, 0.1, 0.1))
	var skin := Color(0.98, 0.8, 0.12)
	var legs_c: Color = cfg.get("legs", suit.darkened(0.3))
	var accent: Color = cfg.get("accent", suit.lightened(0.35))
	var style: String = cfg.get("style", "ninja")
	var sc: float = cfg.get("scale", 1.0)
	scale = Vector3.ONE * sc
	body = _pivot(self, Vector3.ZERO)
	# legs (pivot at hip)
	leg_l = _pivot(body, Vector3(-0.12, 0.55, 0))
	leg_r = _pivot(body, Vector3(0.12, 0.55, 0))
	_box(leg_l, Vector3(0.22, 0.55, 0.28), Vector3(0, -0.275, 0), legs_c)
	_box(leg_r, Vector3(0.22, 0.55, 0.28), Vector3(0, -0.275, 0), legs_c)
	# hips, torso, belt, emblem
	_box(body, Vector3(0.48, 0.16, 0.3), Vector3(0, 0.62, 0), legs_c)
	_box(body, Vector3(0.52, 0.55, 0.32), Vector3(0, 0.975, 0), suit)
	_box(body, Vector3(0.54, 0.07, 0.34), Vector3(0, 0.74, 0), accent)
	_box(body, Vector3(0.18, 0.18, 0.02), Vector3(0, 1.05, -0.165), accent)
	if cfg.has("robe"):
		_box(body, Vector3(0.64, 0.64, 0.44), Vector3(0, 0.45, 0), cfg["robe"])
	# arms (pivot at shoulder)
	arm_l = _pivot(body, Vector3(-0.34, 1.18, 0))
	arm_r = _pivot(body, Vector3(0.34, 1.18, 0))
	for a in [arm_l, arm_r]:
		_box(a, Vector3(0.15, 0.46, 0.17), Vector3(0, -0.23, 0), suit)
		_ball(a, 0.085, Vector3(0, -0.5, 0), skin)
	# head
	head = _pivot(body, Vector3(0, 1.25, 0))
	var stud_c := skin
	if style == "ninja":
		var hood := suit.darkened(0.1)
		stud_c = hood
		_cyl(head, 0.26, 0.26, 0.32, Vector3(0, 0.16, 0), hood)
		_box(head, Vector3(0.3, 0.1, 0.03), Vector3(0, 0.17, -0.255), skin)
		_box(head, Vector3(0.045, 0.05, 0.02), Vector3(-0.07, 0.17, -0.272), Color.BLACK)
		_box(head, Vector3(0.045, 0.05, 0.02), Vector3(0.07, 0.17, -0.272), Color.BLACK)
	else:
		_cyl(head, 0.26, 0.26, 0.32, Vector3(0, 0.16, 0), skin)
		_box(head, Vector3(0.045, 0.05, 0.02), Vector3(-0.07, 0.19, -0.262), Color.BLACK)
		_box(head, Vector3(0.045, 0.05, 0.02), Vector3(0.07, 0.19, -0.262), Color.BLACK)
		_box(head, Vector3(0.14, 0.025, 0.02), Vector3(0, 0.09, -0.262), Color(0.4, 0.1, 0.1))
		if cfg.has("hair"):
			_cyl(head, 0.275, 0.275, 0.12, Vector3(0, 0.29, 0), cfg["hair"])
		if cfg.has("hat"):
			_cyl(head, 0.0, 0.36, 0.4, Vector3(0, 0.52, 0), cfg["hat"])
	_cyl(head, 0.1, 0.1, 0.07, Vector3(0, 0.355, 0), stud_c)
	if str(cfg.get("weapon", "")) != "":
		_build_weapon(str(cfg["weapon"]))

## Procedural weapons held in the right hand; they follow the arm swing animations.
func _build_weapon(kind: String) -> void:
	var wp := _pivot(arm_r, Vector3(0, -0.5, 0))
	wp.rotation.x = -0.4
	var metal := Color(0.82, 0.84, 0.9)
	var wood := Color(0.4, 0.26, 0.12)
	var gold := Color(1.0, 0.8, 0.2)
	match kind:
		"sword", "sword_green", "sword_gold":
			var bc := metal
			if kind == "sword_green":
				bc = Color(0.45, 1.0, 0.55)
			elif kind == "sword_gold":
				bc = gold
			_box(wp, Vector3(0.05, 0.14, 0.05), Vector3(0, 0.0, 0), wood)
			_box(wp, Vector3(0.22, 0.035, 0.07), Vector3(0, 0.08, 0), gold)
			_box(wp, Vector3(0.06, 0.8, 0.02), Vector3(0, 0.5, 0), bc)
		"nunchaku":
			_box(wp, Vector3(0.045, 0.4, 0.045), Vector3(0, 0.1, 0), wood)
			_box(wp, Vector3(0.015, 0.22, 0.015), Vector3(0, 0.4, 0), metal)
			var s2 := _box(wp, Vector3(0.045, 0.4, 0.045), Vector3(0, 0.66, 0.1), wood)
			s2.rotation.x = 0.4
		"scythe":
			_box(wp, Vector3(0.05, 1.5, 0.05), Vector3(0, 0.55, 0), wood)
			var bl := _box(wp, Vector3(0.55, 0.07, 0.03), Vector3(0.24, 1.3, 0), metal)
			bl.rotation.z = -0.35
		"shuriken":
			_box(wp, Vector3(0.3, 0.02, 0.3), Vector3(0, 0.05, 0), metal)
			var s3 := _box(wp, Vector3(0.3, 0.02, 0.3), Vector3(0, 0.05, 0), metal)
			s3.rotation.y = PI / 4.0
		"fan":
			_box(wp, Vector3(0.5, 0.4, 0.02), Vector3(0, 0.3, 0), Color(1.0, 0.6, 0.1))
			_box(wp, Vector3(0.5, 0.04, 0.03), Vector3(0, 0.5, 0), gold)
		"club":
			_cyl(wp, 0.09, 0.05, 0.6, Vector3(0, 0.25, 0), wood)
		"hammer":
			_box(wp, Vector3(0.06, 1.0, 0.06), Vector3(0, 0.4, 0), wood)
			_box(wp, Vector3(0.55, 0.3, 0.3), Vector3(0, 0.95, 0), Color(0.45, 0.45, 0.5))
		"spear":
			_box(wp, Vector3(0.05, 1.8, 0.05), Vector3(0, 0.7, 0), wood)
			_box(wp, Vector3(0.1, 0.3, 0.03), Vector3(0, 1.7, 0), metal)
		"staff":
			_box(wp, Vector3(0.05, 1.7, 0.05), Vector3(0, 0.6, 0), Color(0.25, 0.1, 0.3))
			_ball(wp, 0.12, Vector3(0, 1.5, 0), Color(0.7, 0.2, 0.9))

func play(anim_name: String, dur := 0.3) -> void:
	cur = anim_name
	anim_t = 0.0
	anim_dur = maxf(dur, 0.01)
	_clip = ""

func update_anim(delta: float, speed_ratio: float, airborne: bool) -> void:
	if use_model:
		_update_model(delta, speed_ratio, airborne)
		_update_glow(delta)
		return
	anim_t += delta
	var k: float = clampf(anim_t / anim_dur, 0.0, 1.0)
	var al := 0.0
	var ar := 0.0
	var ll := 0.0
	var lr := 0.0
	var alz := -0.08
	var arz := 0.08
	var lean := 0.0
	var twist := 0.0
	if cur != "spin":
		spin_angle = 0.0
	match cur:
		"idle":
			var a: float = clampf(speed_ratio, 0.0, 1.3)
			phase += delta * (5.0 + 7.0 * a)
			ll = sin(phase) * 0.9 * a
			lr = -ll
			al = -ll * 0.8
			ar = -lr * 0.8
			if a < 0.05:
				alz = -0.08 + sin(phase) * 0.02
				arz = 0.08 - sin(phase) * 0.02
			if airborne:
				al = 2.4
				ar = 2.4
				ll = 0.4
				lr = -0.3
		"light1":
			ar = lerpf(-1.4, 2.1, ease(k, 0.35))
			twist = lerpf(0.5, -0.5, k)
		"light2":
			al = lerpf(-1.4, 2.1, ease(k, 0.35))
			twist = lerpf(-0.5, 0.5, k)
		"light3":
			al = lerpf(-0.5, 2.4, ease(k, 0.3))
			ar = al
			lean = lerpf(0.1, -0.45, k)
			ll = 0.8
			lr = -0.6
		"heavy":
			if k < 0.5:
				al = lerpf(0.0, 3.0, k * 2.0)
				lean = lerpf(0.0, 0.25, k * 2.0)
			else:
				al = lerpf(3.0, 0.3, ease(k * 2.0 - 1.0, 0.3))
				lean = lerpf(0.25, -0.5, k * 2.0 - 1.0)
			ar = al
		"cast":
			al = 1.55 + sin(anim_t * 18.0) * 0.12
			ar = al
			lean = -0.12
		"enemy_atk":
			ar = lerpf(-1.6, 2.2, ease(k, 4.0))
			lean = lerpf(0.25, -0.3, ease(k, 4.0))
		"dodge":
			lean = -0.7
			ll = 1.0
			lr = -1.0
			al = -0.8
			ar = -0.8
		"stagger":
			lean = 0.45
			al = 0.9
			ar = 0.9
			alz = -0.7
			arz = 0.7
		"block":
			al = 1.4
			ar = 1.4
			alz = 0.55
			arz = -0.55
			lean = -0.05
		"climb":
			phase += delta * 8.0
			al = 2.6 + sin(phase) * 0.6
			ar = 2.6 - sin(phase) * 0.6
			ll = sin(phase) * 0.7
			lr = -ll
			lean = 0.15
		"spin":
			spin_angle += delta * 22.0
			alz = -1.45
			arz = 1.45
	arm_l.rotation = Vector3(al, 0.0, alz)
	arm_r.rotation = Vector3(ar, 0.0, arz)
	leg_l.rotation.x = ll
	leg_r.rotation.x = lr
	body.rotation = Vector3(lean, twist + spin_angle, 0.0)
	_update_glow(delta)

func set_drained(on: bool) -> void:
	for mt in mats:
		var o: Color = mt.get_meta("orig")
		if on:
			var g := o.get_luminance()
			mt.albedo_color = o.lerp(Color(g, g, g), 0.85)
		else:
			mt.albedo_color = o

func _update_glow(delta: float) -> void:
	var g := glow_e
	var gc := glow_col
	if warn_t > 0.0:
		warn_t -= delta
		g = 1.2
		gc = Color(1.0, 0.1, 0.1)
	if flash_t > 0.0:
		flash_t -= delta
		g = 2.5
		gc = Color.WHITE
	if g != _last_g or gc != _last_c:
		_last_g = g
		_last_c = gc
		for m in mats:
			m.emission_enabled = g > 0.01
			m.emission = gc
			m.emission_energy_multiplier = g

func freeze() -> void:
	if use_model and ap != null:
		ap.pause()

## Real skeletal model (assets/models/minifig.glb): 9-bone skeleton, 15 baked clips.
## Returns false (and leaves everything untouched) if the asset is missing/invalid,
## in which case the procedural primitive minifigure above is used instead.
func _try_build_model(cfg: Dictionary) -> bool:
	if not ResourceLoader.exists(MODEL_PATH):
		return false
	var ps := load(MODEL_PATH) as PackedScene
	if ps == null:
		return false
	var inst := ps.instantiate() as Node3D
	if inst == null:
		return false
	var found_ap := inst.find_child("AnimationPlayer", true, false) as AnimationPlayer
	var found_sk := inst.find_child("Skeleton3D", true, false) as Skeleton3D
	if found_ap == null or found_sk == null or found_sk.find_bone("hand_r") < 0 or not found_ap.has_animation("idle"):
		inst.free()
		return false
	var suit: Color = cfg.get("suit", Color(0.8, 0.1, 0.1))
	var style: String = cfg.get("style", "ninja")
	var colors := {
		"suit": suit, "legs": cfg.get("legs", suit.darkened(0.3)), "accent": cfg.get("accent", suit.lightened(0.35)),
		"hood": suit.darkened(0.1), "skin": Color(0.98, 0.8, 0.12), "hair": cfg.get("hair", Color(0.15, 0.1, 0.05)),
		"hat": cfg.get("hat", Color(0.3, 0.1, 0.3)), "robe": cfg.get("robe", Color(0.3, 0.0, 0.35))}
	for n in inst.find_children("*", "MeshInstance3D", true, false):
		var mi := n as MeshInstance3D
		match String(mi.name):
			"head_hood":
				mi.visible = style == "ninja"
			"head_bare":
				mi.visible = style != "ninja"
			"opt_hair":
				mi.visible = cfg.has("hair") and style != "ninja"
			"opt_hat":
				mi.visible = cfg.has("hat") and style != "ninja"
			"opt_robe":
				mi.visible = cfg.has("robe")
		if mi.mesh == null:
			continue
		for i in mi.mesh.get_surface_count():
			var src := mi.mesh.surface_get_material(i) as StandardMaterial3D
			if src == null:
				continue
			var mt := src.duplicate() as StandardMaterial3D
			var mname := String(src.resource_name)
			if colors.has(mname):
				mt.albedo_color = colors[mname]
			mt.set_meta("orig", mt.albedo_color)
			mi.set_surface_override_material(i, mt)
			mats.append(mt)
	body = inst
	add_child(inst)
	scale = Vector3.ONE * float(cfg.get("scale", 1.0))
	ap = found_ap
	skel = found_sk
	for an in ap.get_animation_list():
		ap.get_animation(an).loop_mode = Animation.LOOP_LINEAR if LOOPING.has(String(an)) else Animation.LOOP_NONE
	var ba := BoneAttachment3D.new()
	ba.bone_name = "hand_r"
	skel.add_child(ba)
	arm_r = Node3D.new()
	arm_r.position = Vector3(0, 0.5, 0)
	ba.add_child(arm_r)
	var wk := str(cfg.get("weapon", ""))
	if wk != "":
		var wpath := "res://assets/models/weapon_%s.glb" % wk
		if ResourceLoader.exists(wpath):
			var wps := load(wpath) as PackedScene
			if wps != null:
				var w := wps.instantiate() as Node3D
				if w != null:
					w.rotation.x = -0.4
					ba.add_child(w)
	use_model = true
	cur = "idle"
	ap.play("idle")
	return true

func _update_model(delta: float, speed_ratio: float, airborne: bool) -> void:
	anim_t += delta
	var want := cur
	var spd := 1.0
	if cur == "idle":
		var wt := 0.05 if (_clip == "walk" or _clip == "run") else 0.1
		var rt := 0.7 if _clip == "run" else 0.85
		if airborne:
			want = "jump"
		elif speed_ratio > rt:
			want = "run"
			spd = clampf(speed_ratio, 0.8, 1.3)
		elif speed_ratio > wt:
			want = "walk"
			spd = clampf(speed_ratio * 1.2, 0.5, 1.3)
	elif not LOOPING.has(want) and ap.has_animation(want):
		spd = ap.get_animation(want).length / anim_dur
	if not ap.has_animation(want):
		want = "idle"
	if want != _clip:
		_clip = want
		if ap.current_animation == want:
			ap.stop()
		ap.play(want, 0.1)
	ap.speed_scale = spd
