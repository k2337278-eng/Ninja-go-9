class_name Fighter
extends CharacterBody3D
## Base combat actor: movement, light/heavy combo, dodge, block + perfect-block
## counter, elemental ability, Spinjitzu, knockback, statuses, cooldowns.
## Player, Enemy and Companion extend this and only implement think().

signal died(fighter)
signal health_changed(fighter)

enum S { IDLE, ATTACK, DODGE, BLOCK, STAGGER, SPIN, CAST, DEAD }

const GRAVITY := 26.0

var char_id := "kai"
var team := "player"
var display_name := ""
var rig_cfg: Dictionary = {}
var max_health := 100.0
var health := 100.0
var move_speed := 6.0
var poise := 0.0
var dmg_mult := 1.0
var light_dmg := 10.0
var heavy_dmg := 22.0
var ability: Dictionary = {}
var state: int = S.IDLE
var state_t := 0.0
var face_dir := Vector3(0, 0, -1)
var aim_dir := Vector3.ZERO
var move_input := Vector3.ZERO
var knock := Vector3.ZERO
var cooldowns := {}
var last_hit_ms := 0
var cd_max := {}
var statuses := {}
var invuln := 0.0
var block_since := -10.0
var combo_idx := 0
var combo_window := 0.0
var counter_window := 0.0
var atk: Dictionary = {}
var atk_hit_done := true
var cast_done := true
var spin_tick := 0.0
var dodge_dir := Vector3.ZERO
var stagger_time := 0.0
var downed := false
var rig: Minifig
var tornado: MeshInstance3D
var _burn_tick := 0.0
# v2: story power state, skills, climbing
var power_stolen := false
var base_hp := 100.0
var base_speed := 6.0
var skill_dmg := 1.0
var cd_scale := 1.0
var ability_mult := 1.0
var spin_mult := 1.0
var spin_bonus := 0.0
var finisher_mult := 1.7
var perfect_window := 0.25
var block_reduce := 0.25
var climb_zones := 0
var climbing := false

func setup_character(id: String, use_costume := false) -> void:
	var d: Dictionary = CharacterDB.DATA[id]
	char_id = id
	display_name = CharacterDB.name_of(id)
	max_health = d["hp"]
	health = max_health
	move_speed = d["speed"]
	base_hp = max_health
	base_speed = move_speed
	light_dmg = d["light"]
	heavy_dmg = d["heavy"]
	poise = d["poise"]
	ability = d["ability"]
	rig_cfg = {"suit": d["suit"], "style": "ninja", "weapon": Minifig.WEAPONS.get(id, "")}
	if use_costume:
		rig_cfg = CostumeDB.apply(rig_cfg, GameState.costume)

## True tag-in swap: exchange character identity (look, stats, ability) with `o`. Health keeps its ratio.
## The caller re-applies the skill tree afterwards (SkillTree.apply).
func swap_identity_with(o: Fighter) -> void:
	var my_ratio := health / maxf(max_health, 1.0)
	var o_ratio := o.health / maxf(o.max_health, 1.0)
	var my_id := char_id
	var o_id := o.char_id
	var my_rig := rig
	var o_rig := o.rig
	var my_tor := tornado
	var o_tor := o.tornado
	setup_character(o_id)
	o.setup_character(my_id)
	rig = o_rig
	o.rig = my_rig
	tornado = o_tor
	o.tornado = my_tor
	o_rig.reparent(self, false)
	my_rig.reparent(o, false)
	o_tor.reparent(self, false)
	my_tor.reparent(o, false)
	health = max_health * my_ratio
	o.health = o.max_health * o_ratio
	refresh_power_state()
	o.refresh_power_state()

func _ready() -> void:
	add_to_group("fighters")
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.35
	cap.height = 1.6
	cs.shape = cap
	cs.position.y = 0.8
	add_child(cs)
	rig = Minifig.new()
	add_child(rig)
	rig.build(rig_cfg)
	# blob shadow (keeps characters grounded when real shadows are off)
	var blob := MeshInstance3D.new()
	var bm := CylinderMesh.new()
	bm.top_radius = 0.5
	bm.bottom_radius = 0.5
	bm.height = 0.01
	bm.radial_segments = 12
	bm.rings = 1
	var bmat := StandardMaterial3D.new()
	bmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	bmat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	bmat.albedo_color = Color(0, 0, 0, 0.35)
	bm.material = bmat
	blob.mesh = bm
	blob.position.y = 0.03
	blob.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(blob)
	# Spinjitzu tornado visual
	var col: Color = ability.get("color", Color(1, 1, 1))
	tornado = MeshInstance3D.new()
	var tm := CylinderMesh.new()
	tm.top_radius = 1.5
	tm.bottom_radius = 0.35
	tm.height = 2.4
	tm.radial_segments = 12
	tm.rings = 1
	var tmat := StandardMaterial3D.new()
	tmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	tmat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	tmat.cull_mode = BaseMaterial3D.CULL_DISABLED
	tmat.albedo_color = Color(col, 0.4)
	tm.material = tmat
	tornado.mesh = tm
	tornado.position.y = 1.2
	tornado.visible = false
	tornado.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(tornado)
	GameState.powers_changed.connect(refresh_power_state)
	refresh_power_state()

# ---- virtuals -------------------------------------------------------------
func think(_delta: float) -> void:
	pass

func on_zero_health() -> bool:
	return false

# ---- main loop ------------------------------------------------------------
func _physics_process(delta: float) -> void:
	if state == S.DEAD:
		velocity.x = 0.0
		velocity.z = 0.0
		velocity.y -= GRAVITY * delta
		move_and_slide()
		return
	_tick_timers(delta)
	think(delta)
	_update_state(delta)
	_move(delta)
	_update_visual(delta)

func _tick_timers(delta: float) -> void:
	for k in cooldowns.keys():
		cooldowns[k] = maxf(0.0, float(cooldowns[k]) - delta)
	invuln = maxf(0.0, invuln - delta)
	combo_window = maxf(0.0, combo_window - delta)
	counter_window = maxf(0.0, counter_window - delta)
	for k in statuses.keys():
		statuses[k] = float(statuses[k]) - delta
		if statuses[k] <= 0.0:
			statuses.erase(k)
	if statuses.has("burn"):
		_burn_tick -= delta
		if _burn_tick <= 0.0:
			_burn_tick = 0.5
			take_damage(3.0, null, 0.0, 0.0, true)

func _set_state(s: int) -> void:
	if state == S.SPIN and s != S.SPIN and tornado != null:
		tornado.visible = false
	state = s
	state_t = 0.0
	match s:
		S.IDLE:
			rig.play("idle")
		S.BLOCK:
			rig.play("block", 1.0)
		S.SPIN:
			rig.play("spin", 1.0)

func _update_state(delta: float) -> void:
	state_t += delta
	match state:
		S.ATTACK:
			if not atk_hit_done and state_t >= float(atk["hit"]):
				atk_hit_done = true
				_do_attack_hit()
			if state == S.ATTACK and state_t >= float(atk["dur"]):
				var was_combo: bool = atk.get("combo", false)
				_set_state(S.IDLE)
				combo_window = 0.45 if was_combo else 0.0
		S.DODGE:
			if state_t >= 0.3:
				_set_state(S.IDLE)
		S.STAGGER:
			if state_t >= stagger_time:
				_set_state(S.IDLE)
		S.CAST:
			if not cast_done and state_t >= 0.3:
				cast_done = true
				Abilities.cast(self, _active_ability())
			if state_t >= 0.55:
				_set_state(S.IDLE)
		S.SPIN:
			spin_tick -= delta
			if spin_tick <= 0.0:
				spin_tick = float(CharacterDB.SPIN["tick"])
				var n := melee(float(CharacterDB.SPIN["damage"]) * spin_mult, float(CharacterDB.SPIN["radius"]), 360.0, 5.0)
				if n > 0:
					Sfx.play("hit")
			if state_t >= float(CharacterDB.SPIN["duration"]) + spin_bonus:
				_set_state(S.IDLE)

func _move(delta: float) -> void:
	var spd := move_speed
	if statuses.has("slow"):
		spd *= 0.45
	var desired := Vector3.ZERO
	match state:
		S.IDLE:
			desired = move_input * spd
		S.ATTACK:
			desired = move_input * spd * 0.35
		S.BLOCK:
			desired = move_input * spd * 0.4
		S.SPIN:
			desired = move_input * spd * 0.8
		S.CAST:
			desired = move_input * spd * 0.2
		S.DODGE:
			desired = dodge_dir * 13.0
	if state == S.IDLE or state == S.BLOCK or state == S.SPIN:
		if aim_dir.length() > 0.1:
			face_dir = aim_dir.normalized()
		elif move_input.length() > 0.1:
			face_dir = move_input.normalized()
	climbing = false
	if climb_zones > 0 and state == S.IDLE and move_input.length() > 0.3:
		climbing = true
		desired *= 0.2
	velocity.x = desired.x + knock.x
	velocity.z = desired.z + knock.z
	knock = knock.move_toward(Vector3.ZERO, 30.0 * delta)
	if climbing:
		velocity.y = 4.5
	elif is_on_floor() and velocity.y <= 0.0:
		velocity.y = -0.5
	else:
		velocity.y -= GRAVITY * delta
	move_and_slide()
	for i in get_slide_collision_count():
		var col := get_slide_collision(i)
		var rb := col.get_collider() as RigidBody3D
		if rb != null:
			rb.apply_central_impulse(-col.get_normal() * 6.0)

func _update_visual(delta: float) -> void:
	var yaw := atan2(-face_dir.x, -face_dir.z)
	rig.rotation.y = lerp_angle(rig.rotation.y, yaw, 1.0 - exp(-18.0 * delta))
	var hs := Vector2(velocity.x, velocity.z).length()
	var ratio := hs / maxf(move_speed, 0.1)
	if state != S.IDLE and state != S.BLOCK:
		ratio = 0.0
	if statuses.has("burn"):
		rig.glow_col = Color(1.0, 0.4, 0.05)
		rig.glow_e = 0.9
	elif statuses.has("slow"):
		rig.glow_col = Color(0.3, 0.7, 1.0)
		rig.glow_e = 0.8
	elif statuses.has("weak"):
		rig.glow_col = Color(1.0, 0.9, 0.2)
		rig.glow_e = 0.9
	else:
		rig.glow_e = 0.0
	if climbing and rig.cur == "idle":
		rig.play("climb")
	elif not climbing and rig.cur == "climb":
		rig.play("idle")
	rig.update_anim(delta, ratio, not is_on_floor() and not climbing)
	if tornado.visible:
		tornado.rotation.y += delta * 15.0

# ---- actions --------------------------------------------------------------
func set_cd(n: String, t: float) -> void:
	cooldowns[n] = t
	cd_max[n] = t

func cd_frac(n: String) -> float:
	return clampf(float(cooldowns.get(n, 0.0)) / float(cd_max.get(n, 1.0)), 0.0, 1.0)

func _face_input() -> void:
	if aim_dir.length() > 0.1:
		face_dir = aim_dir.normalized()
	elif move_input.length() > 0.1:
		face_dir = move_input.normalized()

func _can_start_attack() -> bool:
	if state == S.IDLE:
		return true
	if state == S.ATTACK and atk.get("combo", false) and state_t >= float(atk["dur"]) * 0.55:
		return true
	return false

func begin_attack(p: Dictionary) -> void:
	atk = p
	atk_hit_done = false
	_set_state(S.ATTACK)
	rig.play(str(p["anim"]), float(p["dur"]))
	Sfx.play(str(p.get("sfx", "swing")))

func try_light() -> bool:
	if not _can_start_attack():
		return false
	_face_input()
	if combo_window > 0.0 and combo_idx > 0:
		combo_idx = combo_idx % 3 + 1
	else:
		combo_idx = 1
	var finisher := combo_idx == 3
	begin_attack({
		"anim": "light%d" % combo_idx, "dur": 0.55 if finisher else 0.4,
		"hit": 0.2 if finisher else 0.14,
		"dmg": light_dmg * (finisher_mult if finisher else 1.0), "rng": 2.1, "arc": 110.0,
		"kb": 11.0 if finisher else 4.0, "combo": true, "stun": 0.0,
	})
	return true

func try_heavy() -> bool:
	if state != S.IDLE:
		return false
	_face_input()
	combo_idx = 0
	begin_attack({"anim": "heavy", "dur": 0.8, "hit": 0.4, "dmg": heavy_dmg, "rng": 2.4,
		"arc": 140.0, "kb": 12.0, "combo": false, "stun": 0.5})
	return true

func _do_attack_hit() -> void:
	var dmg: float = float(atk["dmg"])
	if counter_window > 0.0 and atk.get("combo", false):
		dmg *= 2.0
		counter_window = 0.0
		Effects.burst(self, global_position + Vector3(0, 1.2, 0), Color(1, 1, 0.3), 20, 6.0)
	var n := melee(dmg, float(atk["rng"]), float(atk["arc"]), float(atk["kb"]), float(atk.get("stun", 0.0)))
	if n > 0:
		last_hit_ms = Time.get_ticks_msec()
		Sfx.play("impact" if dmg >= 24.0 else "hit")
		Effects.shake(self, 0.12 if team == "player" else 0.05)

func melee(dmg: float, rng: float, arc: float, kb: float, stun := 0.0) -> int:
	var count := 0
	for n in get_tree().get_nodes_in_group("fighters"):
		var f := n as Fighter
		if f == null or f == self or f.team == team or f.state == S.DEAD:
			continue
		var to := f.global_position - global_position
		to.y = 0.0
		var d := to.length()
		if d > rng + 0.35:
			continue
		if arc < 359.0 and d > 0.2 and rad_to_deg(face_dir.angle_to(to / d)) > arc * 0.5:
			continue
		if f.take_damage(dmg * dmg_scale(), self, kb, stun):
			count += 1
			Effects.burst(self, f.global_position + Vector3(0, 1.0, 0), Color(1, 0.9, 0.5), 8, 4.0)
	return count

func try_dodge() -> bool:
	if float(cooldowns.get("dodge", 0.0)) > 0.0:
		return false
	var ok := state == S.IDLE or state == S.BLOCK
	if state == S.ATTACK and state_t >= float(atk["dur"]) * 0.5:
		ok = true
	if not ok:
		return false
	dodge_dir = move_input.normalized() if move_input.length() > 0.1 else -face_dir
	invuln = 0.35
	_set_state(S.DODGE)
	rig.play("dodge", 0.3)
	set_cd("dodge", 0.7)
	Sfx.play("swing", 1.4)
	return true

func set_blocking(on: bool) -> void:
	if on and state == S.IDLE:
		_set_state(S.BLOCK)
		block_since = Time.get_ticks_msec() / 1000.0
	elif not on and state == S.BLOCK:
		_set_state(S.IDLE)

func try_ability() -> bool:
	var ab := _active_ability()
	if ab.is_empty() or state != S.IDLE or float(cooldowns.get("ability", 0.0)) > 0.0:
		return false
	_face_input()
	set_cd("ability", float(ab["cooldown"]) * cd_scale)
	cast_done = false
	_set_state(S.CAST)
	rig.play("cast", 0.55)
	Sfx.play(str(ab.get("sfx", "energy")))
	if self is Player:
		GameState.stat("abilities")
	return true

func try_spin() -> bool:
	if power_stolen:
		return false
	if float(cooldowns.get("spin", 0.0)) > 0.0:
		return false
	if state != S.IDLE and state != S.BLOCK:
		return false
	set_cd("spin", float(CharacterDB.SPIN["cooldown"]))
	_set_state(S.SPIN)
	spin_tick = 0.1
	tornado.visible = true
	Sfx.play("spin")
	if self is Player:
		GameState.stat("spins")
	return true

func try_jump() -> bool:
	if is_on_floor() and (state == S.IDLE or state == S.BLOCK):
		velocity.y = 9.0
		Sfx.play("jump")
		return true
	return false

# ---- damage ---------------------------------------------------------------
func take_damage(amount: float, src: Node3D, kb := 6.0, stun := 0.0, ignore_block := false) -> bool:
	if state == S.DEAD or invuln > 0.0 or amount <= 0.0:
		return false
	var dir := -face_dir
	if src != null and is_instance_valid(src):
		var d := global_position - src.global_position
		d.y = 0.0
		if d.length() > 0.01:
			dir = d.normalized()
	if state == S.BLOCK and not ignore_block and face_dir.dot(-dir) > 0.2:
		var now := Time.get_ticks_msec() / 1000.0
		if now - block_since < perfect_window:
			if src is Fighter:
				(src as Fighter).apply_stagger(0.9, -dir * 6.0)
			counter_window = 0.9
			if self is Player:
				GameState.stat("perfect_blocks")
			Sfx.play("block", 1.5)
			Effects.burst(self, global_position + Vector3(0, 1.2, 0), Color(1, 1, 0.4), 16, 6.0)
			return false
		amount *= block_reduce
		kb *= 0.3
		stun = 0.0
		Sfx.play("block")
	health = maxf(0.0, health - amount)
	rig.flash_t = 0.12
	health_changed.emit(self)
	if team == "player" and not (self is Companion):
		Sfx.play("hurt")
	if health <= 0.0:
		_die()
		return true
	if stun > 0.0 or (kb > 0.0 and amount > poise):
		apply_stagger(maxf(0.3, stun), dir * kb)
	elif kb > 0.0:
		knock = dir * kb * 0.25
	return true

func apply_stagger(t: float, kb_vec := Vector3.ZERO) -> void:
	if state == S.DEAD:
		return
	knock = kb_vec
	stagger_time = t
	_set_state(S.STAGGER)
	rig.play("stagger", t)

func _die() -> void:
	if on_zero_health():
		return
	_set_state(S.DEAD)
	remove_from_group("fighters")
	if is_in_group("enemies"):
		remove_from_group("enemies")
	tornado.visible = false
	rig.freeze()
	var tw := create_tween()
	tw.tween_property(rig.body, "rotation:x", 1.5, 0.45)
	set_deferred("collision_layer", 0)
	Sfx.play("thud")
	died.emit(self)
	if not (self is Player):
		get_tree().create_timer(2.5).timeout.connect(queue_free)

func nearest_foe(from: Vector3, max_d := 1.0e9) -> Fighter:
	var best: Fighter = null
	var bd := max_d
	for n in get_tree().get_nodes_in_group("fighters"):
		var f := n as Fighter
		if f == null or f.team == team or f.state == S.DEAD or f.downed:
			continue
		var d := f.global_position.distance_to(from)
		if d < bd:
			bd = d
			best = f
	return best

# ---- v2 helpers ------------------------------------------------------------
func dmg_scale() -> float:
	return dmg_mult * skill_dmg * (1.3 if statuses.has("empower") else 1.0)

func _active_ability() -> Dictionary:
	if power_stolen:
		return CharacterDB.FOCUS
	return ability

func refresh_power_state() -> void:
	power_stolen = GameState.powers_stolen.has(char_id)
	if rig != null:
		rig.set_drained(power_stolen)

func rebuild_rig() -> void:
	var old := rig
	var yaw := old.rotation.y
	rig = Minifig.new()
	add_child(rig)
	rig.build(rig_cfg)
	rig.rotation.y = yaw
	old.queue_free()
	refresh_power_state()

func setup_costume() -> void:
	var d: Dictionary = CharacterDB.DATA[char_id]
	rig_cfg = CostumeDB.apply({"suit": d["suit"], "style": "ninja", "weapon": Minifig.WEAPONS.get(char_id, "")}, GameState.costume)
	rebuild_rig()
