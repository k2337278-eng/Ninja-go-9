class_name Enemy
extends Fighter
## Tournament opponent AI: approach, strafe, telegraphed attack, global attack
## spacing so groups do not all strike at once.

static var _last_attack_ms := 0

var target: Fighter
var kind := "grunt"
var next_attack := 1.0
var attack_range := 1.9
var atk_damage := 8.0
var strafe_dir := 1.0
var strafe_t := 0.0
var xp_reward := 15
var coin_reward := 3

static func make(k: String) -> Enemy:
	var e := Enemy.new()
	e.kind = k
	e.team = "enemy"
	e.display_name = k
	e.char_id = "enemy_" + k
	if k.begins_with("rival:"):
		_make_rival(e, k.substr(6))
		e.health = e.max_health
		return e
	match k:
		"grunt":
			e.max_health = 60.0
			e.move_speed = 4.2
			e.atk_damage = 8.0
			e.xp_reward = 15
			e.coin_reward = 3
			e.rig_cfg = {"suit": Color(0.3, 0.15, 0.4), "style": "bare", "hair": Color(0.1, 0.1, 0.1)}
		"brute":
			e.max_health = 140.0
			e.move_speed = 3.4
			e.atk_damage = 14.0
			e.poise = 10.0
			e.attack_range = 2.2
			e.xp_reward = 35
			e.coin_reward = 8
			e.rig_cfg = {"suit": Color(0.6, 0.28, 0.08), "style": "bare", "hair": Color(0.25, 0.1, 0.05), "scale": 1.2}
		"dummy":
			e.max_health = 25.0
			e.move_speed = 0.0
			e.atk_damage = 0.0
			e.xp_reward = 5
			e.coin_reward = 0
			e.rig_cfg = {"suit": Color(0.9, 0.5, 0.1), "style": "bare", "hat": Color(0.8, 0.1, 0.1)}
		"elite":
			e.max_health = 110.0
			e.move_speed = 4.8
			e.atk_damage = 12.0
			e.poise = 4.0
			e.xp_reward = 30
			e.coin_reward = 6
			e.rig_cfg = {"suit": Color(0.15, 0.2, 0.45), "style": "ninja"}
		"serpent":
			e.max_health = 80.0
			e.move_speed = 5.0
			e.atk_damage = 10.0
			e.xp_reward = 22
			e.coin_reward = 4
			e.rig_cfg = {"suit": Color(0.2, 0.35, 0.15), "style": "ninja"}
		"anacondrai":
			e.max_health = 85.0
			e.move_speed = 4.8
			e.atk_damage = 11.0
			e.poise = 3.0
			e.xp_reward = 24
			e.coin_reward = 4
			e.rig_cfg = {"suit": Color(0.3, 0.12, 0.4), "style": "ninja", "hat": Color(0.15, 0.4, 0.15)}
		"guard":
			e.max_health = 90.0
			e.move_speed = 4.4
			e.atk_damage = 11.0
			e.poise = 6.0
			e.xp_reward = 25
			e.coin_reward = 5
			e.rig_cfg = {"suit": Color(0.35, 0.4, 0.5), "style": "bare", "hair": Color(0.1, 0.1, 0.1)}
		_:
			e.max_health = 100.0
			e.move_speed = 5.0
			e.atk_damage = 10.0
			e.xp_reward = 40
			e.coin_reward = 10
			e.rig_cfg = {"suit": Color(0.1, 0.5, 0.55), "style": "ninja"}
	var wk := {"grunt": "club", "brute": "hammer", "elite": "sword", "serpent": "spear", "anacondrai": "spear", "guard": "spear", "contender": "sword"}
	e.rig_cfg["weapon"] = wk.get(k, "")
	e.health = e.max_health
	return e

func _ready() -> void:
	add_to_group("enemies")
	super()

func think(delta: float) -> void:
	if kind == "dummy":
		move_input = Vector3.ZERO
		aim_dir = Vector3.ZERO
		return
	next_attack -= delta
	strafe_t -= delta
	move_input = Vector3.ZERO
	aim_dir = Vector3.ZERO
	if target == null or not is_instance_valid(target) or target.state == S.DEAD or target.downed:
		target = nearest_foe(global_position)
	if target == null or state != S.IDLE:
		return
	var to := target.global_position - global_position
	to.y = 0.0
	var dist := to.length()
	if dist < 0.01:
		return
	var dirn := to / dist
	aim_dir = dirn
	if dist > attack_range * 0.85:
		move_input = dirn
	else:
		if strafe_t <= 0.0:
			strafe_t = randf_range(1.0, 2.5)
			strafe_dir = 1.0 if randf() > 0.5 else -1.0
		move_input = dirn.cross(Vector3.UP) * strafe_dir * 0.5
	# separation from other enemies
	for n in get_tree().get_nodes_in_group("enemies"):
		var o := n as Fighter
		if o == null or o == self:
			continue
		var away := global_position - o.global_position
		away.y = 0.0
		if away.length() < 1.3 and away.length() > 0.01:
			move_input += away.normalized() * 0.8
	move_input = move_input.limit_length(1.0)
	if not ability.is_empty() and state == S.IDLE and float(cooldowns.get("ability", 0.0)) <= 0.0 \
			and dist > 4.0 and dist < float(ability.get("range", 8.0)) * 0.75 and randf() < 0.03:
		rig.warn_t = 0.5
		try_ability()
		return
	if dist <= attack_range and next_attack <= 0.0:
		var now := Time.get_ticks_msec()
		if now - _last_attack_ms < 700:
			next_attack = 0.3
			return
		_last_attack_ms = now
		face_dir = dirn
		rig.warn_t = 0.55
		begin_attack({"anim": "enemy_atk", "dur": 0.95, "hit": 0.6, "dmg": atk_damage,
			"rng": attack_range + 0.3, "arc": 100.0, "kb": 6.0, "combo": false, "stun": 0.0})
		next_attack = randf_range(1.6, 2.6)

## Elemental rival: uses another ninja's element/ability at reduced power.
static func _make_rival(e: Enemy, id: String) -> void:
	var d: Dictionary = CharacterDB.DATA[id]
	e.max_health = 160.0
	e.move_speed = 5.5
	e.atk_damage = 12.0
	e.poise = 4.0
	e.xp_reward = 60
	e.coin_reward = 20
	var ab: Dictionary = (d["ability"] as Dictionary).duplicate()
	ab["damage"] = float(ab["damage"]) * 0.6
	ab["cooldown"] = float(ab["cooldown"]) * 1.6
	e.ability = ab
	e.rig_cfg = {"suit": d["suit"], "style": "ninja", "weapon": Minifig.WEAPONS.get(id, "")}
