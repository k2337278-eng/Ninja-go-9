extends Node
## Minimal AR/EN localisation. Story text uses Loc.pick([en, ar]) inline.

var lang := "ar"

const T := {
	"title": ["NINJAGO: Tournament of Elements", "نينجاجو: بطولة العناصر"],
	"subtitle": ["Season 4 story - 10 chapters (fan project)", "قصة الموسم الرابع - 10 فصول (مشروع معجبين)"],
	"continue": ["Continue", "متابعة"],
	"new_game": ["New Game", "لعبة جديدة"],
	"settings": ["Settings", "الإعدادات"],
	"quit": ["Quit", "خروج"],
	"language": ["Language: English", "اللغة: العربية"],
	"quality": ["Graphics: %s", "الرسوم: %s"],
	"q0": ["Low", "منخفضة"],
	"q1": ["Medium", "متوسطة"],
	"q2": ["High", "عالية"],
	"music": ["Music: %d%%", "الموسيقى: %d%%"],
	"vol_voice": ["Voice: %d%%", "الصوت والكلام: %d%%"],
	"vol_music": ["Music: %d%%", "الموسيقى: %d%%"],
	"vol_sfx": ["Effects: %d%%", "المؤثرات: %d%%"],
	"back": ["Back", "رجوع"],
	"choose": ["Choose your ninja", "اختر نينجاك"],
	"start": ["Start", "ابدأ"],
	"pause": ["Paused", "إيقاف مؤقت"],
	"resume": ["Resume", "استئناف"],
	"save": ["Save", "حفظ"],
	"saved": ["Game saved", "تم الحفظ"],
	"menu": ["Main Menu", "القائمة الرئيسية"],
	"retry": ["Retry", "إعادة المحاولة"],
	"defeat": ["Defeated", "هُزمت"],
	"level": ["Lv %d", "م %d"],
	"stat_hp": ["Health", "الصحة"],
	"stat_speed": ["Speed", "السرعة"],
	"stat_atk": ["Attack", "الهجوم"],
	"stat_power": ["Power", "القدرة"],
	"narrator": ["Narrator", "الراوي"],
	"el_fire": ["Fire", "النار"],
	"el_lightning": ["Lightning", "البرق"],
	"el_earth": ["Earth", "الأرض"],
	"el_ice": ["Ice", "الجليد"],
	"el_energy": ["Energy", "الطاقة"],
	"el_absorb": ["Absorption", "الامتصاص"],
	"el_water": ["Water", "الماء"],
	"el_serpent": ["Serpent", "الثعبان"],
	"upgrades": ["Upgrades", "الترقيات"],
	"missions": ["Mission Select", "اختيار المهمة"],
	"close": ["Close", "إغلاق"],
	"ok": ["OK", "موافق"],
	"map": ["Map", "الخريطة"],
	"inventory": ["Inventory", "المخزون"],
}

func pick(arr: Array) -> String:
	return arr[0] if lang == "en" else arr[1]

func t(key: String) -> String:
	if not T.has(key):
		return key
	return pick(T[key])

func set_lang(l: String) -> void:
	lang = l
