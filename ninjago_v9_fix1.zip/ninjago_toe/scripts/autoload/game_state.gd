extends Node
## Progress, settings and save/load (JSON in user://). No cloud, no payments.

const SAVE_PATH := "user://save.json"
const SETTINGS_PATH := "user://settings.json"

signal progress_changed

var selected_char := ""
var unlocked: Array = ["kai", "jay", "cole", "zane", "lloyd"]
var coins := 0
var xp := 0
var level := 1
var points := 0
var chapter := 1
var story_step := 0
var chapter_done := false
var collected: Array = []
var settings := {"lang": "ar", "quality": 1, "music": 0.7, "sfx": 1.0, "voice": 1.0}

signal powers_changed
signal achievement_unlocked(id: String)

var max_step := 0
var skill_points := 0
var skills := {}
var weapon_level := 0
var costume := "default"
var achievements: Array = []
var stats := {}
var flags := {}
var ratings := {}
var deaths_chapter := 0
var powers_stolen: Array = []   # unused by the season-4 story (no ninja loses powers); kept for the mechanics
var captured: Array = []        # unused by the season-4 story
var tournament_log: Array = []  # session only

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	load_settings()
	load_game()
	Loc.set_lang(settings["lang"])

func has_save() -> bool:
	return selected_char != ""

func new_game(id: String) -> void:
	selected_char = id
	coins = 0
	xp = 0
	level = 1
	points = 0
	chapter = 1
	story_step = 0
	chapter_done = false
	collected = []
	reset_progress()
	save_game()

func xp_needed() -> int:
	return 100 + 50 * (level - 1)

func add_xp(a: int) -> void:
	xp += a
	while xp >= xp_needed():
		xp -= xp_needed()
		level += 1
		skill_points += 1
	stats["level"] = level
	check_achievements()
	progress_changed.emit()

func add_coins(n: int) -> void:
	coins += n
	progress_changed.emit()

func damage_multiplier() -> float:
	return 1.0 + 0.05 * (level - 1)

func health_multiplier() -> float:
	return 1.0 + 0.04 * (level - 1)

func save_game() -> void:
	if selected_char == "":
		return
	var d := {
		"version": 3, "selected_char": selected_char, "unlocked": unlocked,
		"coins": coins, "xp": xp, "level": level, "points": points,
		"chapter": chapter, "story_step": story_step, "chapter_done": chapter_done,
		"collected": collected,
		"max_step": max_step, "skill_points": skill_points, "skills": skills,
		"weapon_level": weapon_level, "costume": costume, "achievements": achievements,
		"stats": stats, "flags": flags, "ratings": ratings, "deaths_chapter": deaths_chapter,
	}
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(d))

func load_game() -> void:
	if not FileAccess.file_exists(SAVE_PATH):
		return
	var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if f == null:
		return
	var p = JSON.parse_string(f.get_as_text())
	if typeof(p) != TYPE_DICTIONARY:
		return
	selected_char = str(p.get("selected_char", ""))
	unlocked = p.get("unlocked", unlocked)
	coins = int(p.get("coins", 0))
	xp = int(p.get("xp", 0))
	level = int(p.get("level", 1))
	points = int(p.get("points", 0))
	chapter = int(p.get("chapter", 1))
	story_step = int(p.get("story_step", 0))
	chapter_done = bool(p.get("chapter_done", false))
	collected = []
	for c in p.get("collected", []):
		collected.append(int(c))
	max_step = maxi(int(p.get("max_step", 0)), story_step)
	skill_points = int(p.get("skill_points", 0))
	skills = p.get("skills", {})
	weapon_level = int(p.get("weapon_level", 0))
	costume = str(p.get("costume", "default"))
	achievements = p.get("achievements", [])
	stats = p.get("stats", {})
	flags = p.get("flags", {})
	ratings = p.get("ratings", {})
	deaths_chapter = int(p.get("deaths_chapter", 0))
	# v1 saves used the OLD (invented) story numbering. Story progress is reset; upgrades/coins are kept.
	if int(p.get("version", 1)) < 3:
		story_step = 0
		max_step = 0
		chapter_done = false
		flags = {}
		ratings = {}
		deaths_chapter = 0
		selected_char = "kai"

func save_settings() -> void:
	var f := FileAccess.open(SETTINGS_PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(settings))

func load_settings() -> void:
	if not FileAccess.file_exists(SETTINGS_PATH):
		return
	var f := FileAccess.open(SETTINGS_PATH, FileAccess.READ)
	if f == null:
		return
	var p = JSON.parse_string(f.get_as_text())
	if typeof(p) == TYPE_DICTIONARY:
		for k in p.keys():
			settings[k] = p[k]

func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_CLOSE_REQUEST:
		save_game()
		save_settings()

# ---------------------------------------------------------------- v2 -------
func reset_progress() -> void:
	max_step = 0
	skill_points = 0
	skills = {}
	weapon_level = 0
	costume = "default"
	achievements = []
	stats = {}
	flags = {}
	ratings = {}
	deaths_chapter = 0
	powers_stolen = []
	captured = []
	tournament_log = []

func weapon_multiplier() -> float:
	return 1.0 + 0.1 * weapon_level

func stat(n: String, d := 1) -> void:
	stats[n] = int(stats.get(n, 0)) + d
	check_achievements()

func count_ids(lo: int, hi: int) -> int:
	var c := 0
	for i in collected:
		if int(i) >= lo and int(i) <= hi:
			c += 1
	return c

func award(id: String) -> void:
	if achievements.has(id):
		return
	achievements.append(id)
	achievement_unlocked.emit(id)
	save_game()

func check_achievements() -> void:
	for id in AchievementDB.ORDER:
		var d: Dictionary = AchievementDB.DATA[id]
		if d.has("stat") and not achievements.has(id) and int(stats.get(d["stat"], 0)) >= int(d["need"]):
			award(id)
	if int(stats.get("coins_collected", 0)) >= 20 and int(stats.get("relics", 0)) >= 12 and int(stats.get("scrolls", 0)) >= 6:
		award("completionist")

func steal_power(id: String) -> void:
	if not powers_stolen.has(id):
		powers_stolen.append(id)
	powers_changed.emit()

func restore_power(id: String) -> void:
	powers_stolen.erase(id)
	powers_changed.emit()

# ---- Jadeblades: one piece per chapter, earned by an achievement or a hidden puzzle (docs/GAMEPLAY_DESIGN.md) ----
func jade_count() -> int:
	var c := 0
	for i in range(1, 11):
		if bool(flags.get("jade_%d" % i, false)):
			c += 1
	return c

## Gives chapter n's piece once. Rewards: +2 skill points each; 4 and 8 pieces: weapon +1 level;
## 5 pieces: Jade Gi costume; 10 pieces: +5 skill points + achievement. Returns true when newly awarded.
func award_jade(n: int) -> bool:
	var k := "jade_%d" % n
	if bool(flags.get(k, false)):
		return false
	flags[k] = true
	skill_points += 2
	var c := jade_count()
	if c == 4 or c == 8:
		weapon_level += 1
	if c >= 10:
		skill_points += 5
		award("jade_master")
	save_game()
	return true
