class_name ElementTarget
extends Interactable
## A sealed barrier opened by a matching elemental ability. Press USE nearby to ask the
## ninja with that element (you or an AI companion) to cast at it, or hit it yourself.
## If that ninja's power is stolen the puzzle cannot be solved until it is restored.

signal activated

const COLORS := {"fire": Color(1.0, 0.45, 0.1), "lightning": Color(0.5, 0.8, 1.0),
	"earth": Color(0.55, 0.4, 0.25), "ice": Color(0.6, 0.9, 1.0), "energy": Color(0.4, 1.0, 0.5)}

var element := "fire"
var flag_id := ""
var blocker_size := Vector3(3, 3, 0.6)
var hit_radius := 2.4
var done := false
var blocker: Node3D

func _ready() -> void:
	super()
	radius = 7.0
	add_to_group("element_target")
	if flag_id != "" and GameState.flags.get(flag_id, false):
		done = true
		remove_from_group("interactable")
		remove_from_group("element_target")
		return
	blocker = Node3D.new()
	add_child(blocker)
	var col: Color = COLORS.get(element, Color.WHITE)
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = blocker_size
	var m := StandardMaterial3D.new()
	m.albedo_color = col.darkened(0.35)
	m.emission_enabled = true
	m.emission = col
	m.emission_energy_multiplier = 0.5
	bm.material = m
	mi.mesh = bm
	blocker.add_child(mi)
	var sb := StaticBody3D.new()
	var cs := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = blocker_size
	cs.shape = bs
	sb.add_child(cs)
	blocker.add_child(sb)

func prompt_text() -> String:
	return Loc.pick(["Use %s power", "استخدم قوة %s"]) % Loc.t("el_" + element)

func can_use(_p: Player) -> bool:
	return not done

func on_element(el: String, _src) -> bool:
	if done:
		return false
	if el == element:
		_complete()
	return true

func _complete() -> void:
	done = true
	if flag_id != "":
		GameState.flags[flag_id] = true
	remove_from_group("interactable")
	remove_from_group("element_target")
	var col: Color = COLORS.get(element, Color.WHITE)
	Effects.burst(self, global_position + Vector3(0, 1.2, 0), col, 40, 8.0)
	Effects.ring(self, global_position, 4.0, col)
	Effects.shake(self, 0.25)
	Sfx.play("win", 1.2)
	if blocker != null:
		var tw := create_tween()
		tw.tween_property(blocker, "scale", Vector3(0.01, 0.01, 0.01), 0.6)
		tw.tween_callback(blocker.queue_free)
	activated.emit()

func _elem_of(f: Fighter) -> String:
	return str((CharacterDB.DATA.get(f.char_id, {}) as Dictionary).get("element", ""))

func use(p: Player) -> void:
	var caster: Fighter = null
	if _elem_of(p) == element:
		caster = p
	else:
		for n in get_tree().get_nodes_in_group("fighters"):
			var c := n as Companion
			if c != null and _elem_of(c) == element and not c.downed:
				caster = c
				break
	if caster == null:
		p.feedback.emit(Loc.pick(["No ninja with %s power is nearby.", "لا يوجد نينجا بقوة %s قريب."]) % Loc.t("el_" + element))
		return
	if caster.power_stolen:
		p.feedback.emit(Loc.pick(["%s's power has been drained!", "قوة %s مسلوبة!"]) % caster.display_name)
		return
	if float(caster.cooldowns.get("ability", 0.0)) > 0.0 or caster.state != Fighter.S.IDLE:
		p.feedback.emit(Loc.pick(["%s needs a moment...", "%s يحتاج لحظة..."]) % caster.display_name)
		return
	var to := global_position - caster.global_position
	to.y = 0.0
	var d := to.length()
	var dir := to.normalized() if d > 0.1 else caster.face_dir
	var ab: Dictionary = caster.ability
	var reach := 14.0
	if ab.get("kind", "") != "projectile":
		reach = float(ab["radius"]) + (3.0 if ab.get("center", "self") == "front" else 0.0) - 0.5
	if d > reach:
		if caster is Companion:
			caster.global_position = global_position - dir * minf(reach, 3.2) + Vector3(0, 0.3, 0)
		else:
			p.feedback.emit(Loc.pick(["Get closer.", "اقترب أكثر."]))
			return
	caster.aim_dir = dir
	caster.face_dir = dir
	caster.try_ability()
