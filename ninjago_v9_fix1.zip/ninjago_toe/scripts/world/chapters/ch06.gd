class_name Ch06
extends ChapterBase
## Chapter 6 - Spellbound (ep. 40), per STORY_SPEC v2: Kai and Skylor search for Nya (Chen lured the contestants
## into hunting her), Chen's men seize the D.B. Express, Lloyd opens his energy dragon, Garmadon's and Chen's past
## comes out through a letter, Kai learns Skylor is Chen's daughter and they quarrel, flashback of the Anacondrai war
## (General Arcturus).
## v8 beats: Kai+Skylor search -> D.B. Express seized (Eyezor) -> Lloyd's ambush + energy dragon -> the letter and the
## flashback -> Kai/Skylor quarrel.
## Hooks: ch06_chen_chases_nya, ch06_kai_skylor_search, ch06_db_express_seized, ch06_energy_dragon, ch06_misako_letter,
## ch06_garmadon_past, ch06_arcturus_flashback, ch06_skylor_reveal.
## VERIFY: who rides the D.B. Express and how Chen's men take it; Eyezor, Kapau and Chope as the men on the hunt (the spec
## names them for ch. 6-8 without detailing this episode); the author and content of the letter (not shown); the look of
## the flashback; all gates, ambushes, climbs and notes are gameplay padding with Chen's followers.

func _init() -> void:
	num = 6
	title = ["Spellbound", "مسحورون"]

func beats() -> Array:
	var kp: Array = ["skylor"]
	var lp: Array = ["jay"]
	return [
		beat("ch06_search", "kai", kp, Vector3(26, 0.2, 12), _b0),
		beat("ch06_nya_chase", "nya", [], Vector3(40, 0.2, 20), _bc),
		beat("ch06_express", "kai", kp, Vector3(34, 0.2, -22), _b1),
		beat("ch06_dragon", "lloyd", lp, Vector3(30, 0.2, -12), _b2),
		beat("ch06_past", "lloyd", lp, Vector3(30, 0.2, -16), _b3),
		beat("ch06_flashback", "cole", [], Vector3(30, 0.2, -16), _bf, "dusk"),
		beat("ch06_quarrel", "kai", kp, Vector3(26, 0.2, -16), _b4),
	]

func _b0() -> bool:
	await begin()
	goals([["Search the forest for Nya's trail", "فتّش الغابة بحثًا عن أثر نيا"], ["Open the hunters' gate", "افتح بوابة الصيادين"],
		["Beat the first patrol", "اهزم الدورية الأولى"], ["Slip past the hunters' camp", "تسلّل من معسكر الصيادين"],
		["Read the hunters' orders (optional)", "اقرأ أوامر الصيادين (اختياري)"], ["Find the lantern toy (optional)", "اعثر على لعبة الفانوس (اختياري)"]])
	note(Vector3(32, 0, 18), "Hunters' Orders", "أوامر الصيادين",
		"Orders pinned to a tree: 'Sweep the woods. Take her alive. Make it look like a game.'",
		"أوامر مثبتة على شجرة: 'مشّطوا الغابة. أمسكوها حيّة. واجعلوا الأمر يبدو كلعبة.'", "ch6_orders")
	note(Vector3(22, 0, 2), "Wooden Lantern Toy", "لعبة فانوس خشبية",
		"A child's wooden toy, left at the edge of the trail. It is oddly well kept.",
		"لعبة خشبية لطفل، تُركت عند طرف الدرب. محفوظة بشكل غريب.", "ch6_toy")
	await hook("ch06_chen_chases_nya",
		"Chen lures the contestants into hunting Nya, who has proof of his plan, promising the winners a place in the next round.",
		"يغري تشِن المتسابقين بمطاردة نيا، التي تحمل دليلًا على خطته، واعدًا الفائزين بمكان في الجولة التالية.",
		Vector3(30, 8, 20), Vector3(26, 1, 10))
	await say([
		ln("eyezor", "The master wants her found. Whoever brings her in moves up a round.", "السيد يريد العثور عليها. ومن يحضرها يتقدّم جولة."),
		ln("kapau", "Spread out. Check every bush.", "تفرّقوا. فتّشوا كل شجيرة."),
		ln("chope", "And if she runs, we run faster.", "وإن هربت، نركض أسرع منها."),
	])
	await hook("ch06_kai_skylor_search",
		"Kai and Skylor set out together to find Nya before the hunters do.",
		"يخرج كاي وسكايلور معًا للعثور على نيا قبل الصيادين.",
		Vector3(24, 4, 18), Vector3(26, 1.5, 10))
	await say([
		ln("skylor", "I know these woods. Stay close and stay quiet.", "أعرف هذه الغابة. ابقَ قريبًا وهادئًا."),
		me("I will follow you. But I am watching where you lead.", "سأتبعك. لكنني أراقب إلى أين تقودين."),
	])
	if not await checkpoints([Vector3(26, 0, 6), Vector3(38, 0, -8), Vector3(34, 0, -22), Vector3(26, 0, -30)], "Search the forest", "فتّش الغابة", 0.0, Color(0.4, 1.0, 0.5)):
		return false
	goal_done(0)
	isl.hud.set_objective(L("A hunters' gate bars the trail: pull the lever.", "بوابة للصيادين تسدّ الدرب: اسحب الذراع."))
	if not await lever_door(Vector3(26, 0, -32), Vector3(8, 3, 1), Vector3(32, 0, -30)):
		return false
	goal_done(1)
	checkpoint()
	if not await waves([["guard", "guard"], ["guard", "grunt", "grunt"]], Vector3(26, 0, -36), 8.0, "Fight the patrol", "قاتل الدورية"):
		return false
	goal_done(2)
	var wz: Array = [{"c": Vector3(30, 0, -26), "amp": Vector3(5, 0, 0), "speed": 1.2, "r": 3.2}, {"c": Vector3(34, 0, -32), "amp": Vector3(0, 0, 4), "speed": 1.6, "r": 3.0}]
	if not await stealth([Vector3(34, 0, -28), Vector3(30, 0, -34)], wz, Vector3(26, 0.2, -30), "Slip past the hunters' camp", "تسلّل من معسكر الصيادين"):
		return false
	goal_done(3)
	if flag_set("ch6_orders"):
		goal_done(4)
		side_reward("ch6_orders", "the hunters' orders", "أوامر الصيادين")
	if flag_set("ch6_toy"):
		goal_done(5)
		side_reward("ch6_toy", "the toy", "اللعبة")
	return isl._alive()

# Chen's men seize the D.B. Express. Eyezor leads them (VERIFY).
func _b1() -> bool:
	goals([["Reach the road where the D.B. Express waits", "اصل إلى الطريق حيث تنتظر دي بي إكسبرس"], ["Hold off Chen's men", "صدّ رجال تشِن"],
		["Face Eyezor", "واجه آيزور"], ["Get Skylor clear", "أخرج سكايلور بأمان"]])
	if not await checkpoints([Vector3(34, 0, -16), Vector3(30, 0, -22)], "Reach the road", "اصل إلى الطريق", 0.0, Color(1.0, 0.8, 0.3)):
		return false
	goal_done(0)
	await hook("ch06_db_express_seized",
		"Chen's men close in and seize the D.B. Express before Kai and Skylor can reach it.",
		"يطبق رجال تشِن ويستولون على دي بي إكسبرس قبل أن يصل إليه كاي وسكايلور.",
		Vector3(40, 5, -14), Vector3(32, 1.5, -22))
	await say([
		ln("eyezor", "The vehicle is ours. Hand over whoever was riding it.", "المركبة صارت لنا. سلّمونا من كان يركبها."),
		ln("skylor", "Eyezor, this is not what my father asked for.", "آيزور، هذا ليس ما طلبه أبي."),
		ln("eyezor", "Your father asks for many things, miss.", "أبوك يطلب أشياء كثيرة يا آنسة."),
	])
	if not await waves([["guard", "guard", "grunt"], ["elite", "guard"]], Vector3(32, 0, -22), 8.0, "Hold off Chen's men", "صدّ رجال تشِن"):
		return false
	goal_done(1)
	checkpoint()
	if not await duel("eyezor", Vector3(32, 0.3, -26), "Defeat Eyezor!", "اهزم آيزور!", 0.35):
		return false
	goal_done(2)
	await say([
		ln("eyezor", "Enough. I have what I came for. Tell the girl her friends are not safe.", "كفى. حصلت على ما جئت من أجله. قولوا للفتاة إن أصدقاءها ليسوا في أمان."),
		ln("skylor", "He took it. He actually took it.", "أخذها. فعلًا أخذها."),
	])
	if not await survive(20.0, "guard", Vector3(32, 0, -22), 3, "Stragglers close in", "المتأخرون يقتربون"):
		return false
	goal_done(3)
	return isl._alive()

func _b2() -> bool:
	goals([["Climb the lookout rock", "تسلّق صخرة المراقبة"], ["Hold the trail against the ambush", "احمِ الدرب من الكمين"],
		["Break the ambush", "اكسر الكمين"], ["Focus your energy at the stone", "ركّز طاقتك عند الحجر"], ["Clear the survivors", "أخلِ الناجين"]])
	isl.hud.set_objective(L("Climb the lookout rock to scout the clearing.", "تسلّق صخرة المراقبة لاستطلاع المساحة."))
	if not await climb_lever(Vector3(36, 0, -8), Vector3(0, 0, -1), 3.5):
		return false
	goal_done(0)
	await say([ln("jay", "I see them. They are circling us.", "أراهم. يطوّقوننا."), ln("jay", "Great. A ring of angry strangers. My favorite shape.", "رائع. حلقة من الغرباء الغاضبين. شكلي المفضل.")])
	if not await survive(30.0, "guard", Vector3(30, 0, -12), 4, "Hold the trail", "احمِ الدرب"):
		return false
	goal_done(1)
	checkpoint()
	if not await waves([["guard", "grunt", "brute"], ["elite", "guard", "guard"], ["brute", "elite"]], Vector3(30, 0, -12), 9.0, "Break the ambush", "اكسر الكمين"):
		return false
	goal_done(2)
	await say([
		me("There are too many of them. Something inside me is pushing back harder than I am.", "هم كثيرون. شيء بداخلي يدفع أقوى مني."),
		ln("jay", "Lloyd, whatever that is, let it out. Now.", "لويد، مهما كان ذلك، أطلقه. الآن."),
	])
	if not await waves([["guard", "anacondrai"], ["guard", "guard", "anacondrai"]], Vector3(30, 0, -22), 9.0, "Fight the first ring", "قاتل الحلقة الأولى"):
		return false
	var st := place_stone(Vector3(30, 0, -22), Color(0.4, 1.0, 0.5), "Focus your energy", "ركّز طاقتك")
	for i in 6:
		isl.spawn_enemy("guard" if i % 2 == 0 else "anacondrai", ring_pos(Vector3(30, 0, -22), 10.0, i, 6))
	isl.hud.set_objective(L("Focus your energy at the glowing stone (USE)!", "ركّز طاقتك عند الحجر المتوهج (USE)!"))
	if not await wait_stone(st):
		return false
	goal_done(3)
	await hook("ch06_energy_dragon",
		"Lloyd's energy dragon awakens, a great green serpent of light that scatters the enemy.",
		"يستيقظ تنين الطاقة للويد، ثعبان أخضر عظيم من الضوء يبعثر الأعداء.",
		Vector3(24, 5, -12), Vector3(30, 3, -22))
	GameState.award("energy_dragon")
	await dragon_strike(Color(0.4, 1.0, 0.5), Vector3(30, 0, -22), 70.0)
	var left: Array = []
	for n in isl.get_tree().get_nodes_in_group("enemies"):
		if not n.is_in_group("practice"):
			left.append(n)
	if not left.is_empty() and not await isl.wait_enemies_dead(left):
		return false
	isl.clear_enemies()
	goal_done(4)
	await say([
		me("That was me? That dragon was me?", "كان ذلك أنا؟ ذلك التنين كان أنا؟"),
		ln("jay", "It was you, and it was awesome. Please do it again later.", "كان أنت، وكان رائعًا. أرجو أن تكرره لاحقًا."),
	])
	checkpoint()
	return isl._alive()

# The past comes out through a letter (VERIFY: author/content); then the Anacondrai war flashback (General Arcturus).
func _b3() -> bool:
	goals([["Open the letter", "افتح الرسالة"], ["Defend the clearing from the followers", "احمِ المساحة من الأتباع"],
		["Learn about the past", "تعرّف على الماضي"], ["Watch the flashback", "شاهد الاسترجاع"]])
	await say([ln("jay", "Company! Chen's followers followed the dragon's glow.", "ضيوف! أتباع تشِن تتبّعوا وهج التنين.")])
	if not await waves([["guard", "anacondrai", "anacondrai"], ["elite", "anacondrai", "anacondrai"]], Vector3(30, 0, -18), 9.0, "Defend the clearing", "احمِ المساحة"):
		return false
	goal_done(1)
	checkpoint()
	await hook("ch06_misako_letter",
		"A letter comes to light. It tells how Garmadon and Chen were once tied together. (VERIFY: its author and words.)",
		"تظهر رسالة. تحكي كيف ارتبط غارمادون وتشِن يومًا. (VERIFY: كاتبها وكلماتها.)",
		Vector3(30, 3, -12), Vector3(26, 1.5, -18))
	goal_done(0)
	await say([
		nr("The letter speaks of Garmadon and Chen, and of a time before either became what they are.", "تتحدث الرسالة عن غارمادون وتشِن، وعن زمن سبق أن يصير أي منهما كما هو."),
		me("My father knew him. That explains the way Chen looks at me.", "أبي عرفه. هذا يفسّر نظرة تشِن إليّ."),
	])
	await hook("ch06_garmadon_past",
		"The letter's past: Garmadon once stood with Chen and Clouse, in the days of the war.",
		"ماضي الرسالة: وقف غارمادون يومًا مع تشِن وكلاوس، في أيام الحرب.",
		Vector3(34, 5, -10), Vector3(28, 2, -18))
	goal_done(2)
	await hook("ch06_arcturus_flashback",
		"Flashback: the Anacondrai war, with their General Arcturus leading the army. (VERIFY: look and details.)",
		"استرجاع: حرب الأناكوندراي، والجنرال أركتوروس يقود جيشهم. (VERIFY: الشكل والتفاصيل.)",
		Vector3(30, 9, -6), Vector3(30, 2, -22))
	goal_done(3)
	await say([ln("arcturus", "(In the flashback his voice carries over the battlefield: hold the line.)", "(في الاسترجاع يعلو صوته فوق ساحة المعركة: اثبتوا في الصف.)")])
	goals_clear()
	return isl._alive()

func _b4() -> bool:
	goals([["Hear Skylor out", "اسمع سكايلور حتى النهاية"], ["Quarrel with her", "تخاصم معها"], ["Hold the clearing", "احمِ المساحة"]])
	var sk: Companion = isl.comp_by_id("skylor")
	await hook("ch06_skylor_reveal",
		"Kai learns the truth: Skylor is Chen's daughter. He is hurt, and they quarrel.",
		"يعرف كاي الحقيقة: سكايلور ابنة تشِن. يتألم، ويتخاصمان.",
		Vector3(32, 2.5, -14), Vector3(26, 1.5, -18))
	goal_done(0)
	await say([
		ln("skylor", "I should have told you sooner. Chen is my father.", "كان عليّ أن أخبرك قبل ذلك. تشِن هو أبي."),
		me("You let me trust you while you kept that from me.", "تركتِني أثق بكِ وأنتِ تخفين هذا عنّي."),
		ln("skylor", "I was afraid of exactly this.", "كنت أخاف من هذا بالضبط."),
		me("Then you were right to be. I need space.", "إذن كنتِ محقة في خوفك. أحتاج إلى مساحة."),
	])
	goal_done(1)
	if sk != null:
		sk.global_position += Vector3(-8, 0, 0)
	if not await survive(25.0, "guard", Vector3(26, 0, -16), 3, "Hold the clearing alone", "احمِ المساحة وحدك"):
		return false
	goal_done(2)
	jade_if(6, ["ch6_orders", "ch6_toy"], "Spellbound", "مسحورون")
	goals_clear()
	return await finish(1000.0)

## The hunt from Nya's side: lose Chen's hunters by reaching three hideouts. (Chase pacing is a gameplay choice.)
func _bc() -> bool:
	goals([["Lose the hunters (reach the 3 hideouts)", "اهربي من الصيادين (اصلي إلى المخابئ الثلاثة)"]])
	await say([
		nr("Word has spread through the contestants: whoever finds Nya moves up the bracket.", "انتشر الخبر بين المتسابقين: من يجد نيا يتقدم في الجدول."),
		me("Everyone is hunting me. Fine. I know this forest better than they do.", "الجميع يطاردني. حسنًا. أعرف هذه الغابة أفضل منهم."),
	])
	var pts: Array = [Vector3(46, 0, 10), Vector3(52, 0, -6), Vector3(40, 0, -20)]
	if not await checkpoints(pts, "Reach the hideouts", "اصلي إلى المخابئ", 70.0, Color(0.5, 1.0, 0.6), Vector3(40, 0.2, 20), "guard"):
		return false
	goal_done(0)
	await say([me("Lost them, for now. I have to warn the others.", "أضعتهم، الآن. يجب أن أحذّر الآخرين.")])
	goals_clear()
	return isl._alive()

## The Anacondrai war flashback as a short playable memory (VERIFY: who we play, the exact battle). General Arcturus fights beside you.
func _bf() -> bool:
	goals([["Hold the line beside General Arcturus", "اصمد في الصف بجانب الجنرال أركتوروس"], ["Survive the old war", "انجُ من الحرب القديمة"]])
	await say([
		nr("The vision pulls you into the old war between the Anacondrai and the Elemental Masters.", "تسحبك الرؤية إلى الحرب القديمة بين الأناكوندراي وماسترز العناصر."),
		ln("general", "Hold the line! They will not break us today.", "اصمدوا في الصف! لن يكسرونا اليوم."),
	])
	isl.add_companion("general", Vector3(30, 0.2, -20))
	if not await waves([["anacondrai", "guard"], ["anacondrai", "anacondrai", "elite"]], Vector3(30, 0, -14), 9.0, "Hold the line", "اصمد في الصف"):
		return false
	goal_done(0)
	if not await survive(25.0, "anacondrai", Vector3(30, 0, -14), 4, "Survive the old war", "انجُ من الحرب القديمة"):
		return false
	goal_done(1)
	await say([nr("The vision fades, and you stand in the clearing again.", "تتلاشى الرؤية، وتقف في المساحة من جديد.")])
	goals_clear()
	return isl._alive()
