class_name Ch05
extends ChapterBase
## Chapter 5 - Spy for a Spy (ep. 39). Spec: Nya spies among the contestants, finds the transformation
## spell, fights Clouse and escapes with the spell; Jay injures his foot; Kai and Skylor grow close.
## v4 beats: Nya sneak (3 watch zones + vine climb to the palace window + lever) -> Clouse (2 phases) and
## the timed escape with pursuers -> Kai/Skylor + Jay (talk goals, exhibition wave, optional note).
## Hooks: ch05_spy_among_them, ch05_spell_found, ch05_clouse_intro, ch05_escape, ch05_skylor_spy, ch05_jay_foot, ch05_kai_skylor.
## v6/v7: per STORY_SPEC v2 Skylor is Chen's spy inside the alliance (shown to the player in ch05_skylor_spy); Kai learns she is
## Chen's daughter in ch. 6. VERIFY: where the spell is kept (palace);
## how Jay's foot gets injured (only the result); Cole/Zane's whereabouts (still imprisoned).

func _init() -> void:
	num = 5
	title = ["Spy for a Spy", "جاسوس مقابل جاسوس"]

func beats() -> Array:
	return [
		beat("ch05_nya_sneak", "nya", [], Vector3(24, 0.2, -10), _b0),
		beat("ch05_clouse", "nya", [], Vector3(6, 0.2, -36), _b1),
		beat("ch05_escape", "nya", [], Vector3(0, 0.2, -34), _b2),
		beat("ch05_spy_hunt", "lloyd", ["kai", "jay"], Vector3(0, 0.2, 10), _bh),
		beat("ch05_kai_skylor", "kai", ["jay", "lloyd"], Vector3(0, 0.2, 10), _b3),
	]

func _b0() -> bool:
	await begin()
	goals([["Blend in with the contestants", "اندمجي بين المتسابقين"], ["Cross the yard in disguise", "اعبري الساحة متنكّرة"],
		["Reach the palace front unseen", "اصلي إلى مقدمة القصر دون أن يراك أحد"], ["Find the spell", "اعثري على التعويذة"],
		["Take the guard's note (optional)", "خذي مذكرة الحارس (اختياري)"]])
	note(Vector3(18, 0, -34), "Guard's Note", "مذكرة الحارس",
		"A shift list pinned beside a door: who guards the palace, and when they change. Useful to a spy.",
		"قائمة مناوبات مثبتة بجانب باب: من يحرس القصر ومتى يتبدّلون. مفيدة لجاسوسة.", "ch5_note")
	await hook("ch05_spy_among_them",
		"Nya now walks among the contestants in disguise, a spy trying not to look like one.",
		"تتجول نيا الآن بين المتسابقين متنكّرة، جاسوسة تحاول ألا تبدو كذلك.",
		Vector3(30, 5, 0), Vector3(24, 1.5, -10))
	await say([
		me("Smile, nod, look bored. Spies are boring if they are doing it right.", "ابتسمي، أومئي، وتظاهري بالملل. الجواسيس مملّون حين يُحسنون العمل."),
		me("Whatever Chen is planning, the proof must be inside the palace.", "مهما يخطط تشِن، فالدليل لا بد أن يكون داخل القصر."),
		me("This disguise will not survive a long stare. Keep moving and keep out of their way.", "هذا التنكر لن يصمد أمام نظرة طويلة. واصلي السير وابتعدي عن طريقهم."),
	])
	goal_done(0)
	var w1: Array = [
		{"c": Vector3(20, 0, -16), "amp": Vector3(0, 0, 5), "speed": 1.3, "r": 3.4},
		{"c": Vector3(26, 0, -20), "amp": Vector3(-4, 0, 0), "speed": 1.8, "r": 2.8},
	]
	if not await disguise_run([Vector3(28, 0, -14), Vector3(26, 0, -26)], w1, Vector3(24, 0.2, -10), "Cross the yard in disguise", "اعبري الساحة متنكّرة"):
		return false
	goal_done(1)
	checkpoint()
	var w2: Array = [
		{"c": Vector3(18, 0, -32), "amp": Vector3(5, 0, 0), "speed": 1.0, "r": 3.4},
		{"c": Vector3(7, 0, -41), "amp": Vector3(0, 0, 3), "speed": 1.5, "r": 3.0},
		{"c": Vector3(12, 0, -36), "amp": Vector3(0, 0, 4), "speed": 1.9, "r": 2.6},
	]
	if not await stealth([Vector3(14, 0, -38), Vector3(0, 0, -43)], w2, Vector3(26, 0.2, -26), "Reach the palace unseen", "اصلي إلى القصر دون أن يراك أحد"):
		return false
	goal_done(2)
	if flag_set("ch5_note"):
		goal_done(4)
		side_reward("ch5_note", "the guard's note", "مذكرة الحارس")
	# the spell sits above a window: climb the vines, pull the lever that opens the case
	isl.hud.set_objective(L("Climb the vines beside the window and open the case (lever).", "تسلّقي الكروم بجانب النافذة وافتحي الصندوق (الذراع)."))
	if not await climb_lever(Vector3(-14, 0, -42), Vector3(0, 0, 1), 3.0):
		return false
	await hook("ch05_spell_found",
		"Inside the palace, Nya finds a scroll describing a transformation spell. She takes it.",
		"داخل القصر، تجد نيا لفافة تصف تعويذة تحوّل. تأخذها.",
		Vector3(0, 4, -36), Vector3(0, 2, -44))
	goal_done(3)
	await say([
		me("A transformation spell. So this is what the stolen powers are for.", "تعويذة تحوّل. إذن هذا ما تُستخدم من أجله القوى المسروقة."),
		me("I have to get this out of here before anyone notices it is gone.", "يجب أن أخرجها من هنا قبل أن يلاحظ أحد اختفاءها."),
	])
	goals_clear()
	return isl._alive()

func _b1() -> bool:
	goals([["Survive Clouse", "اصمدي أمام كلاوس"], ["Defeat Clouse", "اهزمي كلاوس"], ["Keep the spell", "احتفظي بالتعويذة"]])
	await hook("ch05_clouse_intro",
		"Clouse catches Nya in the corridor. She cannot talk her way out of this one.",
		"يمسك كلاوس بنيا في الممر. لن تستطيع التحايل بالكلام هذه المرة.",
		Vector3(6, 3, -34), Vector3(0, 1.5, -40))
	await say([
		ln("clouse", "That scroll belongs to the master. Put it down and nobody has to get hurt.", "تلك اللفافة تخص السيد. ضعيها ولن يتأذى أحد."),
		me("Funny. I was going to say the same to you.", "طريف. كنت سأقول لك الشيء نفسه."),
	])
	if not await duel("clouse", Vector3(-6, 0.3, -36), "Defeat Clouse and keep the spell!", "اهزم كلاوس واحتفظ بالتعويذة!"):
		return false
	goal_done(0)
	goal_done(1)
	goal_done(2)
	GameState.award("clouse_beaten")
	GameState.skill_points += 1
	checkpoint()
	goals_clear()
	return isl._alive()

# Timed run to the boat with Chen's guards chasing, plus a guard wave at the bleachers.
func _b2() -> bool:
	goals([["Break through the alarmed guards", "اخترقي الحراس بعد الإنذار"], ["Run to the boat before time runs out", "اركضي إلى القارب قبل انتهاء الوقت"]])
	await hook("ch05_escape",
		"With the spell in hand, Nya runs for the beach and the boat while the guards sound the alarm.",
		"والتعويذة في يدها، تركض نيا نحو الشاطئ والقارب بينما يدق الحراس الإنذار.",
		Vector3(8, 6, -30), Vector3(0, 1, -38))
	if not await waves([["guard", "guard"], ["guard", "grunt", "elite"]], Vector3(0, 0, -37.5), 5.0, "Break through", "اخترقي"):
		return false
	goal_done(0)
	var run_pts: Array = [Vector3(0, 0, -20), Vector3(0, 0, 10), Vector3(-4, 0, 36), Vector3(-14, 0, 56)]
	var back := Vector3(0, 0.2, -34)
	if not await checkpoints(run_pts, "Run to the boat", "اركضي إلى القارب", 80.0, Color(1.0, 0.8, 0.2), back, "guard"):
		return false
	goal_done(1)
	await say([me("Made it. The spell is safe. Now I have to warn the others.", "نجحت. التعويذة في أمان. الآن عليّ تحذير الآخرين.")])
	goals_clear()
	return isl._alive()

## Who is the spy? Read three clues, then accuse. The suspect line-up is a gameplay choice (VERIFY).
## The characters keep it to themselves: Kai only learns the truth in chapter 6.
func _bh() -> bool:
	goals([["Read the 3 clues", "اقرأ الأدلة الثلاثة"], ["Find the spy among the alliance", "اعثر على الجاسوس بين التحالف"]])
	note(Vector3(10, 0, 4), "Torn Schedule", "جدول ممزق",
		"The alliance's meeting hour, written on a torn page. Chen's guards were told about it within the hour.",
		"موعد اجتماع التحالف مكتوب على صفحة ممزقة. عرف حرس تشِن به خلال ساعة.", "ch5_clue1")
	note(Vector3(-10, 0, 6), "Sleeve Mark", "علامة الكم",
		"A contestant keeps one sleeve pulled down, even in the hottest part of the day. Something is hidden underneath.",
		"أحد المتسابقين يبقي كمًّا واحدًا مسحوبًا حتى في أشد ساعات الحر. شيء مخبأ تحته.", "ch5_clue2")
	note(Vector3(0, 0, -6), "Night Footprints", "آثار الليل",
		"Small boot prints lead from the palace corridor back to the contestants' quarters. Whoever walked there had no escort.",
		"آثار حذاء صغيرة تمتد من ممر القصر إلى مساكن المتسابقين. من مشى هناك لم يكن معه مرافق.", "ch5_clue3")
	await say([
		ln("kai", "Chen's guards knew about our meeting within the hour. Someone talked.", "حرس تشِن عرفوا باجتماعنا خلال ساعة. أحدهم تكلّم."),
		me("Then someone in the alliance is not who they say they are. Let us find the clues.", "إذن أحدهم في التحالف ليس كما يدّعي. لنجمع الأدلة."),
	])
	for fid in ["ch5_clue1", "ch5_clue2", "ch5_clue3"]:
		if not await wait_flag(fid):
			return false
	goal_done(0)
	var sus: Array = [
		{"cfg": {"suit": CharacterDB.DATA["skylor"]["suit"], "style": "ninja"}, "pos": Vector3(-6, 0.2, -2), "name": ["Skylor", "سكايلور"], "yaw": 0.6},
		{"cfg": {"suit": Color(0.6, 0.2, 0.7), "style": "ninja"}, "pos": Vector3(0, 0.2, -14), "name": ["Chamille", "شاميل"], "yaw": 0.0},
		{"cfg": {"suit": Color(0.5, 0.5, 0.5), "style": "ninja"}, "pos": Vector3(8, 0.2, -2), "name": ["Ash", "آش"], "yaw": -0.6},
	]
	if not await deduce(sus, 0, "Accuse the spy", "اتهم الجاسوس"):
		return false
	goal_done(1)
	await say([
		me("The sleeve, the footprints, the schedule: they all point to Skylor.", "الكم، والآثار، والجدول: كلها تشير إلى سكايلور."),
		ln("kai", "No. Not her. That is not enough to go on.", "لا. ليست هي. هذا لا يكفي."),
		me("Then we say nothing until we are sure. But we watch.", "إذن لا نقول شيئًا حتى نتأكد. لكننا نراقب."),
	])
	goals_clear()
	return isl._alive()

func _b3() -> bool:
	goals([["Check on Jay", "اطمئن على جاي"], ["Talk with Skylor", "تحدّث مع سكايلور"],
		["Win the exhibition round", "اربح جولة العرض"], ["Read Skylor's note (optional)", "اقرأ مذكرة سكايلور (اختياري)"]])
	note(Vector3(14, 0, 8), "Pressed Flower", "زهرة مجففة",
		"A flower pressed between two plain cards, tucked beside the bench. Someone keeps small kind things secret.",
		"زهرة مجففة بين بطاقتين بسيطتين، مدسوسة بجانب المقعد. أحدهم يخفي أشياء لطيفة صغيرة.", "ch5_flower")
	await hook("ch05_skylor_spy",
		"In Chen's throne room, the spy hidden inside the contestants' alliance reports to him: it is Skylor.",
		"في قاعة عرش تشِن، يقدّم الجاسوس المتخفّي داخل تحالف المتسابقين تقريره له: إنها سكايلور.",
		Vector3(0, 6, -40), Vector3(0, 2, -50))
	await hook("ch05_jay_foot",
		"Back in the arena, Jay is limping: he has injured his foot and cannot fight at full strength.",
		"في الساحة، يعرج جاي: لقد أصاب قدمه ولا يستطيع القتال بكامل قوته.",
		Vector3(6, 4, 8), Vector3(0, 1, 0))
	await say([
		ln("jay", "It is fine. It is a little bit fine. It will be fine after a nap.", "لا بأس. قليلًا لا بأس. سيكون بخير بعد قيلولة."),
		ln("lloyd", "You are benched until it heals. No arguing.", "ستجلس على الدكة حتى تشفى. بلا نقاش."),
	])
	if not await visit_party(["jay"], 0):
		return false
	if not await waves([["guard", "grunt"], ["guard", "guard", "grunt"]], Vector3(0, 0, 4), 8.0, "Exhibition round", "جولة العرض"):
		return false
	goal_done(2)
	checkpoint()
	if not await survive(15.0, "guard", Vector3(0, 0, 4), 3, "Keep the stands safe", "حافظ على أمان المدرّجات"):
		return false
	var sk := spawn_fig({"suit": CharacterDB.DATA["skylor"]["suit"], "style": "ninja", "weapon": "fan"}, Vector3(8, 0.2, 2), -1.2)
	isl.hud.set_objective(L("Talk with Skylor.", "تحدّث مع سكايلور."))
	if not await wait_near(Vector3(8, 0, 2), 4.0):
		return false
	await hook("ch05_kai_skylor",
		"Kai and Skylor spend a quiet moment together, and clearly like each other.",
		"يقضي كاي وسكايلور لحظة هادئة معًا، ومن الواضح أنهما معجبان ببعضهما.",
		Vector3(2, 2.5, 6), Vector3(8, 1.5, 2))
	goal_done(1)
	await say([
		ln("skylor", "You fight like someone who is worried about everyone but himself.", "تقاتل كمن يقلق على الجميع إلا نفسه."),
		me("Is that a problem?", "هل هذه مشكلة؟"),
		ln("skylor", "No. It is just... rare. Do not tell anyone I said it was nice.", "لا. إنها فقط... نادرة. لا تخبر أحدًا أنني قلت إنها لطيفة."),
		ln("jay", "I can hear you both. I am injured, not deaf.", "أسمعكما. أنا مصاب، لست أصمّ."),
	])
	if flag_set("ch5_flower"):
		goal_done(3)
		side_reward("ch5_flower", "Skylor's flower", "زهرة سكايلور")
	drop_fig(sk)
	jade_if(5, ["ch5_note", "ch5_flower"], "Spy for a Spy", "جاسوس مقابل جاسوس")
	goals_clear()
	return await finish(1500.0)
