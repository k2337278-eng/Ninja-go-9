class_name Ch02
extends ChapterBase
## Chapter 2 - Only One Can Remain (ep. 36). Spec: Kai vs Karlof for the last place in the next round
## (Kai wins by unfair means), hints about Skylor's powers, the ninja discover Chen steals powers and
## agree to play by his rules to find Zane. GAMEPLAY: the Kai/Karlof match.
## v4 beats: warm-up (dummies + exhibition) -> match (2 phases) -> bleacher climb + Skylor + discovery.
## Hooks: ch02_announcement, ch02_unfair_win, ch02_skylor_hint, ch02_discovery.
## VERIFY: HOW the win is unfair (left vague); what Skylor's hinted power is (left vague); the
## warm-up/exhibition rounds are GAMEPLAY padding with Chen's guards, not spec events.

func _init() -> void:
	num = 2
	title = ["Only One Can Remain", "مكان واحد فقط يبقى"]

func beats() -> Array:
	var party: Array = ["jay", "cole", "lloyd"]
	return [
		beat("ch02_warmup", "kai", party, Vector3(0, 0.2, 40), _b0),
		beat("ch02_match", "kai", party, Vector3(0, 0.2, 10), _b1),
		beat("ch02_secrets", "kai", party, Vector3(0, 0.2, 10), _b2),
	]

# Warm-up: hit practice dummies on the beach, then an exhibition round before the match.
func _b0() -> bool:
	await begin()
	goals([["Warm up: destroy 5 practice dummies", "إحماء: حطّم 5 دمى تدريب"],
		["Win the exhibition round", "اربح جولة العرض"], ["Find the sailor's lost bag (optional)", "اعثر على حقيبة البحّار الضائعة (اختياري)"],
		["Report to the arena", "توجّه إلى الساحة"],
		["Try a perfect TAG: hit a dummy, then press TAG (optional)", "جرّب TAG مثاليًا: اضرب دمية ثم اضغط TAG (اختياري)"]])
	var start_dummies := int(GameState.stats.get("dummies", 0))
	var start_tags := int(GameState.stats.get("perfect_tags", 0))
	isl.hud.toast(L("Tip: press TAG to call an ally for a cooperation strike (best right after a hit).", "نصيحة: اضغط TAG لتستدعي حليفًا لضربة تعاون (الأفضل بعد ضربة مباشرة)."))
	note(Vector3(22, 0, 52), "Sailor's Bag", "حقيبة البحّار",
		"A damp bag with a note: 'If found, please return to the old fisherman. He pays in smiles.'",
		"حقيبة مبللة عليها ورقة: 'من يجدها فليعدها إلى الصياد العجوز. يدفع ابتسامات.'", "ch2_bag")
	await say([ln("jay", "Chen's people say the arena opens soon. A little warm-up never hurt anyone.", "أهل تشِن يقولون إن الساحة ستفتح قريبًا. القليل من الإحماء لم يؤذِ أحدًا.")])
	isl.hud.set_objective(L("Break 5 practice dummies.", "حطّم 5 دمى تدريب."))
	var tag_marked := false
	while isl._alive() and int(GameState.stats.get("dummies", 0)) - start_dummies < 5:
		await isl.get_tree().create_timer(0.4).timeout
		if not tag_marked and int(GameState.stats.get("perfect_tags", 0)) > start_tags:
			tag_marked = true
			goal_done(4)
			side_reward("ch2_tag", "perfect TAG", "TAG مثالي")
		if isl.player.state == Fighter.S.DEAD:
			return false
	goal_done(0)
	checkpoint()
	await say([ln("cole", "Good. Now the guards want a show: an exhibition round before the main matches.", "جيد. والآن يريد الحراس عرضًا: جولة استعراضية قبل المباريات الرئيسية.")])
	if not await waves([["guard", "grunt"], ["guard", "guard", "grunt"], ["brute", "guard"]], Vector3(0, 0, 36), 9.0, "Exhibition round", "جولة العرض"):
		return false
	goal_done(1)
	if flag_set("ch2_bag"):
		goal_done(2)
		side_reward("ch2_bag", "return the sailor's bag", "إعادة حقيبة البحّار")
	isl.hud.set_objective(L("Head to the arena.", "توجّه إلى الساحة."))
	if not await wait_near(Vector3(0, 0, 14), 5.0):
		return false
	goal_done(3)
	return isl._alive()

func _b1() -> bool:
	goals([["Hear Chen's announcement", "استمع إلى إعلان تشِن"], ["Win the match against Karlof", "اربح المباراة ضد كارلوف"],
		["Lure Karlof into one of Chen's traps", "استدرج كارلوف إلى أحد فخاخ تشِن"]])
	await hook("ch02_announcement",
		"Chen announces that only one fighter can take the last place in the next round: Kai against Karlof.",
		"يعلن تشِن أن مقاتلًا واحدًا فقط يأخذ آخر مكان في الجولة التالية: كاي ضد كارلوف.",
		Vector3(-6, 12, -26), Vector3(0, 10.5, -42))
	goal_done(0)
	await say([
		ln("chen", "One place remains in the next round. One fighter will take it, and the other goes home.", "بقي مكان واحد في الجولة التالية. مقاتل واحد يأخذه، والآخر يعود إلى بيته."),
		ln("karlof", "Good. I like it when the question is simple.", "جيد. أحب الأسئلة البسيطة."),
		ln("jay", "Kai, do not get hit. Or do get hit, but win.", "كاي، لا تُصَب. أو أصَب، لكن فُز."),
	])
	if not await trap_duel("karlof", Vector3(0, 0.3, -12), ARENA_TRAPS, ARENA_BUTTONS, "Win the match against Karlof!", "اربح المباراة ضد كارلوف!", 0.25, 2):
		return false
	goal_done(1)
	await hook("ch02_unfair_win",
		"The match ends in Kai's favor, but not cleanly. Something about the result is wrong. (VERIFY exact method.)",
		"تنتهي المباراة لصالح كاي، لكن ليس بطريقة نظيفة. هناك شيء خاطئ في النتيجة. (VERIFY الطريقة بالضبط.)",
		Vector3(0, 6, 6), Vector3(0, 1.5, -8))
	GameState.points += 200
	await say([
		ln("chen", "The match goes to Kai. Next round!", "المباراة لكاي. إلى الجولة التالية!"),
		me("That did not feel like winning. That felt like being handed a result.", "هذا لم يبدُ كفوز. بدا كمن يُسلَّم نتيجة جاهزة."),
		ln("cole", "Hold that thought. We need somewhere quiet to talk.", "احتفظ بالفكرة. نحتاج مكانًا هادئًا للكلام."),
	])
	checkpoint()
	return isl._alive()

# Climb the bleachers to see the exit gate, meet Skylor, watch a drained loser walk out.
func _b2() -> bool:
	goals([["Climb the bleachers to see the exit gate", "تسلّق المدرّجات لترى بوابة الخروج"],
		["Talk with Skylor", "تحدّث مع سكايلور"], ["Watch the losers leave", "راقب الخاسرين وهم يغادرون"],
		["Read the hidden message (optional)", "اقرأ الرسالة المخفية (اختياري)"]])
	var sk := spawn_fig({"suit": CharacterDB.DATA["skylor"]["suit"], "style": "ninja", "weapon": "fan"}, Vector3(10, 0.2, 4), -1.2)
	note(Vector3(-14, 0, 2), "Folded Message", "رسالة مطوية",
		"A folded scrap under a bench: 'Do not trust the prize. Ask the ones who lost.' No signature.",
		"قصاصة مطوية تحت مقعد: 'لا تثقوا بالجائزة. اسألوا من خسروا.' بلا توقيع.", "ch2_message")
	isl.hud.set_objective(L("Talk with the contestant near the arena.", "تحدّث مع المتسابقة قرب الساحة."))
	if not await wait_near(Vector3(10, 0, 4), 5.0):
		return false
	await hook("ch02_skylor_hint",
		"A contestant named Skylor watches Kai and hints that her power is different from everyone else's.",
		"متسابقة اسمها سكايلور تراقب كاي وتلمّح إلى أن قوتها مختلفة عن الجميع.",
		Vector3(4, 2.5, 8), Vector3(10, 1.5, 4))
	await say([
		ln("skylor", "You are the one who beat Karlof. Congratulations. I think.", "أنت من هزم كارلوف. تهانيّ. على ما أظن."),
		me("You think?", "على ما تظنين؟"),
		ln("skylor", "My kind of power is not like fire or lightning. Watch the losers leave this arena and you will understand why I say so.", "قوتي ليست كالنار أو البرق. راقب الخاسرين وهم يغادرون هذه الساحة وستفهم لماذا أقول ذلك."),
	])
	goal_done(1)
	await say([ln("jay", "The crowd is leaving all at once and the guards are shoving. Hold the stands!", "الحشد يغادر دفعة واحدة والحراس يدفعون الناس. احموا المدرّجات!")])
	if not await survive(20.0, "guard", Vector3(0, 0, -4), 3, "Keep order at the stands", "حافظ على النظام عند المدرّجات"):
		return false
	# puzzle/climb: the bleachers' top row overlooks the exit gate (vine wall on the front of the stands)
	var cw := ClimbWall.new()
	cw.size = Vector3(6, 4.7, 1.8)
	cw.top_dir = Vector3(0, 0, -1)
	cw.position = Vector3(0, 2.35, -22.9)
	isl.add_child(cw)
	isl.hud.set_objective(L("Climb the vines on the stands and reach the top row.", "تسلّق الكروم على المدرّجات واصل إلى الصف العلوي."))
	if not await wait_near(Vector3(0, 0, -29), 3.0):
		return false
	goal_done(0)
	if flag_set("ch2_message"):
		goal_done(3)
		side_reward("ch2_message", "the hidden message", "الرسالة المخفية")
	await hook("ch02_discovery",
		"The ninja watch a defeated contestant walk out, drained and empty. Chen's tournament takes the powers of the losers.",
		"يراقب النينجا متسابقًا خاسرًا يخرج منهكًا وفارغًا. بطولة تشِن تسلب قوى الخاسرين.",
		Vector3(-4, 6, -14), Vector3(0, 1.5, 4))
	goal_done(2)
	await say([
		ln("jay", "Did you see his eyes? There is nothing left in there. His power is gone.", "هل رأيت عينيه؟ لا شيء فيهما. قوته اختفت."),
		ln("lloyd", "So this is what the tournament is for. Chen is collecting powers.", "إذن هذا هو هدف البطولة. تشِن يجمع القوى."),
		ln("cole", "If we leave now, Chen keeps going without us, and Zane stays lost.", "إن غادرنا الآن فسيكمل تشِن من دوننا، ويبقى زين ضائعًا."),
		me("Then we play by his rules. We win, we stay inside, and we find Zane.", "إذن نلعب بقواعده. نفوز، ونبقى في الداخل، ونجد زين."),
		ln("jay", "And try not to lose a single match. Easy. Totally easy.", "ومحاولة ألا نخسر مباراة واحدة. سهل. سهل جدًا."),
	])
	drop_fig(sk)
	jade_if(2, ["ch2_bag", "ch2_message"], "Only One Can Remain", "مكان واحد فقط يبقى")
	goals_clear()
	return await finish(900.0)
