class_name Ch07
extends ChapterBase
## Chapter 7 - The Forgotten Element (ep. 41), per STORY_SPEC v2: Chen needs only Lloyd's power, promises Kai the secrets
## of his parents through Skylor (content NOT invented), Lloyd faces Chen's Staff of Elements, Kai seems to betray the
## team (VERIFY: a ruse?), Kai and Skylor break the staff so the powers return, the Masters take control of the island.
## v8 beats: Lloyd's prelude -> Kai/Skylor's offer -> Lloyd vs the Staff (element stages) -> Kai's staff stage (he
## chooses WHEN to break it) -> the Masters take the island.
## Hooks: ch07_chen_needs_lloyd, ch07_chen_secret, ch07_kai_betrays, ch07_final_match, ch07_staff_break,
## ch07_powers_return, ch07_masters_control.
## VERIFY: the secrets about Kai's parents (never stated); whether Kai's betrayal is a ruse; how Lloyd's confrontation
## ends (here: interrupted at 45 percent); Eyezor leading the staff guard (the spec only places him in ch. 6-8); the four
## element stages of the staff fight are gameplay stand-ins; all gates, climbs and waves are padding with Chen's followers.

func _init() -> void:
	num = 7
	title = ["The Forgotten Element", "العنصر المنسي"]

func beats() -> Array:
	return [
		beat("ch07_prelude", "lloyd", ["jay"], Vector3(0, 0.2, 30), _b0),
		beat("ch07_offer", "kai", [], Vector3(0, 0.2, -36), _b1),
		beat("ch07_staff_duel", "lloyd", ["jay"], Vector3(0, 0.2, 14), _b2),
		beat("ch07_staff_break", "kai", ["skylor"], Vector3(0, 0.2, -36), _b3),
		beat("ch07_masters", "kai", ["skylor", "jay", "cole"], Vector3(0, 0.2, 10), _b4),
	]

func _b0() -> bool:
	await begin()
	goals([["Beat the preliminary guards", "اهزم حراس التصفيات"], ["Open the arena gate", "افتح بوابة الساحة"],
		["Climb the stands to the final ring", "تسلّق المدرّجات إلى حلبة النهائي"], ["Learn why Chen wants you", "اعرف لماذا يريدك تشِن"],
		["Read the programme (optional)", "اقرأ برنامج المباراة (اختياري)"], ["Find the lucky coin (optional)", "اعثر على العملة الميمونة (اختياري)"]])
	note(Vector3(14, 0, 24), "Final Programme", "برنامج النهائي",
		"The final match is printed in gold ink. Under it, in pencil: 'Chen fights the strongest, always.'",
		"مباراة الختام مطبوعة بحبر ذهبي. وتحتها بالقلم الرصاص: 'تشِن يقاتل الأقوى دائمًا.'", "ch7_programme")
	note(Vector3(-16, 0, 20), "Lucky Coin", "عملة ميمونة",
		"A coin worn smooth from being rubbed before every match. Someone will want it back.",
		"عملة مصقولة من كثرة فركها قبل كل مباراة. سيطلبها أحدهم قريبًا.", "ch7_coin")
	if not await waves([["guard", "guard"], ["guard", "grunt", "elite"], ["brute", "guard", "guard"]], Vector3(0, 0, 24), 9.0, "Beat the preliminaries", "اهزم التصفيات"):
		return false
	goal_done(0)
	checkpoint()
	isl.hud.set_objective(L("The arena gate is shut: push a crate onto the plate.", "بوابة الساحة مغلقة: ادفع صندوقًا فوق اللوح."))
	if not await plate_door(Vector3(0, 0, 14), Vector3(8, 4, 1), Vector3(-9, 0, 20), [Vector3(6, 0.7, 22), Vector3(-6, 0.7, 24)]):
		return false
	goal_done(1)
	isl.hud.set_objective(L("Climb the vines to the final ring.", "تسلّق الكروم إلى حلبة النهائي."))
	if not await climb_lever(Vector3(22, 0, 8), Vector3(0, 0, -1), 3.0):
		return false
	goal_done(2)
	if flag_set("ch7_programme"):
		goal_done(4)
		side_reward("ch7_programme", "the final programme", "برنامج النهائي")
	if flag_set("ch7_coin"):
		goal_done(5)
		side_reward("ch7_coin", "the lucky coin", "العملة الميمونة")
	checkpoint()
	await hook("ch07_chen_needs_lloyd",
		"Chen has what he needs from the other masters. Now he needs only Lloyd's power.",
		"حصل تشِن على ما يحتاجه من بقية الأسياد. والآن لا يحتاج إلا إلى قوة لويد.",
		Vector3(-6, 12, -26), Vector3(0, 10.5, -42))
	goal_done(3)
	await say([
		ln("chen", "The other powers were only the road. Yours is where I am going.", "القوى الأخرى كانت الطريق فقط. وقوّتك هي وجهتي."),
		me("Then you will have to come and take it.", "إذن عليك أن تأتي وتأخذها."),
		ln("jay", "Lloyd, he is not bluffing. Be careful with that staff.", "لويد، هو لا يمزح. احذر من تلك العصا."),
	])
	goals_clear()
	return isl._alive()

# Kai alone. Skylor carries Chen's promise (VERIFY: the secrets themselves are left for the real episode).
func _b1() -> bool:
	goals([["Meet Skylor", "قابل سكايلور"], ["Hear Chen's promise", "اسمع وعد تشِن"], ["Decide", "قرّر"], ["Cross to Chen's side", "اعبر إلى جانب تشِن"]])
	var sk := spawn_fig({"suit": CharacterDB.DATA["skylor"]["suit"], "style": "ninja", "weapon": "fan"}, Vector3(4, 0.2, -38), 1.2)
	if not await checkpoints([Vector3(0, 0, -30), Vector3(2, 0, -36)], "Meet Skylor", "قابل سكايلور", 0.0, Color(0.9, 0.3, 0.9)):
		return false
	goal_done(0)
	await hook("ch07_chen_secret",
		"Skylor brings Kai a message from Chen: he knows secrets about Kai's parents, and will tell them. (VERIFY: the secrets are not stated.)",
		"تحمل سكايلور إلى كاي رسالة من تشِن: إنه يعرف أسرارًا عن والديه وسيخبره بها. (VERIFY: الأسرار غير مذكورة.)",
		Vector3(6, 3, -30), Vector3(2, 1.5, -38))
	goal_done(1)
	await say([
		ln("skylor", "My father says he knows what happened to your family. He will tell you.", "أبي يقول إنه يعرف ما حدث لعائلتك. وسيخبرك."),
		me("And what does he want in return?", "وماذا يريد في المقابل؟"),
		ln("skylor", "Only that you stand with him. I did not choose this message, Kai.", "فقط أن تقف معه. أنا لم أختر هذه الرسالة يا كاي."),
	])
	goal_done(2)
	await hook("ch07_kai_betrays",
		"Kai turns away from his friends and goes to Chen's side. Is it a betrayal, or a plan? (VERIFY.)",
		"يدير كاي ظهره لأصدقائه ويذهب إلى جانب تشِن. أهي خيانة أم خطة؟ (VERIFY.)",
		Vector3(-6, 3, -28), Vector3(0, 1.5, -38))
	await say([
		me("I am sorry, everyone. I need to know.", "آسف يا جماعة. أحتاج أن أعرف."),
		ln("skylor", "Whatever happens next, I am with you. Remember that.", "مهما حدث بعد ذلك، أنا معك. تذكّر هذا."),
	])
	if not await wait_near(Vector3(0, 0, -41), 3.5):
		return false
	goal_done(3)
	drop_fig(sk)
	goals_clear()
	return isl._alive()

# Lloyd vs Chen holding the Staff of Elements: four stages, each element with its own status (stand-in design).
func _stage_elem(n: int) -> Dictionary:
	match n:
		1:
			return {"en": "fire", "ar": "النار", "color": Color(1.0, 0.45, 0.1), "status": "burn"}
		2:
			return {"en": "ice", "ar": "الجليد", "color": Color(0.5, 0.9, 1.0), "status": "slow"}
	return {"en": "lightning", "ar": "البرق", "color": Color(1.0, 0.95, 0.3), "status": "stun"}

func _b2() -> bool:
	goals([["Face Chen and the Staff of Elements", "واجه تشِن وعصا العناصر"], ["Survive the fire stage", "اصمد في مرحلة النار"],
		["Survive the ice stage", "اصمد في مرحلة الجليد"], ["Survive the lightning stage", "اصمد في مرحلة البرق"], ["Hold on until help comes", "اصمد حتى يأتي العون"]])
	await hook("ch07_final_match",
		"Lloyd faces Chen, who now carries the Staff of Elements. Every power he has taken answers it.",
		"يواجه لويد تشِن الذي يحمل عصا العناصر الآن. وكل قوة أخذها تستجيب لها.",
		Vector3(-6, 12, -26), Vector3(0, 10.5, -42))
	goal_done(0)
	isl.chen.visible = false
	var b: Boss = isl.spawn_boss("chen", Vector3(0, 0.3, -12))
	await isl.hud.banner(b.display_name, 1.4)
	var stage := 0
	while true:
		await isl.get_tree().create_timer(0.2).timeout
		if not ok_alive():
			return false
		if not is_instance_valid(b) or b.state == Fighter.S.DEAD or b.health / b.max_health <= 0.45:
			break
		if b.phase != stage:
			stage = b.phase
			var el: Dictionary = _stage_elem(stage)
			b.volley_ab["color"] = el["color"]
			b.volley_ab["status"] = str(el["status"])
			b.volley_ab["status_time"] = 2.0
			await isl.hud.banner(L("The staff draws on %s!", "العصا تستمد من %s!") % L(str(el["en"]), str(el["ar"])), 1.2)
			goal_done(stage)
			isl.hud.set_objective(L("Survive the %s stage!", "اصمد في مرحلة %s!") % L(str(el["en"]), str(el["ar"])))
	isl.clear_enemies()
	isl.chen.visible = true
	goal_done(4)
	await say([ln("chen", "Enough. You are good, boy. But now I know exactly what you hold.", "كفى. أنت جيد يا فتى. لكنني الآن أعرف تمامًا ما تملكه.")])
	checkpoint()
	goals_clear()
	return isl._alive()

# Kai + Skylor: Lloyd's power is being drained while they fight to the staff. Kai chooses WHEN to break it.
func _b3() -> bool:
	goals([["Slip past the palace watchers", "تسلّل من مراقبي القصر"], ["Climb to the staff chamber", "تسلّق إلى غرفة العصا"],
		["Beat the staff's guardians", "اهزم حرّاس العصا"], ["Choose the moment and break the staff", "اختر اللحظة واكسر العصا"],
		["Read the torn pledge (optional)", "اقرأ العهد الممزق (اختياري)"], ["Find Kai's old charm (optional)", "اعثر على تميمة كاي القديمة (اختياري)"]])
	note(Vector3(-16, 0, -38), "Torn Pledge", "عهد ممزق",
		"A pledge of loyalty to Chen, ripped in two. Someone changed their mind in the middle of signing.",
		"عهد ولاء لتشِن، ممزق نصفين. غيّر أحدهم رأيه أثناء التوقيع.", "ch7_pledge")
	note(Vector3(18, 0, -38), "Kai's Old Charm", "تميمة كاي القديمة",
		"A cheap charm on a thread, dropped long ago. It smells faintly of woodsmoke.",
		"تميمة رخيصة على خيط، سقطت منذ زمن. تفوح منها رائحة دخان خفيفة.", "ch7_charm")
	await say([
		me("The staff is humming inside my head. It wants me to take, and take more.", "العصا تطنّ داخل رأسي. تريدني أن آخذ، وأن آخذ أكثر."),
		ln("skylor", "Then we break it. Together. Before it finishes with Lloyd.", "إذن نكسرها. معًا. قبل أن تنتهي من لويد."),
	])
	var w: Array = [{"c": Vector3(-6, 0, -34), "amp": Vector3(7, 0, 0), "speed": 1.2, "r": 3.2}, {"c": Vector3(6, 0, -39), "amp": Vector3(-7, 0, 0), "speed": 1.5, "r": 3.0}]
	if not await stealth([Vector3(-10, 0, -40), Vector3(10, 0, -42)], w, Vector3(0, 0.2, -36), "Slip past the watchers", "تسلّل من المراقبين"):
		return false
	goal_done(0)
	checkpoint()
	isl.hud.set_objective(L("Climb the vines to the staff chamber.", "تسلّق الكروم إلى غرفة العصا."))
	if not await climb_lever(Vector3(14, 0, -36), Vector3(0, 0, -1), 3.0):
		return false
	goal_done(1)
	if not await waves([["guard", "guard", "elite"], ["elite", "elite", "brute"]], Vector3(0, 0, -37.5), 5.0, "Fight the staff's guardians", "قاتل حرّاس العصا"):
		return false
	if not await duel("eyezor", Vector3(0, 0.3, -37), "Defeat the guard captain (Eyezor)!", "اهزم قائد الحرس (آيزور)!", 0.3):
		return false
	goal_done(2)
	checkpoint()
	var st := place_stone(Vector3(0, 0, -40), Color(0.7, 0.2, 0.9), "Break the Staff of Elements", "اكسر عصا العناصر")
	var drain := 20.0
	var secs := 0.0
	while isl._alive() and not st.done:
		await isl.get_tree().create_timer(0.25).timeout
		if isl.player.state == Fighter.S.DEAD:
			return false
		drain += 0.25 * (100.0 / 55.0)
		secs += 0.25
		if drain >= 100.0:
			await isl.hud.banner(L("Skylor steadies the staff, buying you time!", "سكايلور تثبّت العصا وتشتري لك وقتًا!"), 1.2)
			drain = 45.0
		isl.hud.set_objective(L("Break the staff (USE). Lloyd's power drained: %d%%  (best: 45-85%%)", "اكسر العصا (USE). قوة لويد المستنزفة: %d%%  (الأفضل: 45-85%%)") % int(drain))
	if not isl._alive():
		return false
	goal_done(3)
	await hook("ch07_staff_break",
		"Kai and Skylor break the Staff of Elements together.",
		"يكسر كاي وسكايلور عصا عناصر معًا.",
		Vector3(8, 4, -30), Vector3(0, 1.5, -40))
	GameState.award("staff_broken")
	Effects.shake(isl, 0.6)
	if drain < 45.0:
		isl.hud.toast(L("Too early: the staff lashes out!", "مبكرًا جدًّا: العصا تردّ بعنف!"))
		if not await fight(["elite", "elite", "anacondrai"], Vector3(0, 0, -37.5), 5.0, "Beat the backlash", "اهزم الارتداد"):
			return false
	elif drain <= 85.0:
		GameState.add_coins(100)
		side_reward("ch7_timing", "perfect timing", "توقيت مثالي")
		jade(7, "The Forgotten Element", "العنصر المنسي")
	else:
		isl.hud.toast(L("Late, but it holds. Lloyd is shaken.", "متأخر، لكنها صمدت. لويد مرتبك."))
	await hook("ch07_powers_return",
		"Freed from the staff, the stolen powers fly back to the masters they were taken from.",
		"متحررة من العصا، تعود القوى المسروقة إلى الأسياد الذين سُلبت منهم.",
		Vector3(0, 8, -22), Vector3(0, 3, -40))
	if flag_set("ch7_pledge"):
		goal_done(4)
		side_reward("ch7_pledge", "the torn pledge", "العهد الممزق")
	if flag_set("ch7_charm"):
		goal_done(5)
		side_reward("ch7_charm", "Kai's old charm", "تميمة كاي القديمة")
	await say([
		me("It is over. The powers are going home.", "انتهى الأمر. القوى عائدة إلى أصحابها."),
		ln("skylor", "Kai... you did it. We did it.", "كاي... فعلتها. فعلناها."),
	])
	goals_clear()
	return isl._alive()

func _b4() -> bool:
	goals([["Round up Chen's followers", "اقبض على أتباع تشِن"], ["Hold the arena", "احمِ الساحة"], ["See the Masters take the island", "شاهد الماسترز يسيطرون على الجزيرة"]])
	await say([
		ln("jay", "My power is back! Everyone's is back! Now, who wants to see what I missed?", "قوتي عادت! قوة الجميع عادت! والآن، من يريد أن يرى ما فاتني؟"),
		ln("cole", "Chen's followers are still around. Let us deal with them.", "أتباع تشِن لا يزالون هنا. لنتعامل معهم."),
	])
	if not await waves([["guard", "guard", "grunt"], ["elite", "guard", "guard"], ["brute", "elite", "guard"]], Vector3(0, 0, 4), 9.0, "Round up the followers", "اقبض على الأتباع"):
		return false
	goal_done(0)
	if not await survive(20.0, "guard", Vector3(0, 0, 4), 3, "Hold the arena", "احمِ الساحة"):
		return false
	goal_done(1)
	await hook("ch07_masters_control",
		"The Masters take control of the island and lock Chen's followers away.",
		"يسيطر الماسترز على الجزيرة ويحبسون أتباع تشِن.",
		Vector3(0, 9, 22), Vector3(0, 2, -6))
	goal_done(2)
	goals_clear()
	return await finish(1400.0)
