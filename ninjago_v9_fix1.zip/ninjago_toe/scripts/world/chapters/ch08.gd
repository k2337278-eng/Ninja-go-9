class_name Ch08
extends ChapterBase
## Chapter 8 - The Day of the Dragon (ep. 42), per STORY_SPEC v2: Chen finds that Skylor can complete the spell; she sees
## her father for what he is and sends an SOS; a rescue race; Zane, with P.I.X.A.L., faces his inner conflict and sees the
## Titanium Dragon; the spell completes (Kapau begins it, Chope completes it) and the followers turn into Anacondrai; the
## Masters open their dragons and flee. Dragon order: Lloyd (ch. 6), then Zane, then Kai (third).
## v8 beats: Skylor's SOS -> rescue run -> Zane's inner test + Titanium Dragon -> the spell (Kapau, Chope) -> Kai's fire
## dragon and the escape.
## Hooks: ch08_chen_discovers, ch08_skylor_sos, ch08_rescue_convoy, ch08_zane_dragon, ch08_spell_begins,
## ch08_transformation, ch08_kai_dragon, ch08_dragons_escape.
## VERIFY: what Chen's followers look like when they turn into Anacondrai (placeholder enemies); the rescue vehicles
## (the spec only says a race; on foot here); Zane's inner conflict (only that it exists; shown as a blizzard run); the
## other Masters' dragons (cinematic only); all gates, waves and notes are gameplay padding with Chen's followers.

func _init() -> void:
	num = 8
	title = ["The Day of the Dragon", "يوم التنين"]

func beats() -> Array:
	return [
		beat("ch08_skylor", "skylor", [], Vector3(-50, 0.2, -10), _b0),
		beat("ch08_rescue", "lloyd", ["jay", "cole"], Vector3(0, 0.2, 40), _b1),
		beat("ch08_zane", "zane", [], Vector3(40, 0.2, -2), _b2, "gloom"),
		beat("ch08_spell", "lloyd", ["jay", "cole", "zane"], Vector3(0, 0.2, 8), _b3),
		beat("ch08_kai", "kai", ["skylor"], Vector3(0, 0.2, 8), _b4),
	]

func _b0() -> bool:
	await begin()
	goals([["Break out of the crystal chamber", "اخرجي من غرفة البلّور"], ["Open the inner door (lever)", "افتحي الباب الداخلي (الذراع)"],
		["Reach the signal stone", "اصلي إلى حجر الإشارة"], ["Send the SOS and hold out", "أرسلي النداء واصمدي"],
		["Read the prisoner's scratches (optional)", "اقرأي خدوش السجين (اختياري)"]])
	note(Vector3(-54, 0, -8), "Prisoner's Scratches", "خدوش السجين",
		"Tally marks on the wall, then one long line, then a single word: 'enough'.",
		"علامات عدّ على الجدار، ثم خط طويل، ثم كلمة واحدة: 'كفى'.", "ch8_scratch")
	await hook("ch08_chen_discovers",
		"Chen discovers that Skylor can complete the transformation spell, and he locks her in the crystal chamber.",
		"يكتشف تشِن أن سكايلور قادرة على إكمال تعويذة التحول، ويحبسها في غرفة البلّور.",
		Vector3(-44, 4, -8), Vector3(-52, 1.5, -12))
	await say([
		ln("chen", "My own daughter holds the missing piece. How fitting.", "ابنتي بالذات تملك القطعة الناقصة. ما أنسب ذلك."),
		me("Father, this is not a family tradition. It is a cage.", "أبي، هذا ليس تقليدًا عائليًّا. هذا قفص."),
	])
	if not await waves([["guard", "guard"], ["guard", "grunt", "brute"]], Vector3(-50, 0, -12), 4.5, "Break out", "اخرجي بالقوة"):
		return false
	goal_done(0)
	checkpoint()
	if not await lever_door(Vector3(-50, 0, -4), Vector3(6, 3, 1), Vector3(-46, 0, -8)):
		return false
	goal_done(1)
	if not await checkpoints([Vector3(-40, 0, -2), Vector3(-30, 0, 0)], "Reach the signal stone", "اصلي إلى حجر الإشارة", 0.0, Color(1.0, 0.6, 0.2)):
		return false
	goal_done(2)
	var st := place_stone(Vector3(-30, 0, 2), Color(1.0, 0.8, 0.2), "Send the SOS", "أرسلي نداء الاستغاثة")
	isl.hud.set_objective(L("Send the SOS at the signal stone (USE)!", "أرسلي النداء عند حجر الإشارة (USE)!"))
	if not await wait_stone(st):
		return false
	await hook("ch08_skylor_sos",
		"Skylor sees her father for what he truly is and sends out an SOS to the ninja.",
		"ترى سكايلور أباها على حقيقته وتبعث نداء استغاثة إلى النينجا.",
		Vector3(-24, 5, 8), Vector3(-30, 2, 2))
	if not await survive(25.0, "guard", Vector3(-30, 0, 2), 3, "Hold out until help arrives", "اصمدي حتى يصل العون"):
		return false
	goal_done(3)
	if flag_set("ch8_scratch"):
		goal_done(4)
		side_reward("ch8_scratch", "the prisoner's scratches", "خدوش السجين")
	goals_clear()
	return isl._alive()

func _b1() -> bool:
	goals([["Answer the SOS: race to the crystal caves", "لبّوا النداء: سباق إلى كهوف البلّور"], ["Slip past the outer watch", "تسلّلوا من الحراسة الخارجية"],
		["Break the cave guard", "اكسروا حرس الكهف"], ["Find the dropped spell page (optional)", "اعثر على صفحة التعويذة الساقطة (اختياري)"]])
	note(Vector3(-14, 0, 14), "Dropped Spell Page", "صفحة تعويذة ساقطة",
		"A page of crossed-out words in a nervous hand. The last line is underlined three times.",
		"صفحة كلمات مشطوبة بخط متوتر. السطر الأخير تحته ثلاثة خطوط.", "ch8_page")
	await hook("ch08_rescue_convoy",
		"The ninja and the other Masters race to answer Skylor's SOS. (VERIFY: which vehicle each ninja drives.)",
		"ينطلق النينجا وبقية الماسترز في سباق للرد على نداء سكايلور. (VERIFY: أي مركبة يقودها كل نينجا.)",
		Vector3(0, 8, 56), Vector3(0, 1, 36))
	await say([ln("jay", "Skylor called, so we answer. Everyone, with me!", "سكايلور نادت، فنحن نلبّي. الجميع معي!")])
	# the rescue run in vehicles (rail mode); the single shared vehicle is a gameplay simplification (VERIFY)
	var rescue_pts: Array = snake(Vector3(120, 0.2, 110), Vector3(-36, 0.2, -4), 13, 16.0)
	var vobs: Array = []
	for i in range(1, 6):
		vobs.append({"s": float(i) * 36.0, "off": sin(float(i) * 1.9) * 3.6, "k": "slab"})
	vobs.append({"s": 60.0, "off": 0.0, "k": "boost"})
	vobs.append({"s": 150.0, "off": -2.0, "k": "boost"})
	await isl.teleport_party(rescue_pts[0])
	await isl.hud.banner(L("Vehicles! Stick: steer   JMP: jump   DGE: boost", "مركبات! العصا: توجيه   JMP: قفز   DGE: تسريع"), 3.0)
	if not await rail_run("vehicle", rescue_pts, {"speed": 12.5, "width": 5.0, "armor": 3, "obstacles": vobs}, "Rescue run to the crystal caves", "سباق الإنقاذ إلى كهوف البلّور"):
		return false
	goal_done(0)
	checkpoint()
	var w: Array = [{"c": Vector3(-40, 0, -2), "amp": Vector3(0, 0, 5), "speed": 1.3, "r": 3.2}, {"c": Vector3(-34, 0, -8), "amp": Vector3(5, 0, 0), "speed": 1.7, "r": 3.0}]
	if not await stealth([Vector3(-42, 0, -4), Vector3(-38, 0, -10)], w, Vector3(-36, 0.2, -4), "Slip past the outer watch", "تسلّلوا من الحراسة الخارجية"):
		return false
	goal_done(1)
	if not await waves([["guard", "guard", "elite"], ["elite", "brute", "guard"]], Vector3(-40, 0, -8), 7.0, "Break the cave guard", "اكسروا حرس الكهف"):
		return false
	goal_done(2)
	if flag_set("ch8_page"):
		goal_done(3)
		side_reward("ch8_page", "the spell page", "صفحة التعويذة")
	goals_clear()
	return isl._alive()

# Zane + P.I.X.A.L.: an inner conflict (blizzard run), then the Titanium Dragon (his dragon, second after Lloyd's).
func _b2() -> bool:
	goals([["Cross the blizzard, listening to P.I.X.A.L.", "اعبر العاصفة، واستمع إلى بيكسال"], ["Open the frozen gate (lever)", "افتح البوابة المتجمدة (الذراع)"],
		["Hold the temple steps", "احمِ درج المعبد"], ["Face yourself and unlock the Titanium Dragon", "واجه نفسك وافتح تنين التيتانيوم"],
		["Read the frost note (optional)", "اقرأ مذكرة الصقيع (اختياري)"]])
	note(Vector3(40, 0, 4), "Frost Note", "مذكرة الصقيع",
		"A note written in neat, cold letters: 'Efficiency is a form of kindness, if you do it right.'",
		"مذكرة بحروف مرتبة باردة: 'الكفاءة شكل من أشكال اللطف، إن أُحسن استخدامها.'", "ch8_frost")
	await say([
		ln("pixal", "Zane, your readings are chaotic. Part of you is arguing with itself.", "زين، قراءاتك مضطربة. جزء منك يجادل نفسه."),
		me("Then talk me through it, P.I.X.A.L. I need a steady voice.", "إذن أرشديني يا بيكسال. أحتاج صوتًا ثابتًا."),
	])
	if not await checkpoints([Vector3(44, 0, 2), Vector3(52, 0, -2), Vector3(48, 0, 6)], "Cross the blizzard", "اعبر العاصفة", 60.0, Color(0.7, 0.9, 1.0), Vector3(40, 0.2, -2)):
		return false
	goal_done(0)
	if not await lever_door(Vector3(48, 0, 12), Vector3(8, 3, 1), Vector3(42, 0, 10)):
		return false
	goal_done(1)
	if not await waves([["anacondrai", "anacondrai"], ["anacondrai", "elite"]], Vector3(48, 0, -2), 8.0, "Hold the temple steps", "احمِ درج المعبد"):
		return false
	goal_done(2)
	# inner trial: stand in the circle while doubts press in (ritual mode), in a whiteout
	isl.set_mood("snow")
	await say([
		ln("pixal", "Your readings are climbing. Stay inside the circle and hold on to what you know.", "قراءاتك ترتفع. ابقَ داخل الدائرة وتمسّك بما تعرفه."),
		me("What I know is that I am more than my programming.", "ما أعرفه أنني أكثر من برمجتي."),
	])
	if not await ritual(Vector3(48, 0, -2), 6.5, 18.0, "guard", "Face your doubts (stay in the circle)", "واجه شكوكك (ابقَ داخل الدائرة)"):
		return false
	isl.set_mood("gloom")
	var st := place_stone(Vector3(48, 0, -2), Color(0.8, 0.85, 0.95), "Unlock your dragon", "افتح تنينك")
	for i in 5:
		isl.spawn_enemy("anacondrai", ring_pos(Vector3(48, 0, -2), 11.0, i, 5))
	isl.hud.set_objective(L("Unlock the Titanium Dragon at the glowing stone (USE)!", "افتح تنين التيتانيوم عند الحجر المتوهج (USE)!"))
	if not await wait_stone(st):
		return false
	await hook("ch08_zane_dragon",
		"With P.I.X.A.L.'s help, Zane faces his inner conflict and sees the Titanium Dragon.",
		"بمساعدة بيكسال، يواجه زين صراعه الداخلي ويرى تنين التيتانيوم.",
		Vector3(56, 5, 8), Vector3(48, 3, -2))
	GameState.award("ice_dragon")
	await dragon_strike(Color(0.8, 0.85, 0.95), Vector3(48, 0, -2), 80.0)
	isl.clear_enemies()
	goal_done(3)
	if flag_set("ch8_frost"):
		goal_done(4)
		side_reward("ch8_frost", "the frost note", "مذكرة الصقيع")
	await say([
		ln("pixal", "Dragon unlocked. Your output is... beautiful, Zane.", "تم فتح التنين. أداؤك... جميل يا زين."),
		me("Thank you, P.I.X.A.L. I could not have done it alone.", "شكرًا يا بيكسال. ما كنت لأفعلها وحدي."),
	])
	checkpoint()
	goals_clear()
	return isl._alive()

# The spell: Kapau begins it, Chope completes it; Chen's followers turn into Anacondrai.
func _b3() -> bool:
	goals([["Stop Kapau before the spell starts", "أوقف كاباو قبل أن تبدأ التعويذة"], ["Survive the ritual", "اصمد خلال الطقس"],
		["Face Chope as the spell completes", "واجه تشوب بينما تكتمل التعويذة"], ["Beat the transformed followers", "اهزم الأتباع المتحوّلين"],
		["Find the cracked ember stone (optional)", "اعثر على حجر الجمر المتشقق (اختياري)"]])
	note(Vector3(14, 0, 14), "Cracked Ember Stone", "حجر جمر متشقق",
		"A warm, cracked stone that still glows faintly orange when you hold it.",
		"حجر دافئ متشقق ما زال يتوهج بالبرتقالي حين تمسكه.", "ch8_ember")
	await hook("ch08_spell_begins",
		"In the crystal caves Kapau begins the transformation spell. The air twists and the crystals sing.",
		"في كهوف البلّور يبدأ كاباو تعويذة التحول. يلتوي الهواء وتغنّي البلّورات.",
		Vector3(-6, 12, -26), Vector3(0, 10.5, -42))
	await say([
		ln("kapau", "The words are older than all of us. Do not interrupt, little ninja.", "الكلمات أقدم منا جميعًا. لا تقاطع يا نينجا صغير."),
		me("Watch me.", "راقبني."),
	])
	if not await duel("kapau", Vector3(0, 0.3, -12), "Stop Kapau!", "أوقف كاباو!", 0.4):
		return false
	goal_done(0)
	if not await survive(30.0, "guard", Vector3(0, 0, -6), 4, "Survive the ritual", "اصمد خلال الطقس"):
		return false
	goal_done(1)
	checkpoint()
	await say([ln("chope", "My turn. I will finish what Kapau started.", "دوري. سأنهي ما بدأه كاباو.")])
	if not await duel("chope", Vector3(0, 0.3, -12), "Hold Chope off!", "اصمد أمام تشوب!", 0.5):
		return false
	goal_done(2)
	await hook("ch08_transformation",
		"Chope completes the spell. Chen's followers shudder and turn into Anacondrai. (VERIFY: the look.)",
		"يكمل تشوب التعويذة. يرتجف أتباع تشِن ويتحولون إلى أناكوندراي. (VERIFY: الشكل.)",
		Vector3(0, 14, 10), Vector3(0, 8, -42))
	await say([me("They are changing. We cannot fight all of them here. Fall back!", "إنهم يتحولون. لا نستطيع قتالهم جميعًا هنا. تراجعوا!")])
	if not await waves([["anacondrai", "anacondrai", "guard"], ["elite", "anacondrai", "anacondrai"]], Vector3(0, 0, -6), 9.0, "Beat the transformed followers", "اهزم الأتباع المتحوّلين"):
		return false
	goal_done(3)
	if flag_set("ch8_ember"):
		goal_done(4)
		side_reward("ch8_ember", "the ember stone", "حجر الجمر")
	goals_clear()
	return isl._alive()

# Kai's dragon is the third (after Lloyd's and Zane's). Kai and Skylor escape on it; the Masters open theirs and flee.
func _b4() -> bool:
	goals([["Hold off the Anacondrai", "صدّ الأناكوندراي"], ["Call your elemental dragon", "استدعِ تنين عنصرك"],
		["Escape the island before time runs out", "اهرب من الجزيرة قبل انتهاء الوقت"]])
	if not await waves([["anacondrai", "anacondrai"], ["anacondrai", "anacondrai", "elite"]], Vector3(0, 0, 2), 9.0, "Hold off the Anacondrai", "صدّ الأناكوندراي"):
		return false
	goal_done(0)
	# inner trial: master your anger among the flames
	await say([
		ln("skylor", "Kai, your anger is the fire. Do not fight it. Stand in it until it is yours.", "كاي، غضبك هو النار. لا تحاربه. قف فيه حتى يصبح لك."),
		me("Then I stand. And I do not burn.", "إذن أقف. ولا أحترق."),
	])
	var hz: Dictionary = hazard_field([{"k": "flame", "p": Vector3(-5, 0, 2), "r": 3.0}, {"k": "flame", "p": Vector3(5, 0, 6), "r": 3.0}, {"k": "flame", "p": Vector3(0, 0, -5), "r": 3.0}], [])
	if not await survive(22.0, "anacondrai", Vector3(0, 0, 2), 3, "Master your anger (avoid the flames)", "تحكّم في غضبك (تجنّب اللهب)", 8.0):
		hazards_free(hz)
		return false
	hazards_free(hz)
	var st := place_stone(Vector3(0, 0, 2), Color(1.0, 0.45, 0.1), "Summon your dragon", "استدعِ تنينك")
	for i in 5:
		isl.spawn_enemy("anacondrai", ring_pos(Vector3(0, 0, 2), 10.0, i, 5))
	isl.hud.set_objective(L("Call your elemental dragon at the glowing stone (USE)!", "استدعِ تنين عنصرك عند الحجر المتوهج (USE)!"))
	if not await wait_stone(st):
		return false
	await hook("ch08_kai_dragon",
		"Kai calls his elemental dragon, the third master to do so: a blaze of fire in the shape of a great serpent.",
		"يستدعي كاي تنين عنصره، الثالث بين الأسياد: لهب بشكل ثعبان عظيم.",
		Vector3(10, 5, 14), Vector3(0, 3, 2))
	GameState.award("fire_dragon")
	await dragon_strike(Color(1.0, 0.45, 0.1), Vector3(0, 0, 2), 80.0)
	isl.clear_enemies()
	goal_done(1)
	await say([
		me("My own dragon. I almost forgot what it feels like to be proud of this fire.", "تنيني. كدت أنسى كيف يكون الفخر بهذه النار."),
		ln("skylor", "Then fly, Kai. Get us off this island.", "إذن حلّق يا كاي. أخرجنا من هذه الجزيرة."),
	])
	await hook("ch08_dragons_escape",
		"The Masters open their dragons one by one and flee the island, with Chen's new army behind them.",
		"يفتح الماسترز تنانينهم واحدًا تلو الآخر ويفرّون من الجزيرة، وجيش تشِن الجديد خلفهم.",
		Vector3(0, 18, 30), Vector3(0, 6, -10))
	# the escape on the dragons (flight mode in rail form)
	var fly_pts: Array = snake(Vector3(0, 0.2, 10), Vector3(-80, 0.2, 230), 14, 20.0)
	var fobs: Array = []
	for i in range(1, 9):
		fobs.append({"s": float(i) * 30.0, "off": sin(float(i) * 2.1) * 3.5, "k": "rock", "y": 3.0 + float(i % 3) * 2.2})
	await isl.hud.banner(L("Dragon flight! Stick: steer and climb   ATK: fire breath   DGE: boost", "طيران التنين! العصا: توجيه وارتفاع   ATK: لهب   DGE: تسريع"), 3.5)
	if not await rail_run("dragon", fly_pts, {"speed": 15.0, "width": 6.0, "obstacles": fobs}, "Escape on the dragons", "الهروب على التنانين"):
		return false
	goal_done(2)
	jade_if(8, ["ch8_scratch", "ch8_page", "ch8_frost", "ch8_ember"], "The Day of the Dragon", "يوم التنين")
	goals_clear()
	return await finish(1600.0)
