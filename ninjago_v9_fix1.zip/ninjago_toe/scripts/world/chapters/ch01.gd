class_name Ch01
extends ChapterBase
## Chapter 1 - The Invitation (ep. 35). Spec: grief at Zane's statue, Lloyd gathers the team, the
## invitation arrives, the trip to Chen's island. GAMEPLAY: Kai fights Karlof on the way.
## v4 beats: courtyard (talk goals + optional note) -> arrival ambush -> door puzzle -> Karlof (2 phases).
## Hooks: ch01_mourning, ch01_invitation, ch01_voyage, ch01_arrival, ch01_karlof_intro.
## VERIFY: whether Nya really stays behind (spec: she sneaks onto the ferry in ch. 4); how the
## Kai/Karlof fight ends (here: interrupted); the ambush/door puzzle are GAMEPLAY padding, not story events.

func _init() -> void:
	num = 1
	title = ["The Invitation", "الدعوة"]

func beats() -> Array:
	var party: Array = ["jay", "cole", "lloyd"]
	return [
		beat("ch01_home", "kai", ["jay", "cole", "lloyd", "nya"], Vector3(0, 0.2, 52), _b0),
		beat("ch01_ambush", "kai", party, Vector3(0, 0.2, 52), _b1),
		beat("ch01_gate", "kai", party, Vector3(0, 0.2, 38), _b2),
		beat("ch01_karlof", "kai", party, Vector3(0, 0.2, 30), _b3),
	]

# The beach stands in for the monastery courtyard (placeholder set: pedestal + pale statue).
func _b0() -> bool:
	await begin()
	isl._block(Vector3(5, 0.5, 46), Vector3(2.2, 1.0, 2.2), Color(0.55, 0.55, 0.6))
	var statue := spawn_fig({"suit": Color(0.85, 0.87, 0.92), "style": "ninja", "scale": 1.4}, Vector3(5, 1.0, 46), PI)
	goals([["Check on each of your friends", "اطمئن على كل واحد من أصدقائك"],
		["Read the memorial note at the statue", "اقرأ مذكرة التذكار عند التمثال"],
		["Gather everyone at the statue", "اجمع الجميع عند التمثال"]])
	note(Vector3(7, 0, 47), "Memorial Note", "مذكرة التذكار",
		"Someone left a few words at the foot of the statue: he gave everything so that we could keep going.",
		"ترك أحدهم كلمات عند قدم التمثال: لقد أعطى كل شيء كي نستطيع المتابعة.", "ch1_memorial")
	note(Vector3(-9, 0, 56), "Torn Notebook", "دفتر ممزق",
		"A notebook page full of tidy calculations, and in the margin a small drawing of a smiling robot. (Optional find.)",
		"صفحة دفتر مليئة بحسابات مرتبة، وعلى الهامش رسم صغير لروبوت مبتسم. (اكتشاف اختياري.)", "ch1_notebook")
	isl.hud.set_objective(L("Walk around the courtyard and talk with the team.", "تجوّل في الساحة وتحدّث مع الفريق."))
	if not await visit_party(["jay", "cole", "lloyd", "nya"], 0):
		return false
	if not await wait_flag("ch1_memorial"):
		return false
	goal_done(1)
	if flag_set("ch1_notebook"):
		side_reward("ch1_notebook", "Zane's notebook", "دفتر زين")
	isl.hud.set_objective(L("Stand by the statue.", "قف عند التمثال."))
	if not await wait_near(Vector3(5, 0, 46), 4.5):
		return false
	goal_done(2)
	if flag_set("ch1_notebook"):
		side_reward("ch1_notebook", "Zane's notebook", "دفتر زين")
	goals_clear()
	await hook("ch01_mourning",
		"Days after Zane vanished into the Digiverse, the team stands before his statue. Nobody speaks.",
		"بعد أيام من اختفاء زين في الـ Digiverse، يقف الفريق أمام تمثاله. لا أحد يتكلم.",
		Vector3(-2, 3, 55), Vector3(5, 2.5, 46))
	if not isl._alive():
		return false
	await say([
		me("It has been days, and the place still feels empty without him.", "مرّت أيام، والمكان ما زال فارغًا من دونه."),
		ln("jay", "He would hate us standing here like statues ourselves.", "كان سيكره أن نقف هنا كالتماثيل."),
		ln("cole", "He would hate it, then explain exactly why, with numbers.", "كان سيكرهه، ثم يشرح السبب بالأرقام."),
		ln("nya", "He walked into the Digiverse for us. If there is a way in, there is a way back.", "دخل الـ Digiverse من أجلنا. إن كان هناك طريق للدخول فهناك طريق للعودة."),
		ln("lloyd", "Then we start by staying together. All of us. No more drifting apart.", "إذن نبدأ بأن نبقى معًا. جميعنا. لا مزيد من التفرّق."),
	])
	await hook("ch01_invitation",
		"A messenger arrives with an invitation: Master Chen is holding a Tournament of Elements on his island.",
		"يصل رسول بدعوة: الماستر تشِن ينظّم بطولة العناصر على جزيرته.",
		Vector3(8, 3, 54), Vector3(5, 2, 46))
	await say([
		ln("jay", "A tournament for elemental masters. Fire, lightning, earth... that is us.", "بطولة لأسياد العناصر. النار والبرق والأرض... هذا نحن."),
		ln("cole", "Or it is bait. Somebody wants masters in one place.", "أو هي طُعم. أحدهم يريد الأسياد في مكان واحد."),
		me("Maybe. But a gathering of masters is also the best place to ask questions about Zane.", "ربما. لكن تجمّع الأسياد هو أفضل مكان لنسأل عن زين."),
		ln("lloyd", "Kai, Jay, Cole: you enter. Nya and I will watch the boat and the news.", "كاي وجاي وكول: تدخلون. أنا ونيا نراقب القارب والأخبار."),
	])
	await hook("ch01_voyage",
		"The ferry crosses the sea toward Chen's island under a bruised evening sky.",
		"تعبر العبّارة البحر نحو جزيرة تشِن تحت سماء مساء داكنة.",
		Vector3(-6, 4, 62), Vector3(0, 1, 50))
	drop_fig(statue)
	return isl._alive()

# Arrival + an ambush of Chen's guards on the beach path. (Gameplay padding: VERIFY, not a spec event.)
func _b1() -> bool:
	isl.chapter_start()
	goals([["Take in the island", "تأمّل الجزيرة"], ["Reach the middle of the path", "اصل إلى منتصف الطريق"],
		["Defeat the guards who block the path", "اهزم الحراس الذين يسدّون الطريق"], ["Open the gate", "افتح البوابة"],
		["Reach the arena", "اصل إلى الساحة"]])
	await hook("ch01_arrival",
		"The ninja step onto Chen's island. Banners, torches, and a crowd of strangers with strange powers.",
		"ينزل النينجا على جزيرة تشِن. رايات ومشاعل وحشد من الغرباء بقوى غريبة.",
		Vector3(0, 12, 80), Vector3(0, 2, 45))
	if not isl._alive():
		return false
	goal_done(0)
	await say([
		me("Stay sharp. We are guests here, and guests get watched.", "ابقوا متيقظين. نحن ضيوف هنا، والضيوف يُراقَبون."),
		ln("jay", "Nice island. Suspiciously nice.", "جزيرة جميلة. جميلة بشكل مريب."),
	])
	isl.hud.set_objective(L("A rope gate blocks the pier road: pull the lever.", "بوابة حبال تسدّ طريق الرصيف: اسحب الذراع."))
	if not await lever_door(Vector3(0, 0, 47), Vector3(7, 3, 1), Vector3(6, 0, 49)):
		return false
	isl.hud.set_objective(L("Follow the path toward the arena.", "اتبع الطريق نحو الساحة."))
	if not await checkpoints([Vector3(4, 0, 50), Vector3(-4, 0, 44), Vector3(0, 0, 38)], "Scout the path", "استكشف الطريق", 0.0, Color(0.4, 0.9, 1.0)):
		return false
	goal_done(1)
	await say([ln("cole", "Guards ahead, and they do not look like they are here to give directions.", "حرّاس في الأمام، ولا يبدو أنهم هنا ليدلّونا على الطريق.")])
	if not await waves([["guard", "guard"], ["guard", "grunt", "grunt"], ["elite", "guard"]], Vector3(0, 0, 32), 8.0, "Fight off the guards", "صدّ الحراس"):
		return false
	goal_done(2)
	checkpoint()
	return isl._alive()

# Door puzzle: push a crate onto the plate to open the gate across the path.
func _b2() -> bool:
	goals([["Take in the island", "تأمّل الجزيرة"], ["Reach the middle of the path", "اصل إلى منتصف الطريق"],
		["Defeat the guards who block the path", "اهزم الحراس الذين يسدّون الطريق"], ["Open the gate", "افتح البوابة"],
		["Reach the arena", "اصل إلى الساحة"]])
	for i in 3:
		goal_done(i)
	await say([ln("lloyd", "A gate. There must be a plate somewhere that opens it.", "بوابة. لا بد من وجود لوح ما يفتحها.")])
	isl.hud.set_objective(L("Push a crate onto the glowing plate (the gate opens).", "ادفع صندوقًا فوق اللوح المتوهج (تنفتح البوابة)."))
	if not await plate_door(Vector3(0, 0, 22), Vector3(7, 4, 1), Vector3(-7, 0, 29), [Vector3(5, 0.7, 33), Vector3(-5, 0.7, 36)]):
		return false
	goal_done(3)
	await say([ln("cole", "The gate noise woke the whole path. Hold position!", "ضجيج البوابة أيقظ الطريق كله. اثبتوا!")])
	if not await survive(20.0, "guard", Vector3(0, 0, 26), 3, "Guards rush the gate: hold out", "الحراس يهجمون على البوابة: اصمدوا"):
		return false
	checkpoint()
	isl.hud.set_objective(L("Go through the gate.", "اعبر البوابة."))
	return await wait_near(Vector3(0, 0, 18), 4.0)

func _b3() -> bool:
	goal_done(4)
	await say([ln("jay", "More guards at the arena gate. They are testing everyone who walks in.", "حرّاس آخرون عند بوابة الساحة. يختبرون كل من يدخل.")])
	if not await fight(["guard", "guard", "grunt", "grunt"], Vector3(0, 0, 26), 7.0, "Pass the gate guards", "تجاوز حراس البوابة"):
		return false
	await hook("ch01_karlof_intro",
		"A huge contender blocks the path and decides Kai is in his way. His name is Karlof.",
		"متسابق ضخم يسدّ الطريق ويقرر أن كاي يقف في طريقه. اسمه كارلوف.",
		Vector3(6, 3, 38), Vector3(0, 1.5, 24))
	await say([
		ln("karlof", "You walk like you already own the arena. Let us see if you fight like it.", "تمشي كأنك تملك الساحة. لنرَ إن كنت تقاتل كذلك."),
		me("I came to find someone, not to start fights. But if you insist...", "جئت لأجد شخصًا، لا لأبدأ معارك. لكن إن أصررت..."),
	])
	if not await duel("karlof", Vector3(0, 0.3, 22), "Beat back Karlof!", "تصدَّ لكارلوف!", 0.3):
		return false
	GameState.award("karlof_duel")
	await say([
		ln("karlof", "Enough. A bell is ringing; the real matches are about to be posted.", "كفى. الجرس يدق؛ ستُعلَن المباريات الحقيقية قريبًا."),
		ln("karlof", "We will finish this inside the arena, where it counts.", "سننهي هذا داخل الساحة، حيث يُحتسب."),
		ln("jay", "Wow. Not even inside the gates and you already made a friend.", "رائع. لم ندخل البوابة بعد وكوّنت صديقًا."),
	])
	jade_if(1, ["ch1_memorial", "ch1_notebook"], "The Invitation", "الدعوة")
	goals_clear()
	return await finish(600.0)
