class_name Ch04
extends ChapterBase
## Chapter 4 - Ninja Roll (ep. 38). Spec: the "Thunderblade" round, Lloyd vs Chamille; Nya sneaks onto
## Chen's ferry (the D.B. Express); Cole starts planning an escape from the prison with Zane and the
## losing contestants.
## v4 beats: Lloyd (ring puzzle + guard waves + 2-phase match) -> Nya (two stealth runs) -> Cole (prison).
## Hooks: ch04_round_intro, ch04_nya_infiltrates, ch04_nya_aboard, ch04_escape_plan.
## v6: Thunderblade = Chen's roller-skating contest; Chamille is the Master of Form (canon per STORY_SPEC v2). VERIFY: the result; how Zane ended up in the prison with Cole;
## what the D.B. Express is (only "the ferry"); Cole in prison after losing in ch.3; guard waves,
## plates and levers are gameplay padding with Chen's followers.

func _init() -> void:
	num = 4
	title = ["Ninja Roll", "جولة النينجا"]

func beats() -> Array:
	return [
		beat("ch04_lloyd_chamille", "lloyd", ["kai", "jay", "cole"], Vector3(0, 0.2, 40), _b0),
		beat("ch04_nya_ferry", "nya", [], Vector3(-14, 0.2, 56), _b1),
		beat("ch04_cole_prison", "cole", ["zane"], Vector3(-50, 0.2, -10), _b2),
	]

func _b0() -> bool:
	await begin()
	goals([["Open the round gate (crate on the plate)", "افتح بوابة الجولة (صندوق على اللوح)"],
		["Win the warm-up fights", "اربح قتالات الإحماء"], ["Read the round board", "اقرأ لوحة الجولة"],
		["Defeat Chamille", "اهزم شاميل"], ["Find the lightning charm (optional)", "اعثر على تميمة البرق (اختياري)"],
		["Use Chen's traps against Chamille", "استخدم فخاخ تشِن ضد شاميل"], ["Win the Thunderblade skate race", "اربح سباق Thunderblade بالتزلج"]])
	note(Vector3(-24, 0, 24), "Lightning Charm", "تميمة البرق",
		"A little charm shaped like a bolt, left by a contestant who prefers luck to training.",
		"تميمة صغيرة على شكل صاعقة، تركها متسابق يفضّل الحظ على التدريب.", "ch4_charm")
	await say([ln("kai", "Guards at the dock road! Hold them off while Lloyd opens the gate.", "حرّاس على طريق الرصيف! أبقوهم بعيدًا بينما يفتح لويد البوابة.")])
	if not await survive(25.0, "guard", Vector3(0, 0, 36), 3, "Hold the road", "احمِ الطريق"):
		return false
	isl.hud.set_objective(L("The round gate is shut: push a crate onto the plate.", "بوابة الجولة مغلقة: ادفع صندوقًا فوق اللوح."))
	if not await plate_door(Vector3(0, 0, 24), Vector3(8, 4, 1), Vector3(8, 0, 32), [Vector3(-6, 0.7, 36), Vector3(5, 0.7, 38)]):
		return false
	goal_done(0)
	checkpoint()
	if not await waves([["guard", "grunt", "grunt"], ["elite", "guard"], ["brute", "guard", "guard"]], Vector3(0, 0, 14), 9.0, "Warm-up fights", "قتالات الإحماء"):
		return false
	goal_done(1)
	if flag_set("ch4_charm"):
		goal_done(4)
		side_reward("ch4_charm", "the lightning charm", "تميمة البرق")
	checkpoint()
	await hook("ch04_round_intro",
		"The Thunderblade race begins: a deadly roller-skating contest. Lloyd's opponent is Chamille, the Master of Form.",
		"يبدأ سباق Thunderblade، مسابقة تزلّج قاتلة. خصم لويد هي شاميل، ماستر الشكل.",
		Vector3(-6, 12, -26), Vector3(0, 10.5, -42))
	goal_done(2)
	await say([
		ln("chamille", "A kid with a green suit. Chen must be joking.", "فتى ببذلة خضراء. لا بد أن تشِن يمزح."),
		me("I get that a lot. Usually before the fight ends.", "أسمع هذا كثيرًا. وعادة قبل أن تنتهي المعركة."),
	])
	# Thunderblade: the roller-skating race (rail mode). VERIFY: the real result; here Lloyd must reach the line first.
	var skate_pts: Array = snake(Vector3(-140, 0.2, 90), Vector3(140, 0.2, 90), 15, 22.0)
	var sobs: Array = []
	for i in range(1, 10):
		sobs.append({"s": float(i) * 34.0, "off": sin(float(i) * 2.3) * 3.8, "k": "slab"})
	for i in range(1, 5):
		sobs.append({"s": 40.0 + float(i) * 70.0, "off": cos(float(i) * 1.7) * 3.0, "k": "boost"})
	await say([ln("chamille", "Skates, not fists, kid. First to the line decides who is still standing.", "عجلات لا قبضات يا فتى. أول من يعبر الخط يقرر من يبقى واقفًا.")])
	await isl.teleport_party(skate_pts[0])
	var rival := spawn_fig({"suit": Color(0.6, 0.2, 0.7), "style": "ninja"}, (skate_pts[0] as Vector3) + Vector3(2.5, 0, 0), 0.0)
	await isl.hud.banner(L("Stick: steer   JMP: jump   DGE: boost", "العصا: توجيه   JMP: قفز   DGE: تسريع"), 3.0)
	var raced: bool = await rail_run("skate", skate_pts, {"speed": 12.0, "width": 5.0, "rival_speed": 11.0, "obstacles": sobs, "tricks": [90.0, 200.0, 300.0]}, "Thunderblade race", "سباق Thunderblade", rival)
	drop_fig(rival)
	if not raced:
		return false
	goal_done(6)
	await isl.teleport_party(Vector3(0, 0.2, 10))
	if not await trap_duel("chamille", Vector3(0, 0.3, -12), ARENA_TRAPS, ARENA_BUTTONS, "Defeat Chamille!", "اهزم شاميل!", 0.0, 5):
		return false
	goal_done(3)
	GameState.points += 250
	await say([
		ln("chamille", "Hm. Not a joke after all.", "همم. لم يكن مزحة بعد كل شيء."),
		ln("kai", "Nice one, Lloyd. But something is off: Nya should have called by now.", "أحسنت يا لويد. لكن هناك خطب: كان على نيا أن تتصل الآن."),
	])
	goals_clear()
	return isl._alive()

# The boat on the beach stands in for the ferry. Two stealth runs: the pier, then the path.
func _b1() -> bool:
	goals([["Slip past the dock guards", "تسلّل من حراس الرصيف"], ["Cross the beach path unseen", "اعبر طريق الشاطئ دون أن يراك أحد"],
		["Stash the lantern (optional)", "أخفِ الفانوس (اختياري)"], ["Get inside the island", "ادخل إلى الجزيرة"]])
	note(Vector3(-20, 0, 50), "Dock Lantern", "فانوس الرصيف",
		"A lantern left burning on the dock. Nobody would notice if it went missing. (Optional find.)",
		"فانوس ترك مشتعلًا على الرصيف. لن يلاحظ أحد لو اختفى. (اكتشاف اختياري.)", "ch4_lantern")
	await hook("ch04_nya_infiltrates",
		"Outside the island, Nya disguises the D.B. Express as a noodle truck and, with Dareth, slips toward Chen's ferry in the dark.",
		"خارج الجزيرة، تنكّر نيا الـ D.B. Express على هيئة شاحنة نودلز وتتسلل مع داريث نحو عبّارة تشِن في العتمة.",
		Vector3(-26, 6, 66), Vector3(-14, 1, 60))
	await say([me("Waiting by the boat is not going to find Zane. I am getting on that ferry.", "الانتظار بجوار القارب لن يجد زين. سأصعد إلى تلك العبّارة.")])
	var w1: Array = [
		{"c": Vector3(-8, 0, 56), "amp": Vector3(5, 0, 0), "speed": 1.2, "r": 3.0},
		{"c": Vector3(-14, 0, 50), "amp": Vector3(0, 0, 4), "speed": 1.5, "r": 2.8},
	]
	if not await stealth([Vector3(-18, 0, 50), Vector3(-10, 0, 52), Vector3(-4, 0, 54)], w1, Vector3(-14, 0.2, 56), "Slip past the dock guards", "تسلّل من حراس الرصيف"):
		return false
	goal_done(0)
	checkpoint()
	var w2: Array = [
		{"c": Vector3(2, 0, 52), "amp": Vector3(6, 0, 0), "speed": 1.2, "r": 3.2},
		{"c": Vector3(0, 0, 44), "amp": Vector3(0, 0, 4), "speed": 1.6, "r": 3.0},
		{"c": Vector3(-2, 0, 38), "amp": Vector3(7, 0, 0), "speed": 1.1, "r": 3.2},
	]
	if not await stealth([Vector3(8, 0, 48), Vector3(-8, 0, 42), Vector3(0, 0, 34)], w2, Vector3(-4, 0.2, 54), "Cross the path unseen", "اعبر الطريق دون أن يراك أحد"):
		return false
	goal_done(1)
	if not await checkpoints([Vector3(6, 0, 30), Vector3(-6, 0, 24), Vector3(0, 0, 16)], "Slip through the shadows", "تسلّلي عبر الظلال", 45.0, Color(0.4, 0.7, 1.0), Vector3(0, 0.2, 34)):
		return false
	GameState.award("nya_spy")
	if flag_set("ch4_lantern"):
		goal_done(2)
		side_reward("ch4_lantern", "the dock lantern", "فانوس الرصيف")
	await hook("ch04_nya_aboard",
		"Nya makes it onto the island unseen.",
		"تصل نيا إلى الجزيرة دون أن يراها أحد.",
		Vector3(4, 5, 44), Vector3(0, 1.5, 34))
	goal_done(3)
	await say([
		me("In. Now to find out what Chen is really hiding.", "دخلت. الآن لأعرف ما الذي يخفيه تشِن حقًّا."),
		ln("dareth", "Wait for me! I have the truck, a plan, and several snacks.", "انتظريني! معي الشاحنة وخطة وبعض الوجبات الخفيفة."),
		me("Dareth, quiet. We are sneaking.", "داريث، اهدأ. نحن نتسلل."),
		ln("dareth", "I am sneaking. This is my sneaking face.", "أنا أتسلل. هذا وجه التسلل خاصتي."),
	])
	goals_clear()
	return isl._alive()

# The cave stands in for the prison.
func _b2() -> bool:
	goals([["Deal with the prison guards", "تعامل مع حراس السجن"], ["Open the cell door (lever)", "افتح باب الزنزانة (الذراع)"],
		["Gather the defeated contestants", "اجمع المتسابقين الخاسرين"], ["Hide the plan note (optional)", "أخفِ مذكرة الخطة (اختياري)"], ["Collect the cell keys across the conveyor belts", "اجمع مفاتيح الزنازين عبر السيور"]])
	note(Vector3(-54, 0, -16), "Scratched Wall", "جدار منقوش",
		"Tally marks and a rough map are scratched into the cave wall. A previous prisoner kept count of the guard shifts.",
		"علامات عدّ وخريطة خشنة محفورة على جدار الكهف. سجين سابق دوّن مناوبات الحراس.", "ch4_wall")
	await say([
		me("The guards think a few locked doors will keep losers quiet.", "الحراس يظنون أن بضعة أبواب موصدة تُسكت الخاسرين."),
		ln("zane", "My analysis says the cell door and the guard schedule have one weakness in common.", "تحليلي يقول إن باب الزنزانة وجدول الحراس يشتركان في نقطة ضعف واحدة."),
	])
	if not await waves([["guard", "guard"], ["guard", "grunt", "brute"]], Vector3(-50, 0, -12), 4.5, "Overpower the guards", "تغلّب على الحراس"):
		return false
	goal_done(0)
	checkpoint()
	await say([ln("zane", "Reinforcements. Hold them off until the lock gives.", "تعزيزات. أبقوهم بعيدًا حتى ينفتح القفل.")])
	if not await survive(20.0, "guard", Vector3(-50, 0, -12), 3, "Hold the cell block", "احمِ جناح الزنازين", 4.5):
		return false
	# noodle factory: conveyor belts push you around while patrols sweep the floor (positions are a gameplay choice)
	var belts: Array = [conveyor(Vector3(-46, 0, -22), Vector3(10, 0.3, 4), Vector3(1, 0, 0), 3.0), conveyor(Vector3(-54, 0, -28), Vector3(10, 0.3, 4), Vector3(-1, 0, 0), 3.0)]
	await say([ln("zane", "The keys hang over the noodle line. Mind the belts, and mind the patrols.", "المفاتيح معلّقة فوق خط النودلز. انتبهوا للسيور، وانتبهوا للدوريات.")])
	var key_pts: Array = [Vector3(-40, 0, -22), Vector3(-60, 0, -28), Vector3(-50, 0, -18)]
	var patrol: Array = [{"c": Vector3(-50, 0, -24), "amp": Vector3(10, 0, 0), "speed": 0.7, "r": 3.2}, {"c": Vector3(-50, 0, -16), "amp": Vector3(0, 0, 6), "speed": 0.9, "r": 3.0}]
	if not await stealth(key_pts, patrol, Vector3(-50, 0.2, -12), "Collect the cell keys", "اجمع مفاتيح الزنازين"):
		return false
	for b in belts:
		(b as Node).queue_free()
	goal_done(4)
	checkpoint()
	isl.hud.set_objective(L("Pull the lever to open the cell door.", "اسحب الذراع لتفتح باب الزنزانة."))
	if not await lever_door(Vector3(-50, 0, -6), Vector3(6, 4, 1), Vector3(-45, 0, -10)):
		return false
	goal_done(1)
	if flag_set("ch4_wall"):
		goal_done(3)
		side_reward("ch4_wall", "the scratched wall", "الجدار المنقوش")
	await wait_near(Vector3(-50, 0, -8), 5.0)
	await hook("ch04_escape_plan",
		"Cole, Zane and the defeated contestants huddle together and plan a way out of the prison.",
		"يتحلّق كول وزين والمتسابقون الخاسرون ويخططون للهروب من السجن.",
		Vector3(-44, 4, -8), Vector3(-52, 1.5, -12))
	goal_done(2)
	await say([
		me("We need everyone together or the plan fails. And someone outside to help.", "نحتاج الجميع معًا وإلا فشلت الخطة. ونحتاج أحدًا في الخارج."),
		ln("zane", "Then we begin tonight. Slowly, quietly, and with extremely careful timing.", "إذن نبدأ الليلة. ببطء وهدوء وتوقيت دقيق جدًّا."),
	])
	jade_if(4, ["ch4_charm", "ch4_lantern"], "Ninja Roll", "جولة النينجا")
	goals_clear()
	return await finish(1200.0)
