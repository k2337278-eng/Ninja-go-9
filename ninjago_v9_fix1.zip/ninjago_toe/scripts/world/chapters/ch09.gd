class_name Ch09
extends ChapterBase
## Chapter 9 - The Greatest Fear of All (ep. 43), per STORY_SPEC v2: Chen's cultists camp in the subway, the ninja reunite
## with Wu and go to the Kryptarium prison to ask a tiny Pythor for help; the cultists free the inmates and seize Pythor;
## Pythor later escapes Chen with the Book of Spells (ch. 10).
## v8 beats: the race (Wu joins) -> Kryptarium gate (Warden Noble) and blocks -> escort tiny Pythor -> prison riot and the
## seizure.
## Hooks: ch09_race_begins, ch09_wu_meets, ch09_noble_gate, ch09_pythor_reached, ch09_pythor_seized.
## VERIFY: Wu rejoining on screen (the spec only says the ninja reunite with him: how and where is a gameplay choice);
## Warden Noble's role beyond running the Kryptarium; the subway camp (not shown); Pythor's "greatest fear" (episode
## title only); the prison location on the map is a gameplay choice; escort/riot/gates are gameplay padding with Chen's
## cultists (Anacondrai).

const RUINS := Vector3(-48, 0, -52)

func _init() -> void:
	num = 9
	title = ["The Greatest Fear of All", "أعظم خوف على الإطلاق"]

func beats() -> Array:
	var party: Array = ["kai", "jay", "zane", "skylor", "wu"]
	return [
		beat("ch09_race", "lloyd", party, Vector3(-44, 0.2, 40), _b0),
		beat("ch09_gate", "lloyd", party, Vector3(-48, 0.2, -36), _b1),
		beat("ch09_escort", "lloyd", party, Vector3(-48, 0.2, -44), _b2),
		beat("ch09_riot", "lloyd", party, Vector3(-48, 0.2, -46), _b3),
	]

func _b0() -> bool:
	await begin()
	goals([["Race across the city outskirts to the Kryptarium before the followers", "اعبر أطراف المدينة إلى سجن Kryptarium قبل الأتباع"],
		["Slip past the followers' scouts", "تسلّل من كشّافة الأتباع"], ["Open the stone gate (lever)", "افتح البوابة الحجرية (الذراع)"],
		["Hold the pass until your friends catch up", "اصمد في الممر حتى يلحق بك أصدقاؤك"], ["Find the shortcut map (optional)", "اعثر على خريطة الطريق المختصر (اختياري)"]])
	note(Vector3(-52, 0, 30), "Shortcut Map", "خريطة الطريق المختصر",
		"A hand-drawn map of the west woods, with one path circled twice: 'Fast, if you do not mind the thorns.'",
		"خريطة مرسومة باليد للغابة الغربية، ومسار محاط بدائرتين: 'سريع، إن لم تمانع الأشواك.'", "ch9_map")
	await hook("ch09_race_begins",
		"Chen's followers and the ninja both race toward the same place: the Kryptarium prison, where a tiny Pythor is held.",
		"يتسابق أتباع تشِن والنينجا نحو المكان نفسه: سجن Kryptarium، حيث يُحتجز بايثور المصغّر.",
		Vector3(-34, 8, 52), Vector3(-44, 1, 40))
	await hook("ch09_wu_meets",
		"On the road the ninja meet Wu again, and he agrees to come with them to the Kryptarium.",
		"على الطريق يلتقي النينجا بوو من جديد، ويوافق على مرافقتهم إلى الكريبتاريوم.",
		Vector3(-40, 5, 36), Vector3(-44, 1.5, 38))
	await say([
		ln("wu", "I came as soon as I heard. A tiny serpent may hold the key to a very large problem.", "جئت فور أن سمعت. ثعبان صغير قد يحمل مفتاح مشكلة كبيرة جدًّا."),
		me("Master Wu, it is good to have you with us.", "المعلّم وو، من الجيد أن تكون معنا."),
		ln("wu", "Walk fast and talk less. The followers are not far behind.", "امشوا بسرعة وتكلموا أقل. الأتباع ليسوا بعيدين."),
	])
	await say([
		ln("skylor", "Chen's followers know where Pythor is locked up. We have to get there first.", "أتباع تشِن يعرفون أين يُحتجز بايثور. يجب أن نصل قبلهم."),
		me("Then no stopping. Go!", "إذن لا توقف. انطلقوا!"),
	])
	if not await checkpoints([Vector3(-58, 0, 16), Vector3(-62, 0, -6)], "Race to Pythor", "السباق إلى بايثور", 55.0, Color(1.0, 0.4, 0.2), Vector3(-44, 0.2, 40), "anacondrai"):
		return false
	goal_done(0)
	checkpoint()
	var w: Array = [{"c": Vector3(-62, 0, -14), "amp": Vector3(5, 0, 0), "speed": 1.2, "r": 3.2}, {"c": Vector3(-60, 0, -24), "amp": Vector3(-5, 0, 0), "speed": 1.6, "r": 3.0}]
	if not await stealth([Vector3(-64, 0, -18), Vector3(-62, 0, -28)], w, Vector3(-62, 0.2, -6), "Slip past the scouts", "تسلّل من الكشّافة"):
		return false
	goal_done(1)
	if flag_set("ch9_map"):
		goal_done(4)
		side_reward("ch9_map", "the shortcut map", "خريطة الطريق المختصر")
	isl.hud.set_objective(L("A stone gate blocks the pass: pull the lever.", "بوابة حجرية تسدّ الممر: اسحب الذراع."))
	if not await lever_door(Vector3(-56, 0, -34), Vector3(9, 4, 1), Vector3(-62, 0, -32)):
		return false
	goal_done(2)
	if not await survive(30.0, "anacondrai", Vector3(-56, 0, -30), 4, "Hold the pass", "اصمد في الممر"):
		return false
	goal_done(3)
	return isl._alive()

func _b1() -> bool:
	dress_prison(RUINS)
	goals([["Reach the Kryptarium gate", "اصل إلى بوابة الكريبتاريوم"], ["Talk to Warden Noble", "تحدّث مع المأمور نوبل"],
		["Break the followers at the prison gate", "حطّم الأتباع عند بوابة السجن"], ["Open the inner door (crate on the plate)", "افتح الباب الداخلي (صندوق على اللوح)"],
		["Climb the broken wall", "تسلّق الجدار المكسور"], ["Read the serpent carving (optional)", "اقرأ النقش الأفعواني (اختياري)"],
		["Find the old coin (optional)", "اعثر على العملة القديمة (اختياري)"]])
	note(Vector3(-54, 0, -42), "Serpent Carving", "نقش أفعواني",
		"A carving of a coiled serpent, scratched over so many times that only its eyes remain.",
		"نقش لأفعى ملتفة، خُدش مرات كثيرة حتى لم يبق منه إلا العينان.", "ch9_carving")
	note(Vector3(-40, 0, -45), "Old Coin", "عملة قديمة",
		"A coin stamped with a snake eating its own tail. It is much older than the tournament.",
		"عملة مختومة بأفعى تأكل ذيلها. أقدم بكثير من البطولة.", "ch9_coin")
	var noble := spawn_fig({"suit": CharacterDB.DATA["noble"]["suit"], "style": "ninja"}, Vector3(-48, 0.2, -38), 0.0)
	if not await checkpoints([Vector3(-48, 0, -32), Vector3(-48, 0, -37)], "Reach the gate", "اصل إلى البوابة", 0.0, Color(0.6, 0.7, 0.9)):
		return false
	goal_done(0)
	await hook("ch09_noble_gate",
		"Warden Noble runs the Kryptarium. He is wary of visitors, but he hears Wu out.",
		"يدير المأمور نوبل الكريبتاريوم. يتوجّس من الزوّار، لكنه يُنصت إلى وو.",
		Vector3(-42, 3, -32), Vector3(-48, 1.5, -38))
	await say([
		ln("noble", "Nobody visits my prison without a very good reason. What is yours?", "لا أحد يزور سجني بلا سبب وجيه. فما سببكم؟"),
		ln("wu", "A prisoner of yours is the one thing standing between us and a worse war.", "سجينك هو الشيء الوحيد الذي يقف بيننا وبين حرب أسوأ."),
		ln("noble", "Then go in. But the cultists are already at my door, and I do not have the guards to stop them.", "إذن ادخلوا. لكن الأتباع عند بابي بالفعل، وليس لدي حرّاس يكفون لإيقافهم."),
	])
	goal_done(1)
	if isl.ruins_gate != null and not isl.ruins_gate.opened:
		isl.ruins_gate.open()
	if not await waves([["anacondrai", "anacondrai"], ["anacondrai", "anacondrai", "guard"], ["elite", "anacondrai", "anacondrai"]], RUINS, 6.0, "Hold the gate", "احمِ البوابة"):
		return false
	goal_done(2)
	if not await survive(20.0, "anacondrai", RUINS, 3, "More followers pour in", "المزيد من الأتباع يتدفقون", 6.0):
		return false
	checkpoint()
	isl.hud.set_objective(L("An inner door is sealed: push a crate onto the plate.", "باب داخلي مغلق: ادفع صندوقًا فوق اللوح."))
	if not await plate_door(Vector3(-48, 0, -58), Vector3(8, 4, 1), Vector3(-54, 0, -46), [Vector3(-42, 0.7, -46), Vector3(-52, 0.7, -49)]):
		return false
	goal_done(3)
	isl.hud.set_objective(L("Climb the broken wall and pull the lever.", "تسلّق الجدار المكسور واسحب الذراع."))
	if not await climb_lever(Vector3(-40, 0, -62), Vector3(0, 0, 1), 3.0):
		return false
	goal_done(4)
	if flag_set("ch9_carving"):
		goal_done(5)
		side_reward("ch9_carving", "the serpent carving", "النقش الأفعواني")
	if flag_set("ch9_coin"):
		goal_done(6)
		side_reward("ch9_coin", "the old coin", "العملة القديمة")
	drop_fig(noble)
	return isl._alive()

# Escort the tiny Pythor from his cell to the safe corner of the block while the cultists close in.
func _b2() -> bool:
	dress_prison(RUINS)
	goals([["Reach Pythor's cell", "اصل إلى زنزانة بايثور"], ["Meet Pythor", "قابل بايثور"], ["Escort Pythor to the safe corner", "رافق بايثور إلى الركن الآمن"],
		["Keep Pythor healthy", "حافظ على سلامة بايثور"]])
	if not await checkpoints([RUINS + Vector3(-6, 0, -2), RUINS + Vector3(6, 0, -4), RUINS + Vector3(0, 0, -6)], "Search the cell block", "فتّش عنبر الزنازين", 0.0, Color(0.5, 1.0, 0.4)):
		return false
	goal_done(0)
	var py := Minifig.new()
	isl.add_child(py)
	py.build({"suit": CharacterDB.DATA["pythor"]["suit"], "style": "ninja", "scale": 0.6})
	py.position = RUINS + Vector3(0, 0.2, -8)
	await hook("ch09_pythor_reached",
		"The ninja reach the Kryptarium cell and find a tiny Pythor.",
		"يصل النينجا إلى زنزانة الكريبتاريوم ويجدون بايثور مصغّرًا.",
		Vector3(-40, 5, -38), RUINS + Vector3(0, 1.5, -8))
	GameState.award("pythor_found")
	goal_done(1)
	await say([
		ln("pythor", "You came here, to me, of all places. Either you are very brave, or very desperate.", "جئتم إليّ أنا، من بين كل الأماكن. إما أنكم شجعان جدًّا، أو يائسون جدًّا."),
		me("Both. We need your help against Chen.", "كلاهما. نحتاج مساعدتك ضد تشِن."),
		ln("pythor", "Help the ones who defeated my kind? ...Then again, Chen is worse. Walk beside me, and mind the ceiling.", "أساعد من هزموا قومي؟ ...لكن تشِن أسوأ. امشوا بجانبي، وانتبهوا للسقف."),
	])
	checkpoint()
	var route: Array = [RUINS + Vector3(-5, 0, -4), RUINS + Vector3(-5, 0, 4), RUINS + Vector3(2, 0, 6), RUINS + Vector3(7, 0, 0)]
	if not await escort(py, route, "anacondrai", "Escort Pythor", "رافق بايثور", 100.0):
		return false
	goal_done(2)
	goal_done(3)
	checkpoint()
	py.queue_free()
	jade_if(9, ["ch9_carving", "ch9_coin", "ch9_map"], "The Greatest Fear of All", "أعظم خوف على الإطلاق")
	return isl._alive()

# The cultists free the inmates; the riot ends with Pythor seized.
func _b3() -> bool:
	goals([["Survive the prison riot", "اصمد في شغب السجن"], ["Beat the freed inmates and the cultists", "اهزم المساجين المحرَّرين والأتباع"],
		["Protect Wu and the others", "احمِ وو والآخرين"], ["Watch Pythor taken", "شاهد أسر بايثور"]])
	await say([ln("noble", "They are opening my cells! Everyone, brace yourselves!", "إنهم يفتحون زنازيني! الجميع، تماسكوا!")])
	var cells: Array = [RUINS + Vector3(-8, 0, -4), RUINS + Vector3(8, 0, -4), RUINS + Vector3(0, 0, 8)]
	if not await prison_riot(cells, ["anacondrai", "anacondrai", "elite"], 9.0, "Survive the riot", "اصمد في الشغب"):
		return false
	goal_done(0)
	goal_done(1)
	goal_done(2)
	var py := spawn_fig({"suit": CharacterDB.DATA["pythor"]["suit"], "style": "ninja", "scale": 0.6}, RUINS + Vector3(7, 0.2, 0), 0.0)
	await hook("ch09_pythor_seized",
		"In the chaos the cultists seize Pythor and drag him away to Chen.",
		"في الفوضى يستولي الأتباع على بايثور ويسحبونه إلى تشِن.",
		Vector3(-38, 5, -46), RUINS + Vector3(7, 1.5, 0))
	goal_done(3)
	drop_fig(py)
	await say([
		ln("wu", "We lost him. But a prisoner who has seen the cultists' faces will not stay quiet for long.", "فقدناه. لكن سجينًا رأى وجوه الأتباع لن يبقى صامتًا طويلًا."),
		me("Then we get him back. And we are ready for what comes next.", "إذن نستعيده. ونكون مستعدين لما سيأتي."),
	])
	undress_prison()
	goals_clear()
	return await finish(1200.0)
