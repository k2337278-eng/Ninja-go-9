class_name Hazard
extends Node3D
## Arena trap added by Chen's buttons (STORY_SPEC ch. 2-4). kind: "flame" | "wind" | "slab".
## A faint disc shows the trap area. fire() -> red warning ring (0.9 s) -> active phase.
## Active traps hurt EVERY fighter inside the radius (player side and enemy side), so the player can lure the
## opponent into them. VERIFY: Chen's real obstacles are only "obstacles added with his buttons" in the spec;
## flame/wind/slab are gameplay stand-ins (the spec's design note also lists platforms, not built here).

var kind := "flame"
var radius := 3.0
var wind_dir := Vector3(1, 0, 0)
var active_time := 3.0
var _warn := 0.0
var _on := 0.0
var _tick := 0.0
var _mat: StandardMaterial3D
var _disc: MeshInstance3D
var _st := -1

func _ready() -> void:
	_disc = MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = radius
	cm.bottom_radius = radius
	cm.height = 0.06
	cm.radial_segments = 24
	cm.rings = 1
	_mat = StandardMaterial3D.new()
	_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	cm.material = _mat
	_disc.mesh = cm
	_disc.position.y = 0.12
	_disc.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(_disc)
	_paint(0.0)

func busy() -> bool:
	return _warn > 0.0 or _on > 0.0

## Start the trap. Returns false when it is already running.
func fire(dur := 3.0) -> bool:
	if busy():
		return false
	active_time = dur
	_warn = 0.9
	Sfx.play("whoosh", 0.8)
	return true

func _color() -> Color:
	match kind:
		"wind":
			return Color(0.5, 0.9, 1.0)
		"slab":
			return Color(0.7, 0.7, 0.75)
	return Color(1.0, 0.45, 0.1)

func _paint(state: float) -> void:
	# state 0 dormant, 1 warning, 2 active
	if int(state) == _st:
		return
	_st = int(state)
	var c := _color()
	if state == 1.0:
		c = Color(1.0, 0.15, 0.1)
	_mat.albedo_color = Color(c.r, c.g, c.b, [0.12, 0.45, 0.7][int(state)])

func _fighters_inside() -> Array:
	var out: Array = []
	for n in get_tree().get_nodes_in_group("fighters"):
		var f := n as Fighter
		if f == null or f.state == Fighter.S.DEAD or not f.visible:
			continue
		if Vector2(f.global_position.x - global_position.x, f.global_position.z - global_position.z).length() <= radius:
			out.append(f)
	return out

func _hit(f: Fighter, dmg: float, kb: float, stun := 0.0) -> void:
	if f.take_damage(dmg, self, kb, stun, true) and f.team == "enemy":
		GameState.stat("trap_hits")

func _process(delta: float) -> void:
	if _warn > 0.0:
		_warn -= delta
		_paint(1.0)
		if _warn <= 0.0:
			_on = active_time if kind != "slab" else 0.25
			_tick = 0.0
			if kind == "slab":
				Effects.shake(self, 0.5)
				Sfx.play("impact")
				for f in _fighters_inside():
					_hit(f, 26.0, 8.0, 0.8)
			else:
				Sfx.play("elem", 0.8)
		return
	if _on > 0.0:
		_on -= delta
		_paint(2.0)
		_tick -= delta
		if kind == "flame" and _tick <= 0.0:
			_tick = 0.45
			for f in _fighters_inside():
				_hit(f, 9.0, 3.0)
		elif kind == "wind":
			for f in _fighters_inside():
				f.global_position += wind_dir.normalized() * 5.5 * delta
				if _tick <= 0.0:
					_tick = 1.0
					_hit(f, 3.0, 1.0)
		if _on <= 0.0:
			_paint(0.0)
	else:
		_paint(0.0)
