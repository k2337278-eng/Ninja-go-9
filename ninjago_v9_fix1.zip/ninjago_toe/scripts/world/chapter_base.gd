class_name ChapterBase
extends RefCounted
## Base class for ONE story chapter (scripts/world/chapters/chNN.gd).
## A chapter = a list of BEATS (beats()). One beat = one save checkpoint:
##   {"id", "player": char id, "party": [char ids], "spawn": Vector3, "mood": ""|"digi"|"dusk", "run": Callable}
## Chapters.run() runs the beats in order. When the next beat has a different player / party / mood
## the island scene is reloaded (Island.reload_story), so the right ninja is spawned.
## Beats must be restartable from their first line (the Retry button reloads the scene).
## CUTSCENE HOOKS: hook(id, en, ar) marks where a real cinematic will go (see docs/CUTSCENE_HOOKS.md).
## Story facts come from STORY_SPEC.md only; anything unconfirmed is tagged VERIFY in comments + docs.

const NAMES := {
	"karlof": ["Karlof", "كارلوف"], "ash": ["Ash", "آش"], "chamille": ["Chamille", "شاميل"],
	"clouse": ["Clouse", "كلاوس"], "chen": ["Master Chen", "الماستر تشِن"],
	"pixal": ["P.I.X.A.L.", "بيكسال"], "garmadon": ["Garmadon", "غارمادون"],
	"misako": ["Misako", "ميساكو"], "arcturus": ["General Arcturus", "الجنرال أركتوروس"],
}

## Chen's arena traps (ch. 2-4): flame, wind and slab hazards + two buttons the player can press (see Hazard).
const ARENA_TRAPS := [
	{"k": "flame", "p": Vector3(-7, 0, -10), "r": 3.2},
	{"k": "wind", "p": Vector3(7, 0, -9), "r": 3.4, "dir": Vector3(-1, 0, 0)},
	{"k": "slab", "p": Vector3(0, 0, -4), "r": 3.6},
]
const ARENA_BUTTONS := [
	{"p": Vector3(-13, 0, -2), "t": [0, 2]},
	{"p": Vector3(13, 0, -2), "t": [1, 0]},
]

var isl: Node3D
var story: Node
var num := 0
var title: Array = ["", ""]
var _goals: Array = []

func beats() -> Array:
	return []

func beat(id: String, player: String, party: Array, spawn: Vector3, run: Callable, mood := "") -> Dictionary:
	return {"id": id, "player": player, "party": party, "spawn": spawn, "run": run, "mood": mood}

# ------------------------------------------------------------------ text ---
func L(en: String, ar: String) -> String:
	return en if Loc.lang == "en" else ar

func nm(id: String) -> String:
	if NAMES.has(id):
		return Loc.pick(NAMES[id])
	return CharacterDB.name_of(id)

func narr() -> String:
	return Loc.t("narrator")

func pl() -> String:
	return isl.player.display_name

## Dialogue line spoken by a character id.
func ln(id: String, en: String, ar: String) -> Array:
	return [nm(id), L(en, ar), id, Voice.line_id(ar)]

## Dialogue line spoken by the narrator.
func nr(en: String, ar: String) -> Array:
	return [narr(), L(en, ar), "narrator", Voice.line_id(ar)]

## Dialogue line spoken by the character the player controls.
func me(en: String, ar: String) -> Array:
	return [pl(), L(en, ar), isl.player.char_id, Voice.line_id(ar)]

# ------------------------------------------------------------------ flow ---
func begin(first_banner := true) -> void:
	isl.chapter_start()
	if first_banner:
		await isl.hud.banner(L("Chapter %d: ", "الفصل %d: ") % num + Loc.pick(title), 2.0)

func say(lines: Array) -> void:
	await isl.talk(lines)

## Cutscene hook: plays Cutscenes.CUSTOM[id] when it exists, else a placeholder card.
func hook(id: String, en: String, ar: String, from := Vector3.ZERO, look := Vector3.ZERO) -> void:
	await isl.play_hook(id, en, ar, from, look)

func dist(p: Vector3) -> float:
	return Vector2(isl.player.global_position.x - p.x, isl.player.global_position.z - p.z).length()

func ok_alive() -> bool:
	return isl._alive() and isl.player.state != Fighter.S.DEAD

func wait_near(p: Vector3, r: float) -> bool:
	while isl._alive() and dist(p) > r:
		await isl.get_tree().create_timer(0.25).timeout
	return isl._alive()

func ring_pos(center: Vector3, r: float, i: int, n: int) -> Vector3:
	var a := TAU * i / float(n)
	return center + Vector3(cos(a) * r, 0.3, sin(a) * r)

func finish(par: float, extra: Array = []) -> bool:
	await isl.finish_chapter(num, par, true, extra)
	return isl._alive()

# ---------------------------------------------------------------- combat ---
## Spawn a ring of enemies and wait until all are dead.
func fight(kinds: Array, center: Vector3, r: float, obj_en: String, obj_ar: String) -> bool:
	var foes: Array = []
	for i in kinds.size():
		foes.append(isl.spawn_enemy(str(kinds[i]), ring_pos(center, r, i, kinds.size())))
	isl.hud.set_objective(L(obj_en, obj_ar))
	var ok: bool = await isl.wait_enemies_dead(foes)
	return ok

## Named duel against a Boss.build() fighter. stop_at > 0 ends the duel (scripted) when the
## opponent's health ratio drops to that value; stop_at == 0 fights to the end.
func duel(boss_id: String, pos: Vector3, obj_en: String, obj_ar: String, stop_at := 0.0) -> bool:
	var b: Boss = isl.spawn_boss(boss_id, pos)
	await isl.hud.banner(b.display_name, 1.4)
	isl.hud.set_objective(L(obj_en, obj_ar))
	while true:
		await isl.get_tree().create_timer(0.2).timeout
		if not isl._alive() or isl.player.state == Fighter.S.DEAD:
			return false
		if not is_instance_valid(b) or b.state == Fighter.S.DEAD:
			break
		if stop_at > 0.0 and b.health / b.max_health <= stop_at:
			break
	isl.clear_enemies()
	return isl._alive()

## Hold out for `secs` while `kind` enemies keep arriving (max_alive at once).
func survive(secs: float, kind: String, center: Vector3, max_alive: int, label_en: String, label_ar: String, ring := 10.0) -> bool:
	var t := secs
	var spawn_t := 0.0
	var foes: Array = []
	await isl.hud.banner(L(label_en, label_ar), 1.2)
	while t > 0.0:
		await isl.get_tree().create_timer(0.25).timeout
		if not ok_alive():
			return false
		t -= 0.25
		spawn_t -= 0.25
		foes = foes.filter(func(x): return is_instance_valid(x) and x.state != Fighter.S.DEAD)
		if spawn_t <= 0.0 and foes.size() < max_alive:
			spawn_t = 3.5
			foes.append(isl.spawn_enemy(kind, ring_pos(center, ring, randi() % 8, 8)))
		isl.hud.set_objective(L(label_en, label_ar) + " %d" % int(ceil(t)))
	isl.clear_enemies()
	return true

# ------------------------------------------------------------- movement ---
## Reach every point in order. secs > 0 adds a time limit (restart from retry_pos when it runs out).
## chaser != "" spawns that enemy kind near the player now and then.
func checkpoints(pts: Array, label_en: String, label_ar: String, secs: float, color: Color, retry_pos := Vector3.ZERO, chaser := "") -> bool:
	while true:
		var beacons: Array = []
		for p in pts:
			var bc: MeshInstance3D = isl.make_beacon(p, color)
			bc.visible = false
			beacons.append(bc)
		beacons[0].visible = true
		var t := secs
		var idx := 0
		var spawn_t := 6.0
		while idx < pts.size() and (secs <= 0.0 or t > 0.0):
			await isl.get_tree().create_timer(0.1).timeout
			if not ok_alive():
				return false
			if secs > 0.0:
				t -= 0.1
			if chaser != "":
				spawn_t -= 0.1
				if spawn_t <= 0.0:
					spawn_t = 7.0
					var a := randf() * TAU
					isl.spawn_enemy(chaser, isl.player.global_position + Vector3(cos(a) * 12.0, 0.3, sin(a) * 12.0))
			if dist(pts[idx]) < 3.2:
				beacons[idx].visible = false
				idx += 1
				Sfx.play("coin")
				if idx < pts.size():
					beacons[idx].visible = true
			var txt := L(label_en, label_ar) + " %d/%d" % [mini(idx + 1, pts.size()), pts.size()]
			if secs > 0.0:
				txt += " - %d s" % int(ceil(t))
			isl.hud.set_objective(txt)
		for bc in beacons:
			bc.queue_free()
		if idx >= pts.size():
			if chaser != "":
				isl.clear_enemies()
			return true
		isl.clear_enemies()
		await isl.hud.banner(L("Too slow! Try again.", "بطيء جدًا! حاول مرة أخرى."), 1.2)
		if retry_pos != Vector3.ZERO:
			await isl.teleport_party(retry_pos)
	return false

## Stealth: reach every point while avoiding moving red watch-zones. Being caught sends you back to
## the last checkpoint. watchers = [{"c": center, "amp": Vector3 swing, "speed": float, "r": radius}].
func stealth(pts: Array, watchers: Array, start: Vector3, label_en: String, label_ar: String) -> bool:
	var discs: Array = []
	for w in watchers:
		var mi := MeshInstance3D.new()
		var cm := CylinderMesh.new()
		cm.top_radius = float(w["r"])
		cm.bottom_radius = float(w["r"])
		cm.height = 0.06
		cm.radial_segments = 20
		cm.rings = 1
		var m := StandardMaterial3D.new()
		m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		m.albedo_color = Color(1.0, 0.15, 0.1, 0.4)
		cm.material = m
		mi.mesh = cm
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		isl.add_child(mi)
		discs.append(mi)
	var beacons: Array = []
	for p in pts:
		var bc: MeshInstance3D = isl.make_beacon(p, Color(0.3, 0.9, 1.0))
		bc.visible = false
		beacons.append(bc)
	beacons[0].visible = true
	var idx := 0
	var t := 0.0
	var last := start
	while idx < pts.size():
		await isl.get_tree().create_timer(0.1).timeout
		if not ok_alive():
			return false
		t += 0.1
		var spotted := false
		for i in watchers.size():
			var w: Dictionary = watchers[i]
			var c: Vector3 = w["c"]
			var off: Vector3 = w["amp"]
			var wp := c + off * sin(t * float(w["speed"]))
			(discs[i] as MeshInstance3D).position = wp + Vector3(0, 0.15, 0)
			var px: float = isl.player.global_position.x
			var pz: float = isl.player.global_position.z
			if Vector2(px - wp.x, pz - wp.z).length() < float(w["r"]):
				spotted = true
		if spotted:
			await isl.hud.banner(L("Spotted! Back to the last checkpoint.", "اكتُشفت! العودة لآخر نقطة."), 1.0)
			await isl.teleport_party(last)
			continue
		if dist(pts[idx]) < 2.8:
			beacons[idx].visible = false
			last = pts[idx]
			idx += 1
			Sfx.play("coin")
			if idx < pts.size():
				beacons[idx].visible = true
		isl.hud.set_objective(L(label_en, label_ar) + " %d/%d" % [mini(idx + 1, pts.size()), pts.size()])
	for d in discs:
		d.queue_free()
	for bc in beacons:
		bc.queue_free()
	return true

# ------------------------------------------------------------- set dressing ---
func spawn_fig(cfg: Dictionary, pos: Vector3, yaw := 0.0) -> Minifig:
	var m := Minifig.new()
	isl.add_child(m)
	m.build(cfg)
	m.position = pos
	m.rotation.y = yaw
	isl.npc_rigs.append(m)
	return m

func drop_fig(m: Minifig) -> void:
	if is_instance_valid(m):
		isl.npc_rigs.erase(m)
		m.queue_free()

func place_stone(pos: Vector3, color: Color, prompt_en: String, prompt_ar: String) -> StoryStone:
	var st := StoryStone.new()
	st.color = color
	st.prompt = [prompt_en, prompt_ar]
	st.position = pos
	isl.add_child(st)
	return st

func wait_stone(st: StoryStone) -> bool:
	while isl._alive() and not st.done:
		await isl.get_tree().create_timer(0.3).timeout
		if isl._alive() and isl.player.state == Fighter.S.DEAD:
			return false
	return isl._alive()

## A dragon of glowing spheres circles `center` for ~3 s and damages every enemy within 9 m.
## Placeholder visual for the elemental dragons (VERIFY: real dragon cinematics come later).
func dragon_strike(color: Color, center: Vector3, dmg: float) -> void:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.emission_enabled = true
	m.emission = color
	var seg: Array = []
	for i in 9:
		var mi := MeshInstance3D.new()
		var sm := SphereMesh.new()
		sm.radius = 1.1 - i * 0.08
		sm.height = sm.radius * 2.0
		sm.radial_segments = 8
		sm.rings = 4
		sm.material = m
		mi.mesh = sm
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		isl.add_child(mi)
		seg.append(mi)
	var t := 0.0
	var hit_t := 0.0
	while t < 3.2:
		await isl.get_tree().create_timer(0.03).timeout
		if not isl._alive():
			return
		t += 0.03
		hit_t -= 0.03
		for i in seg.size():
			var a := t * 2.4 - i * 0.32
			var h := 4.0 + sin(a * 1.5) * 1.5
			(seg[i] as MeshInstance3D).position = center + Vector3(cos(a) * 9.0, h, sin(a) * 9.0)
		if hit_t <= 0.0:
			hit_t = 0.35
			Effects.shake(isl, 0.3)
			Sfx.play("elem")
			for n in isl.get_tree().get_nodes_in_group("enemies"):
				var f := n as Fighter
				if f == null or f.state == Fighter.S.DEAD or n.is_in_group("practice"):
					continue
				if Vector2(f.global_position.x - center.x, f.global_position.z - center.z).length() < 9.5:
					f.take_damage(dmg, isl.player, 7.0)
					Effects.burst(f, f.global_position + Vector3(0, 1.0, 0), color, 10, 5.0)
	for s in seg:
		s.queue_free()

# ------------------------------------------------------------- objectives ---
## On-screen objective list. items = [[en, ar], ...]. Mark them with goal_done(i).
func goals(items: Array) -> void:
	_goals = []
	for it in items:
		_goals.append({"t": L(str(it[0]), str(it[1])), "done": false})
	isl.hud.set_goals(_goals)

func goal_done(i: int) -> void:
	if i >= 0 and i < _goals.size() and not bool(_goals[i]["done"]):
		_goals[i]["done"] = true
		isl.hud.set_goals(_goals)
		Sfx.play("coin")

func goals_clear() -> void:
	_goals = []
	isl.hud.set_goals(_goals)

## Save point inside a chapter (beats are the real restart points; this only tells the player).
func checkpoint() -> void:
	GameState.save_game()
	isl.hud.toast(L("Checkpoint saved", "تم حفظ نقطة"))

# ----------------------------------------------------- reusable activities ---
## Readable note. flag_id stores that it was read. Returns the scroll.
func note(pos: Vector3, title_en: String, title_ar: String, text_en: String, text_ar: String, flag_id: String) -> LoreScroll:
	var sc := LoreScroll.new()
	sc.counts = false
	sc.flag_id = flag_id
	sc.title = [title_en, title_ar]
	sc.text = [text_en, text_ar]
	sc.isl = isl
	sc.position = pos
	isl.add_child(sc)
	return sc

func flag_set(id: String) -> bool:
	return bool(GameState.flags.get(id, false))

func wait_flag(id: String) -> bool:
	while isl._alive() and not flag_set(id):
		await isl.get_tree().create_timer(0.3).timeout
		if isl._alive() and isl.player.state == Fighter.S.DEAD:
			return false
	return isl._alive()

## Optional side reward (once): skill point + toast.
func side_reward(flag: String, en: String, ar: String) -> void:
	if flag_set("side_" + flag):
		return
	GameState.flags["side_" + flag] = true
	GameState.skill_points += 1
	GameState.stat("side_goals")
	isl.hud.toast(L("Side goal done: ", "هدف جانبي مكتمل: ") + L(en, ar) + L(" (+1 skill point)", " (+1 نقطة مهارة)"))

## Waves of enemies: each wave = array of kinds. Banner per wave, short rest between waves.
func waves(list: Array, center: Vector3, r: float, label_en: String, label_ar: String) -> bool:
	for w in list.size():
		await isl.hud.banner(L("%s %d/%d", "%s %d/%d") % [L(label_en, label_ar), w + 1, list.size()], 1.0)
		var kinds: Array = list[w]
		if not await fight(kinds, center, r, label_en, label_ar):
			return false
		await isl.get_tree().create_timer(0.8).timeout
	return true

## Crate-on-plate puzzle: a door at door_pos opens when a crate rests on the plate. Waits until open.
func plate_door(door_pos: Vector3, door_size: Vector3, plate_pos: Vector3, crates: Array) -> bool:
	var door := Door.new()
	door.size = door_size
	door.color = Color(0.35, 0.3, 0.28)
	door.position = door_pos + Vector3(0, door_size.y * 0.5, 0)
	isl.add_child(door)
	var plate := PressurePlate.new()
	plate.position = plate_pos
	plate.changed.connect(func(p: bool):
		if p:
			door.open())
	isl.add_child(plate)
	for cp in crates:
		var c := Crate.new()
		c.position = cp as Vector3
		isl.add_child(c)
	while isl._alive() and not door.opened:
		await isl.get_tree().create_timer(0.3).timeout
		if isl.player.state == Fighter.S.DEAD:
			return false
	return isl._alive()

## Lever puzzle: a door opens when the lever is pulled. Returns when open.
func lever_door(door_pos: Vector3, door_size: Vector3, lever_pos: Vector3) -> bool:
	var door := Door.new()
	door.size = door_size
	door.color = Color(0.3, 0.28, 0.35)
	door.position = door_pos + Vector3(0, door_size.y * 0.5, 0)
	isl.add_child(door)
	var lv := Lever.new()
	lv.position = lever_pos
	lv.activated.connect(func(): door.open())
	isl.add_child(lv)
	while isl._alive() and not door.opened:
		await isl.get_tree().create_timer(0.3).timeout
		if isl.player.state == Fighter.S.DEAD:
			return false
	return isl._alive()

## Climb puzzle: ledge block with a vine wall; the lever on top must be pulled. top_dir = direction of the ledge.
func climb_lever(base: Vector3, top_dir: Vector3, height: float) -> bool:
	isl._block(base + top_dir * 3.0 + Vector3(0, height * 0.5, 0), Vector3(8, height, 6), Color(0.4, 0.37, 0.35))
	var cw := ClimbWall.new()
	cw.size = Vector3(4, height + 0.2, 1.8)
	cw.top_dir = top_dir
	cw.position = base + Vector3(0, height * 0.5, 0) - top_dir * 0.1
	isl.add_child(cw)
	var lv := Lever.new()
	lv.position = base + top_dir * 3.5 + Vector3(0, height, 0)
	isl.add_child(lv)
	while isl._alive() and not lv.on:
		await isl.get_tree().create_timer(0.3).timeout
		if isl.player.state == Fighter.S.DEAD:
			return false
	return isl._alive()

## Walk up to every listed companion once (talk goal). Marks goal_index when all were visited.
func visit_party(ids: Array, goal_index: int) -> bool:
	var seen: Array = []
	while isl._alive() and seen.size() < ids.size():
		await isl.get_tree().create_timer(0.3).timeout
		if isl.player.state == Fighter.S.DEAD:
			return false
		for id in ids:
			if seen.has(id):
				continue
			var c: Companion = isl.comp_by_id(str(id))
			if c != null and c.global_position.distance_to(isl.player.global_position) < 2.8:
				seen.append(id)
	goal_done(goal_index)
	return isl._alive()

## Pause/resume every enemy (used around a blocking cutscene that happens in the middle of a fight).
func freeze_foes(on: bool) -> void:
	for n in isl.get_tree().get_nodes_in_group("enemies"):
		n.process_mode = Node.PROCESS_MODE_DISABLED if on else Node.PROCESS_MODE_INHERIT

# ============================================================ v8 activities ===
## Jadeblade piece of this chapter (earned by an achievement / hidden finds, never by repeating a fight).
func jade(n: int, en: String, ar: String) -> void:
	if GameState.award_jade(n):
		Sfx.play("win")
		isl.hud.toast(L("Jadeblade piece found: ", "عثرت على قطعة Jadeblade: ") + L(en, ar) + " (%d/10)" % GameState.jade_count())

## Build trap hazards + Chen's buttons. specs = [{"k": "flame"|"wind"|"slab", "p": Vector3, "r": radius, "dir": Vector3 (wind)}],
## btns = [{"p": Vector3, "t": [spec indexes]}]. Returns {"hazards": [...], "buttons": [...]} (free with hazards_free).
func hazard_field(specs: Array, btns: Array) -> Dictionary:
	var hz: Array = []
	for sp in specs:
		var h := Hazard.new()
		h.kind = str(sp["k"])
		h.radius = float(sp.get("r", 3.0))
		h.wind_dir = sp.get("dir", Vector3(1, 0, 0))
		h.position = sp["p"] as Vector3
		isl.add_child(h)
		hz.append(h)
	var bs: Array = []
	for bd in btns:
		var b := HazardButton.new()
		b.prompt = ["Press Chen's button (traps)", "اضغط زر تشِن (فخاخ)"]
		for i in bd["t"]:
			b.hazards.append(hz[int(i)])
		b.position = bd["p"] as Vector3
		isl.add_child(b)
		bs.append(b)
	return {"hazards": hz, "buttons": bs}

func hazards_free(info: Dictionary) -> void:
	for h in info.get("hazards", []):
		if is_instance_valid(h):
			h.queue_free()
	for b in info.get("buttons", []):
		if is_instance_valid(b):
			b.queue_free()

func trap_hits() -> int:
	return int(GameState.stats.get("trap_hits", 0))

## Named duel with arena traps (Chen's buttons). Goal marks: returns false only when the player dies.
## trap_goal(i) is called (once) when a trap has hit the opponent, so the goals list can show "use the traps".
func trap_duel(boss_id: String, pos: Vector3, specs: Array, btns: Array, obj_en: String, obj_ar: String, stop_at := 0.0, goal_trap := -1) -> bool:
	var info := hazard_field(specs, btns)
	var base := trap_hits()
	var marked := false
	var b: Boss = isl.spawn_boss(boss_id, pos)
	await isl.hud.banner(b.display_name, 1.4)
	isl.hud.set_objective(L(obj_en, obj_ar))
	isl.hud.toast(L("Chen's buttons are live: lure the opponent into the traps!", "أزرار تشِن تعمل: استدرج الخصم إلى الفخاخ!"))
	while true:
		await isl.get_tree().create_timer(0.2).timeout
		if not ok_alive():
			hazards_free(info)
			return false
		if goal_trap >= 0 and not marked and trap_hits() > base:
			marked = true
			goal_done(goal_trap)
		if not is_instance_valid(b) or b.state == Fighter.S.DEAD:
			break
		if stop_at > 0.0 and b.health / b.max_health <= stop_at:
			break
	isl.clear_enemies()
	hazards_free(info)
	return isl._alive()

## Tiny escort: a small Minifig `py` walks the route. It advances only while no enemy is within 6 m and you are
## within 9 m. Enemies touching it drain its health; at 0 it is carried back to the last waypoint (soft fail, no restart).
func escort(py: Minifig, pts: Array, kind: String, label_en: String, label_ar: String, hp_max := 100.0) -> bool:
	var hp := hp_max
	var idx := 0
	var last := py.position
	var spawn_t := 4.0
	while idx < pts.size():
		await isl.get_tree().create_timer(0.1).timeout
		if not ok_alive():
			return false
		var near := 0
		var touching := 0
		var alive := 0
		for n in isl.get_tree().get_nodes_in_group("enemies"):
			var f := n as Fighter
			if f == null or f.state == Fighter.S.DEAD:
				continue
			alive += 1
			var d := Vector2(f.global_position.x - py.global_position.x, f.global_position.z - py.global_position.z).length()
			if d < 6.0:
				near += 1
			if d < 2.4:
				touching += 1
		hp -= float(touching) * 9.0 * 0.1
		var tgt: Vector3 = pts[idx]
		var pd := Vector2(isl.player.global_position.x - py.global_position.x, isl.player.global_position.z - py.global_position.z).length()
		var moving := false
		if near == 0 and pd < 9.0:
			var dir := Vector3(tgt.x - py.position.x, 0.0, tgt.z - py.position.z)
			if dir.length() > 0.8:
				py.position += dir.normalized() * 2.4 * 0.1
				py.rotation.y = atan2(-dir.x, -dir.z)
				moving = true
			else:
				last = py.position
				idx += 1
				Sfx.play("coin")
				if idx < pts.size():
					checkpoint()
		py.update_anim(0.1, 0.8 if moving else 0.0, false)
		spawn_t -= 0.1
		if spawn_t <= 0.0 and alive < 3:
			spawn_t = 6.0
			var a := randf() * TAU
			isl.spawn_enemy(kind, py.global_position + Vector3(cos(a) * 9.0, 0.3, sin(a) * 9.0))
		isl.hud.set_objective(L(label_en, label_ar) + " | " + L("Pythor", "بايثور") + " %d%%  %d/%d" % [maxi(0, int(100.0 * hp / hp_max)), mini(idx + 1, pts.size()), pts.size()])
		if hp <= 0.0:
			await isl.hud.banner(L("Pythor is hurt! Back to the last waypoint.", "بايثور أُصيب! العودة لآخر نقطة."), 1.2)
			isl.clear_enemies()
			py.position = last
			hp = hp_max
	return true

## Prison riot: followers are already inside; every `gap` seconds a cell bursts open and its inmates (team "prisoner")
## fight the followers AND you. Done when every cell is open and nothing is left alive.
func prison_riot(cells: Array, followers: Array, gap: float, label_en: String, label_ar: String) -> bool:
	var foes: Array = []
	for i in followers.size():
		foes.append(isl.spawn_enemy(str(followers[i]), ring_pos(cells[0] as Vector3, 5.0, i, followers.size())))
	var opened := 0
	var t := 3.0
	isl.hud.set_objective(L(label_en, label_ar))
	while true:
		await isl.get_tree().create_timer(0.25).timeout
		if not ok_alive():
			return false
		t -= 0.25
		if opened < cells.size() and t <= 0.0:
			t = gap
			var cp: Vector3 = cells[opened]
			opened += 1
			await isl.hud.banner(L("A cell bursts open! (%d/%d)", "تنفتح زنزانة! (%d/%d)") % [opened, cells.size()], 0.9)
			Sfx.play("impact")
			for k in 2:
				var e: Enemy = isl.spawn_enemy("brute" if k == 0 else "grunt", cp + Vector3(k * 1.2 - 0.6, 0.3, 0))
				e.team = "prisoner"
				foes.append(e)
		var left := 0
		for f in foes:
			if is_instance_valid(f) and (f as Fighter).state != Fighter.S.DEAD:
				left += 1
		if opened >= cells.size() and left == 0:
			break
	return isl._alive()

## Hold a ritual circle: progress only grows while the player stands inside it; enemies keep coming. The spell
## (Garmadon, ch. 10) needs `secs` seconds of progress. Dying/leaving only costs progress, never the stage.
func ritual(center: Vector3, r: float, secs: float, kind: String, label_en: String, label_ar: String) -> bool:
	var prog := 0.0
	var spawn_t := 2.0
	var ring := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = r
	cm.bottom_radius = r
	cm.height = 0.05
	cm.radial_segments = 28
	cm.rings = 1
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.albedo_color = Color(0.7, 0.3, 1.0, 0.35)
	cm.material = m
	ring.mesh = cm
	ring.position = center + Vector3(0, 0.15, 0)
	isl.add_child(ring)
	while prog < secs:
		await isl.get_tree().create_timer(0.1).timeout
		if not ok_alive():
			ring.queue_free()
			return false
		var inside := dist(center) <= r
		prog = clampf(prog + (0.1 if inside else -0.12), 0.0, secs)
		m.albedo_color = Color(0.7, 0.3, 1.0, 0.25 + 0.5 * prog / secs) if inside else Color(1.0, 0.3, 0.3, 0.3)
		spawn_t -= 0.1
		if spawn_t <= 0.0:
			var alive := 0
			for n in isl.get_tree().get_nodes_in_group("enemies"):
				if (n as Fighter) != null and (n as Fighter).state != Fighter.S.DEAD:
					alive += 1
			if alive < 4:
				isl.spawn_enemy(kind, ring_pos(center, r + 5.0, randi() % 8, 8))
			spawn_t = 3.2
		isl.hud.set_objective(L(label_en, label_ar) + " %d%%" % int(100.0 * prog / secs) + ("" if inside else L("  (stand in the circle!)", "  (قف داخل الدائرة!)")))
	ring.queue_free()
	isl.clear_enemies()
	return true

## Jadeblade piece when every listed flag is set (hidden finds). Returns true when this call awarded it.
func jade_if(n: int, flag_ids: Array, en: String, ar: String) -> void:
	for f in flag_ids:
		if not flag_set(str(f)):
			return
	jade(n, en, ar)

# ------------------------------------------------------------ v9 modes ---
## Skate / vehicle / dragon rail run (see RailRun). Returns true when the finish line is reached.
## opts: speed, width, rival_speed, armor, tricks (rival path distances), obstacles [{s, off, k: slab|boost|rock, y}].
func rail_run(kind: String, pts: Array, opts: Dictionary, label_en: String, label_ar: String, rival: Node3D = null) -> bool:
	var rr := RailRun.new()
	isl.add_child(rr)
	rr.setup(kind, pts, isl.player, opts, rival)
	rr.status.connect(func(t: String) -> void: isl.hud.set_objective(L(label_en, label_ar) + "  " + t))
	rr.banner.connect(func(t: String) -> void: isl.hud.banner(t, 1.2))
	rr.start()
	await rr.finished
	if not isl._alive():
		return false
	var endp: Vector3 = pts[pts.size() - 1]
	await isl.teleport_party(endp)
	return isl._alive()

## A conveyor belt that pushes fighters along `dir`. Free it with queue_free() when the stage is over.
func conveyor(pos: Vector3, size: Vector3, dir: Vector3, speed: float) -> Conveyor:
	var c := Conveyor.new()
	c.size = size
	c.dir = dir
	c.speed = speed
	c.position = pos
	isl.add_child(c)
	return c

## Disguised stealth (ch. 5): like stealth(), but a watch-zone only drains the disguise meter. When the meter is empty
## the disguise is blown and you go back to the last checkpoint. The meter refills outside the zones.
func disguise_run(pts: Array, watchers: Array, start: Vector3, label_en: String, label_ar: String, secs := 5.0) -> bool:
	var discs: Array = []
	for w in watchers:
		var mi := MeshInstance3D.new()
		var cm := CylinderMesh.new()
		cm.top_radius = float(w["r"])
		cm.bottom_radius = float(w["r"])
		cm.height = 0.06
		cm.radial_segments = 20
		cm.rings = 1
		var m := StandardMaterial3D.new()
		m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		m.albedo_color = Color(1.0, 0.6, 0.1, 0.35)
		cm.material = m
		mi.mesh = cm
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		isl.add_child(mi)
		discs.append(mi)
	var beacons: Array = []
	for p in pts:
		var bc: MeshInstance3D = isl.make_beacon(p, Color(0.8, 0.5, 1.0))
		bc.visible = false
		beacons.append(bc)
	beacons[0].visible = true
	var idx := 0
	var t := 0.0
	var last := start
	var meter := secs
	while idx < pts.size():
		await isl.get_tree().create_timer(0.1).timeout
		if not ok_alive():
			return false
		t += 0.1
		var near := false
		for i in watchers.size():
			var w: Dictionary = watchers[i]
			var c: Vector3 = w["c"]
			var off: Vector3 = w["amp"]
			var wp := c + off * sin(t * float(w["speed"]))
			(discs[i] as MeshInstance3D).position = wp + Vector3(0, 0.15, 0)
			var px: float = isl.player.global_position.x
			var pz: float = isl.player.global_position.z
			if Vector2(px - wp.x, pz - wp.z).length() < float(w["r"]):
				near = true
		if near:
			meter -= 0.1
		else:
			meter = minf(secs, meter + 0.05)
		if meter <= 0.0:
			await isl.hud.banner(L("Your disguise slipped! Back to the last checkpoint.", "سقط تنكرك! العودة لآخر نقطة."), 1.0)
			await isl.teleport_party(last)
			meter = secs
			continue
		if dist(pts[idx]) < 2.8:
			beacons[idx].visible = false
			last = pts[idx]
			idx += 1
			Sfx.play("coin")
			if idx < pts.size():
				beacons[idx].visible = true
		var bars := int(ceil(meter / secs * 6.0))
		var txt := L(label_en, label_ar) + " %d/%d" % [mini(idx + 1, pts.size()), pts.size()]
		txt += "  [" + "#".repeat(bars) + "-".repeat(6 - bars) + "]"
		isl.hud.set_objective(txt)
	for d in discs:
		d.queue_free()
	for bc in beacons:
		bc.queue_free()
	return true

## Deduction puzzle (ch. 5): after the clues are read, USE the stone beside the suspect you think is the spy.
## suspects = [{"cfg": figure config, "pos": Vector3, "name": [en, ar], "yaw": float}]. A wrong pick only costs a retry.
func deduce(suspects: Array, answer: int, label_en: String, label_ar: String) -> bool:
	var figs: Array = []
	var stones: Array = []
	for i in suspects.size():
		var sp: Dictionary = suspects[i]
		var pos: Vector3 = sp["pos"]
		figs.append(spawn_fig(sp["cfg"] as Dictionary, pos, float(sp.get("yaw", 0.0))))
		var nm_pair: Array = sp["name"]
		stones.append(place_stone(pos + Vector3(2.2, 0, 0), Color(1.0, 0.85, 0.3), "Accuse " + str(nm_pair[0]), "اتهم " + str(nm_pair[1])))
	isl.hud.set_objective(L(label_en, label_ar))
	var found := false
	while not found:
		await isl.get_tree().create_timer(0.3).timeout
		if not isl._alive():
			break
		if isl.player.state == Fighter.S.DEAD:
			break
		for i in stones.size():
			var st: StoryStone = stones[i]
			if not st.done:
				continue
			if i == answer:
				found = true
				break
			var sp2: Dictionary = suspects[i]
			var nm2: Array = sp2["name"]
			var pos2: Vector3 = sp2["pos"]
			st.queue_free()
			stones[i] = place_stone(pos2 + Vector3(2.2, 0, 0), Color(1.0, 0.85, 0.3), "Accuse " + str(nm2[0]), "اتهم " + str(nm2[1]))
			await isl.hud.banner(L("Not them. Look at the clues again.", "ليس هو. انظر إلى الأدلة مرة أخرى."), 1.4)
	for st3 in stones:
		if is_instance_valid(st3):
			(st3 as Node).queue_free()
	for f in figs:
		drop_fig(f as Minifig)
	return isl._alive()

## Weaving path between two points for rail runs: n+1 points, sideways swing `amp` fading out at both ends.
func snake(a: Vector3, b: Vector3, n: int, amp: float) -> Array:
	var out: Array = []
	var fwd := b - a
	fwd.y = 0.0
	var right := fwd.normalized().cross(Vector3.UP).normalized()
	for i in range(0, n + 1):
		var t := float(i) / float(n)
		var p := a.lerp(b, t) + right * sin(float(i) * 1.1) * amp * sin(t * PI)
		p.y = a.y
		out.append(p)
	out[n] = b
	return out

## Visual dressing for the Kryptarium (ch. 9): a dark yard slab and rows of cell bars around `center` (no collision).
func dress_prison(center: Vector3) -> void:
	if not isl.get_tree().get_nodes_in_group("prison_dress").is_empty():
		return
	var root := Node3D.new()
	root.position = center
	root.add_to_group("prison_dress")
	isl.add_child(root)
	var slab := MeshInstance3D.new()
	var sb := BoxMesh.new()
	sb.size = Vector3(30, 0.1, 26)
	slab.mesh = sb
	var sm := StandardMaterial3D.new()
	sm.albedo_color = Color(0.16, 0.16, 0.19)
	slab.material_override = sm
	slab.position = Vector3(0, 0.05, 0)
	root.add_child(slab)
	var bar_m := StandardMaterial3D.new()
	bar_m.albedo_color = Color(0.3, 0.32, 0.38)
	for row in [-1.0, 1.0]:
		for i in range(-6, 7):
			var bar := MeshInstance3D.new()
			var bb := BoxMesh.new()
			bb.size = Vector3(0.14, 3.4, 0.14)
			bar.mesh = bb
			bar.material_override = bar_m
			bar.position = Vector3(float(i) * 1.1, 1.7, float(row) * 9.0)
			root.add_child(bar)
		var rail := MeshInstance3D.new()
		var rb := BoxMesh.new()
		rb.size = Vector3(14.0, 0.18, 0.18)
		rail.mesh = rb
		rail.material_override = bar_m
		rail.position = Vector3(0, 3.4, float(row) * 9.0)
		root.add_child(rail)

func undress_prison() -> void:
	for n in isl.get_tree().get_nodes_in_group("prison_dress"):
		(n as Node).queue_free()
