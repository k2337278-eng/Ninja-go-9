class_name DefensePoint
extends Node3D
## One defense point of the Corridor of Elders (ch. 10). An ally group stationed here supports the fight:
##  "citizens"   - rebuild the barricade (the point heals), "serpentine" - venom: slows and hurts nearby enemies,
##  "masters"    - elemental volley: damages the nearest enemy. Enemies touching the point wear its integrity down.
## Empty points still wear down, so the player must help where nobody is stationed. VERIFY: the real battle is not
## described in the spec in this detail (gameplay stand-in).

var kind := ""
var max_hp := 160.0
var hp := 160.0
var radius := 6.5
var label_en := "Point"
var label_ar := "نقطة"
var _t := 0.0
var _lbl: Label3D
var _ring: MeshInstance3D

func _ready() -> void:
	_lbl = Label3D.new()
	_lbl.position = Vector3(0, 3.2, 0)
	_lbl.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	_lbl.font_size = 48
	_lbl.no_depth_test = true
	add_child(_lbl)
	_ring = MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 1.2
	cm.bottom_radius = 1.2
	cm.height = 2.4
	cm.radial_segments = 10
	cm.rings = 1
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(0.9, 0.8, 0.3, 0.35)
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	cm.material = m
	_ring.mesh = cm
	_ring.position.y = 1.2
	_ring.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(_ring)
	_refresh()

func kind_name(k: String) -> String:
	match k:
		"citizens":
			return Loc.pick(["Citizens", "المواطنون"])
		"serpentine":
			return Loc.pick(["Serpentine", "السيربنتين"])
		"masters":
			return Loc.pick(["Masters", "الماسترز"])
	return Loc.pick(["Nobody", "لا أحد"])

func _refresh() -> void:
	if _lbl != null:
		_lbl.text = "%s: %s  %d%%" % [Loc.pick([label_en, label_ar]), kind_name(kind), int(100.0 * hp / max_hp)]

func reset_hp() -> void:
	hp = max_hp
	_refresh()

func _process(delta: float) -> void:
	_t -= delta
	var near: Array = []
	var touching := 0
	for n in get_tree().get_nodes_in_group("enemies"):
		var f := n as Fighter
		if f == null or f.state == Fighter.S.DEAD or n.is_in_group("practice"):
			continue
		var d := Vector2(f.global_position.x - global_position.x, f.global_position.z - global_position.z).length()
		if d <= radius:
			near.append(f)
		if d <= 3.2:
			touching += 1
	hp = maxf(0.0, hp - float(touching) * 7.0 * delta)
	if _t <= 0.0:
		_t = 1.2
		match kind:
			"citizens":
				hp = minf(max_hp, hp + 10.0)
			"serpentine":
				for f in near:
					(f as Fighter).statuses["slow"] = 1.6
					(f as Fighter).take_damage(4.0, self, 0.0, 0.0, true)
			"masters":
				if not near.is_empty():
					var tgt: Fighter = near[0]
					tgt.take_damage(14.0, self, 3.0, 0.0, true)
					Effects.burst(tgt, tgt.global_position + Vector3(0, 1.0, 0), Color(1.0, 0.7, 0.3), 12, 5.0)
		_refresh()
