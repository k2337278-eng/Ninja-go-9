class_name PowerVessel
extends Interactable
## Holds a stolen power. USE with Skylor nearby to draw it back (story restore quests).

signal used

var active := false
var done := false
var restore_id := ""
var crystal_mat: StandardMaterial3D

func _ready() -> void:
	super()
	radius = 4.0
	prompt = ["Draw back the stolen power", "اسحب القوة المسلوبة"]
	var base := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.5
	cm.bottom_radius = 0.7
	cm.height = 0.5
	cm.radial_segments = 8
	cm.rings = 1
	var bmat := StandardMaterial3D.new()
	bmat.albedo_color = Color(0.3, 0.3, 0.35)
	cm.material = bmat
	base.mesh = cm
	base.position.y = 0.25
	add_child(base)
	var crystal := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.5
	sm.height = 1.0
	sm.radial_segments = 4
	sm.rings = 2
	crystal_mat = StandardMaterial3D.new()
	crystal_mat.albedo_color = Color(0.5, 0.2, 0.7)
	crystal_mat.emission_enabled = true
	crystal_mat.emission = Color(0.5, 0.2, 0.7)
	sm.material = crystal_mat
	crystal.mesh = sm
	crystal.position.y = 1.3
	add_child(crystal)
	set_active(false)

func set_active(v: bool) -> void:
	active = v
	visible = v

func can_use(_p: Player) -> bool:
	return active and not done

func use(p: Player) -> void:
	var sky: Fighter = null
	for n in get_tree().get_nodes_in_group("fighters"):
		var f := n as Fighter
		if f != null and f.char_id == "skylor" and not f.downed and f.global_position.distance_to(global_position) < 14.0:
			sky = f
	if sky == null:
		p.feedback.emit(Loc.pick(["Skylor must be nearby to absorb the stolen power.", "يجب أن تكون سكايلور قريبة لامتصاص القوة المسلوبة."]))
		return
	done = true
	crystal_mat.albedo_color = Color(1.0, 0.8, 0.2)
	crystal_mat.emission = Color(1.0, 0.8, 0.2)
	Effects.ring(self, global_position, 5.0, Color(1.0, 0.8, 0.2))
	Effects.burst(self, global_position + Vector3(0, 1.3, 0), Color(1.0, 0.8, 0.2), 40, 8.0)
	Sfx.play("energy", 1.2)
	used.emit()
