class_name Npc
extends Interactable
## Island resident. Lines depend on story progress: phases = [{"until": chapter number, "lines": [[en, ar], ...]}].

var isl: Node
var speaker: Array = ["Villager", "قروي"]
var phases: Array = []
var cfg: Dictionary = {}
var rig: Minifig

func _ready() -> void:
	super()
	radius = 2.8
	prompt = ["Talk", "تحدث"]
	rig = Minifig.new()
	add_child(rig)
	rig.build(cfg)
	var sb := StaticBody3D.new()
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.35
	cap.height = 1.6
	cs.shape = cap
	cs.position.y = 0.8
	sb.add_child(cs)
	add_child(sb)

func _process(delta: float) -> void:
	rig.update_anim(delta, 0.0, false)
	if isl != null and isl.player != null:
		var d: Vector3 = isl.player.global_position - global_position
		d.y = 0.0
		if d.length() < 7.0 and d.length() > 0.1:
			rig.rotation.y = lerp_angle(rig.rotation.y, atan2(-d.x, -d.z), 1.0 - exp(-6.0 * delta))

func use(_p: Player) -> void:
	var step := Chapters.chapter_of_step(GameState.story_step)
	var chosen: Array = []
	for ph in phases:
		if step <= int(ph["until"]):
			chosen = ph["lines"]
			break
	if chosen.is_empty() and not phases.is_empty():
		chosen = phases[phases.size() - 1]["lines"]
	var out: Array = []
	for l in chosen:
		out.append([Loc.pick(speaker), Loc.pick(l)])
	if isl != null and not out.is_empty():
		await isl.talk(out)
