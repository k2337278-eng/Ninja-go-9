class_name HazardButton
extends Interactable
## "Chen's button": USE to fire the linked Hazards. Re-arms after `cooldown` seconds. Set `hazards` BEFORE add_child().

signal pressed

var hazards: Array = []
var cooldown := 9.0
var duration := 3.0
var _left := 0.0
var _mat: StandardMaterial3D

func _ready() -> void:
	super()
	radius = 2.6
	var base := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.6
	cm.bottom_radius = 0.75
	cm.height = 0.35
	cm.radial_segments = 10
	cm.rings = 1
	base.mesh = cm
	base.position.y = 0.18
	add_child(base)
	var mi := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.42
	sm.height = 0.6
	sm.radial_segments = 10
	sm.rings = 4
	_mat = StandardMaterial3D.new()
	_mat.emission_enabled = true
	sm.material = _mat
	mi.mesh = sm
	mi.position.y = 0.5
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mi)
	_paint()

func _paint() -> void:
	var c := Color(0.9, 0.15, 0.15) if _left <= 0.0 else Color(0.35, 0.1, 0.1)
	_mat.albedo_color = c
	_mat.emission = c if _left <= 0.0 else Color(0.1, 0.0, 0.0)

func can_use(_p: Player) -> bool:
	return _left <= 0.0

func use(_p: Player) -> void:
	if _left > 0.0:
		return
	_left = cooldown
	Sfx.play("ui")
	GameState.stat("button_presses")
	for h in hazards:
		if is_instance_valid(h):
			(h as Hazard).fire(duration)
	pressed.emit()
	_paint()

func _process(delta: float) -> void:
	if _left > 0.0:
		_left -= delta
		if _left <= 0.0:
			_paint()
