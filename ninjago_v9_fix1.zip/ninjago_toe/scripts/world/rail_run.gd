class_name RailRun
extends Node3D
## Rail mode (v9): the Thunderblade skate race, the vehicle rescue run and the dragon flight.
## The player's body is moved along a path of waypoints. Stick = steer sideways (and up/down when flying).
## JMP = jump (skate/vehicle), DGE = boost, ATK = fire breath (dragon). Crashing or losing never ends the stage:
## you restart from the last checkpoint. Created by ChapterBase.rail_run(); emits `finished` when the end is reached.

signal status(text: String)
signal banner(text: String)
signal finished

const STEER := {"skate": 9.0, "vehicle": 6.5, "dragon": 9.0}

var kind := "skate"
var pts: Array = []
var cum: Array = []
var total := 0.0
var player: Player
var rival: Node3D
var s := 0.0
var off := 0.0
var h := 0.0
var vh := 0.0
var speed := 0.0
var base_speed := 12.0
var width := 5.0
var boost_t := 0.0
var boost_cd := 0.0
var hit_t := 0.0
var breath_cd := 0.0
var armor := 3
var max_armor := 3
var obstacles: Array = []
var rival_s := 0.0
var rival_speed := 10.5
var tricks: Array = []
var running := false
var jump_req := false
var breath_req := false
var ckpt_s := 0.0
var fails := 0
var hits := 0
var ui_t := 0.0
var deck: Node3D
var guide: Array = []

func setup(kind_: String, pts_: Array, pl: Player, opts: Dictionary, rival_node: Node3D = null) -> void:
	kind = kind_
	pts = pts_
	player = pl
	rival = rival_node
	base_speed = float(opts.get("speed", 12.0))
	width = float(opts.get("width", 5.0))
	rival_speed = float(opts.get("rival_speed", base_speed * 0.9))
	max_armor = int(opts.get("armor", 3))
	armor = max_armor
	var tr: Array = opts.get("tricks", [])
	tricks = tr.duplicate()
	cum = [0.0]
	for i in range(1, pts.size()):
		var a: Vector3 = pts[i - 1]
		var b: Vector3 = pts[i]
		cum.append(float(cum[i - 1]) + a.distance_to(b))
	total = float(cum[cum.size() - 1])
	var obs: Array = opts.get("obstacles", [])
	for o in obs:
		_add_obstacle(o as Dictionary)
	_build_guide()

func start() -> void:
	player.input_locked = true
	if player.controls != null:
		player.controls.action_pressed.connect(_on_action)
	_build_deck()
	s = 0.0
	off = 0.0
	h = 0.0
	ckpt_s = 0.0
	running = true
	_snap(0.016)

# ------------------------------------------------------------------ path ---
func _seg(sd: float) -> int:
	var i := 0
	while i < pts.size() - 2 and sd > float(cum[i + 1]):
		i += 1
	return i

func point_at(sd: float) -> Vector3:
	var d := clampf(sd, 0.0, total)
	var i := _seg(d)
	var a: Vector3 = pts[i]
	var b: Vector3 = pts[i + 1]
	var sl := float(cum[i + 1]) - float(cum[i])
	var t := 0.0
	if sl > 0.001:
		t = (d - float(cum[i])) / sl
	return a.lerp(b, t)

func dir_at(sd: float) -> Vector3:
	var i := _seg(clampf(sd, 0.0, total))
	var a: Vector3 = pts[i]
	var b: Vector3 = pts[i + 1]
	var dv := b - a
	dv.y = 0.0
	if dv.length() < 0.001:
		return Vector3(0, 0, -1)
	return dv.normalized()

func right_at(sd: float) -> Vector3:
	return dir_at(sd).cross(Vector3.UP).normalized()

# --------------------------------------------------------------- visuals ---
func _box(parent: Node3D, size: Vector3, pos: Vector3, col: Color, unshaded := false) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	var m := StandardMaterial3D.new()
	m.albedo_color = col
	if unshaded:
		m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mi.material_override = m
	mi.position = pos
	parent.add_child(mi)
	return mi

func _build_deck() -> void:
	deck = Node3D.new()
	add_child(deck)
	match kind:
		"skate":
			_box(deck, Vector3(0.9, 0.12, 1.5), Vector3(0, 0.12, 0), Color(0.12, 0.12, 0.18))
			for sx in [-0.4, 0.4]:
				for sz in [-0.5, 0.5]:
					_box(deck, Vector3(0.16, 0.2, 0.2), Vector3(sx, 0.06, sz), Color(0.95, 0.85, 0.2))
		"vehicle":
			_box(deck, Vector3(1.8, 0.5, 3.2), Vector3(0, 0.35, 0), Color(0.85, 0.3, 0.15))
			_box(deck, Vector3(1.3, 0.5, 1.2), Vector3(0, 0.85, -0.3), Color(0.25, 0.28, 0.35))
			for sx in [-1.0, 1.0]:
				for sz in [-1.0, 1.0]:
					_box(deck, Vector3(0.3, 0.6, 0.6), Vector3(sx, 0.3, sz), Color(0.08, 0.08, 0.08))
		_:
			_box(deck, Vector3(1.1, 0.7, 4.2), Vector3(0, -0.3, 0), Color(0.55, 0.6, 0.65))
			_box(deck, Vector3(0.8, 0.6, 1.2), Vector3(0, 0.0, 2.6), Color(0.62, 0.66, 0.72))
			_box(deck, Vector3(5.2, 0.12, 1.6), Vector3(0, -0.2, 0.2), Color(0.45, 0.5, 0.58))
			_box(deck, Vector3(0.4, 0.4, 2.2), Vector3(0, -0.2, -2.9), Color(0.5, 0.55, 0.6))

func _build_guide() -> void:
	var n := int(total / 8.0)
	for i in range(0, n + 1):
		var sd := float(i) * 8.0
		var p := point_at(sd)
		var r := right_at(sd)
		var col := Color(1.0, 1.0, 1.0) if i % 2 == 0 else Color(1.0, 0.6, 0.2)
		for sgn in [-1.0, 1.0]:
			var q: Vector3 = p + r * (width + 1.2) * sgn
			var mi := _box(self, Vector3(0.25, 0.25, 0.25), Vector3.ZERO, col, true)
			mi.position = Vector3(q.x, 0.15, q.z)
			guide.append(mi)
	var endp := point_at(total)
	var endr := right_at(total)
	for sgn in [-1.0, 1.0]:
		var q2: Vector3 = endp + endr * (width + 1.5) * sgn
		var post := _box(self, Vector3(0.5, 6.0, 0.5), Vector3.ZERO, Color(1.0, 0.85, 0.2), true)
		post.position = Vector3(q2.x, 3.0, q2.z)
		guide.append(post)

func _add_obstacle(o: Dictionary) -> void:
	var k := str(o.get("k", "slab"))
	var node := MeshInstance3D.new()
	var m := StandardMaterial3D.new()
	match k:
		"boost":
			var bm := BoxMesh.new()
			bm.size = Vector3(2.4, 0.08, 2.4)
			node.mesh = bm
			m.albedo_color = Color(0.3, 0.95, 1.0)
			m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		"rock":
			var sm := SphereMesh.new()
			sm.radius = 1.6
			sm.height = 3.2
			sm.radial_segments = 8
			sm.rings = 4
			node.mesh = sm
			m.albedo_color = Color(0.45, 0.43, 0.42)
		_:
			var bx := BoxMesh.new()
			bx.size = Vector3(2.2, 0.9, 0.7)
			node.mesh = bx
			m.albedo_color = Color(0.9, 0.2, 0.15)
	node.material_override = m
	add_child(node)
	var d := {"s": float(o["s"]), "off": float(o.get("off", 0.0)), "k": k, "y": float(o.get("y", 4.0)), "node": node, "alive": true}
	obstacles.append(d)
	var y := 0.45
	if k == "boost":
		y = 0.06
	elif k == "rock":
		y = float(d["y"])
	var p := point_at(float(d["s"])) + right_at(float(d["s"])) * float(d["off"])
	node.position = Vector3(p.x, y, p.z)

func _kill_obstacle(od: Dictionary) -> void:
	od["alive"] = false
	var node: MeshInstance3D = od["node"]
	node.visible = false

# ----------------------------------------------------------------- input ---
func _on_action(a: String) -> void:
	match a:
		"jump":
			jump_req = true
		"dodge":
			if boost_cd <= 0.0:
				boost_t = 1.3
				boost_cd = 3.0
				Sfx.play("whoosh")
		"light":
			breath_req = true

# ------------------------------------------------------------------ loop ---
func _physics_process(delta: float) -> void:
	if not running or not is_instance_valid(player):
		return
	var mv := Vector2.ZERO
	if player.controls != null:
		mv = player.controls.move_vector
	mv.x += float(Input.is_key_pressed(KEY_D)) - float(Input.is_key_pressed(KEY_A))
	mv.y += float(Input.is_key_pressed(KEY_S)) - float(Input.is_key_pressed(KEY_W))
	mv = mv.limit_length(1.0)
	boost_t = maxf(0.0, boost_t - delta)
	boost_cd = maxf(0.0, boost_cd - delta)
	hit_t = maxf(0.0, hit_t - delta)
	breath_cd = maxf(0.0, breath_cd - delta)
	off = clampf(off + mv.x * float(STEER[kind]) * delta, -width, width)
	var target := base_speed
	if boost_t > 0.0:
		target *= 1.55
	if hit_t > 0.0:
		target *= 0.45
	speed = lerpf(speed, target, 1.0 - exp(-4.0 * delta))
	s += speed * delta
	if kind == "dragon":
		h = clampf(h - mv.y * 7.0 * delta, 0.6, 9.0)
	else:
		if jump_req and h <= 0.02:
			vh = 8.0
			Sfx.play("whoosh")
		vh -= 24.0 * delta
		h += vh * delta
		if h < 0.0:
			h = 0.0
			vh = 0.0
	jump_req = false
	if breath_req and kind == "dragon" and breath_cd <= 0.0:
		breath_cd = 1.2
		Sfx.play("elem")
		Effects.burst(self, player.global_position, Color(1.0, 0.5, 0.15), 24, 8.0)
		for o in obstacles:
			var ob: Dictionary = o
			if bool(ob["alive"]) and float(ob["s"]) > s and float(ob["s"]) < s + 16.0 and absf(float(ob["off"]) - off) < 4.5:
				_kill_obstacle(ob)
	breath_req = false
	for o in obstacles:
		var od: Dictionary = o
		if not bool(od["alive"]):
			continue
		if absf(float(od["s"]) - s) > 1.3:
			continue
		var dl := absf(float(od["off"]) - off)
		var ok := str(od["k"])
		if ok == "boost":
			if dl < 1.5:
				boost_t = 1.5
				Sfx.play("whoosh")
				_kill_obstacle(od)
			continue
		if dl > 1.5:
			continue
		var clear := false
		if kind == "dragon":
			clear = absf(h - float(od["y"])) > 2.4
		else:
			clear = h > 1.0
		if clear:
			continue
		_hit(od)
	_update_rival(delta)
	if s >= ckpt_s + total * 0.25 and ckpt_s + total * 0.25 < total - 6.0:
		ckpt_s += total * 0.25
		Sfx.play("coin")
		banner.emit(_t("Checkpoint!", "نقطة حفظ!"))
	_snap(delta)
	ui_t -= delta
	if ui_t <= 0.0:
		ui_t = 0.2
		var txt := "%d%%" % int(clampf(s / maxf(total, 1.0), 0.0, 1.0) * 100.0)
		if kind == "vehicle":
			txt += "  " + _t("Armor", "الدرع") + " %d" % armor
		if boost_cd > 0.0:
			txt += "  " + _t("Boost", "تسريع") + " %d" % int(ceil(boost_cd))
		status.emit(txt)
	if s >= total:
		_finish()

func _t(en: String, ar: String) -> String:
	return ar if Loc.lang == "ar" else en

func _hit(od: Dictionary) -> void:
	hits += 1
	hit_t = 1.0
	_kill_obstacle(od)
	Sfx.play("impact")
	Effects.shake(self, 0.3)
	if kind == "vehicle":
		armor -= 1
		if armor <= 0:
			_restart(_t("The vehicle is wrecked! Back to the checkpoint.", "تحطمت المركبة! العودة لنقطة الحفظ."))

func _update_rival(delta: float) -> void:
	if rival == null or not is_instance_valid(rival):
		return
	var gap := s - rival_s
	var k := clampf(1.0 + gap * 0.02, 0.8, 1.3)
	rival_s += rival_speed * k * delta
	var rp := point_at(rival_s) + right_at(rival_s) * (sin(rival_s * 0.12) * width * 0.6)
	rival.global_position = rp
	var rd := dir_at(rival_s)
	rival.rotation.y = atan2(-rd.x, -rd.z)
	if not tricks.is_empty() and rival_s >= float(tricks[0]):
		tricks.remove_at(0)
		_add_obstacle({"s": minf(s + 14.0, total - 4.0), "off": off, "k": "slab"})
		Sfx.play("thud")
	if rival_s >= total and s < total:
		_restart(_t("She was faster this time! Back to the checkpoint.", "كانت أسرع هذه المرة! العودة لنقطة الحفظ."))

func _restart(msg: String) -> void:
	fails += 1
	s = ckpt_s
	off = 0.0
	h = 0.0
	vh = 0.0
	speed = 0.0
	armor = max_armor
	hit_t = 0.0
	rival_s = maxf(0.0, ckpt_s - 6.0)
	banner.emit(msg)

func _snap(delta: float) -> void:
	var d := dir_at(s)
	var p := point_at(s) + right_at(s) * off + Vector3(0, h, 0)
	player.global_position = p
	player.velocity = Vector3.ZERO
	player.face_dir = d
	if deck != null:
		var dy := p.y - h + 0.02
		if kind == "dragon":
			dy = p.y - 0.25
		deck.global_position = Vector3(p.x, dy, p.z)
		deck.rotation.y = atan2(d.x, d.z)
	var cam := get_tree().get_first_node_in_group("camera_rig") as CameraRig
	if cam != null:
		cam.lock_target = null
		cam.yaw = lerp_angle(cam.yaw, atan2(-d.x, -d.z), 1.0 - exp(-4.0 * delta))
		var want_pitch := -0.28
		if kind == "dragon":
			want_pitch = -0.12
		cam.pitch = lerpf(cam.pitch, want_pitch, 1.0 - exp(-3.0 * delta))

func _finish() -> void:
	if not running:
		return
	running = false
	if is_instance_valid(player):
		player.input_locked = false
		if player.controls != null and player.controls.action_pressed.is_connected(_on_action):
			player.controls.action_pressed.disconnect(_on_action)
	finished.emit()
	queue_free()
