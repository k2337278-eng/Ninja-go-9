class_name Chapters
extends Node
## Story coordinator. The story follows STORY_SPEC.md (Ninjago season 4, episodes 35-44), one
## chapter per episode, each in its own file: scripts/world/chapters/ch01.gd ... ch10.gd.
## GameState.story_step is a BEAT index over all chapters (beat = one save checkpoint, see ChapterBase).
## Old (v1) numbering is gone: GameState.load_game resets story progress for v1 saves.

var isl: Node3D

static var _plan: Array = []

static func make_all() -> Array:
	return [Ch01.new(), Ch02.new(), Ch03.new(), Ch04.new(), Ch05.new(),
		Ch06.new(), Ch07.new(), Ch08.new(), Ch09.new(), Ch10.new()]

## Flat list of beat dictionaries (see ChapterBase.beat) + "ch" (chapter number) + "inst" (the chapter object).
static func plan() -> Array:
	if _plan.is_empty():
		for c in make_all():
			for b in c.beats():
				var d: Dictionary = (b as Dictionary).duplicate()
				d["ch"] = c.num
				d["inst"] = c
				_plan.append(d)
	return _plan

static func total() -> int:
	return plan().size()

static func meta_for_step(step: int) -> Dictionary:
	var p := plan()
	return p[clampi(step, 0, p.size() - 1)] as Dictionary

static func chapter_of_step(step: int) -> int:
	if step >= total():
		return 10
	return int(meta_for_step(step)["ch"])

## First beat index of every chapter (for Mission Select).
static func first_steps() -> Array:
	var out: Array = []
	var p := plan()
	var cur := 0
	for i in p.size():
		if int((p[i] as Dictionary)["ch"]) != cur:
			cur = int((p[i] as Dictionary)["ch"])
			out.append(i)
	return out

static func chapter_names() -> Array:
	var out: Array = []
	for c in make_all():
		out.append(c.title)
	return out

## Beats that need a different player / party / mood cannot share one island scene.
static func scene_key(d: Dictionary) -> String:
	var s := str(d["player"]) + "|" + str(d["mood"]) + "|"
	for id in d["party"]:
		s += str(id) + ","
	return s

func spawn_for(step: int) -> Vector3:
	return meta_for_step(step)["spawn"] as Vector3

# ------------------------------------------------------------------ driver ---
func run() -> void:
	var p := plan()
	for d in p:
		var inst: ChapterBase = d["inst"]
		inst.isl = isl
		inst.story = self
	var first: int = GameState.story_step
	for i in range(first, p.size()):
		var d: Dictionary = p[i]
		if i != first:
			await isl.teleport_party(d["spawn"] as Vector3)
		var ok = await (d["run"] as Callable).call()
		if not ok or not isl._alive():
			return
		isl._set_step(i + 1)
		if i + 1 < p.size() and scene_key(p[i + 1] as Dictionary) != scene_key(d):
			isl.reload_story()
			return
	await _free_roam()

func _free_roam() -> void:
	isl.hud.set_objective(Loc.pick(["The story is complete. Explore freely, or replay chapters from the main menu.",
		"اكتملت القصة. استكشف بحرية، أو أعد الفصول من القائمة الرئيسية."]))
