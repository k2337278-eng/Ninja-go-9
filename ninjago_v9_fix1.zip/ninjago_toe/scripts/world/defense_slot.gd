class_name DefenseSlot
extends Interactable
## USE cycles which recruited ally group guards the linked DefensePoint. Set `point` and `choices` BEFORE add_child().

var point: DefensePoint
var choices: Array = []
var idx := -1
var locked := false

func _ready() -> void:
	super()
	radius = 3.0
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.7
	cm.bottom_radius = 0.9
	cm.height = 0.3
	cm.radial_segments = 10
	cm.rings = 1
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(0.9, 0.8, 0.3)
	m.emission_enabled = true
	m.emission = Color(0.9, 0.8, 0.3)
	cm.material = m
	mi.mesh = cm
	mi.position.y = 0.15
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mi)

func can_use(_p: Player) -> bool:
	return not locked and not choices.is_empty()

func prompt_text() -> String:
	var nxt := str(choices[(idx + 1) % choices.size()]) if not choices.is_empty() else ""
	return Loc.pick(["Station: ", "عيّن: "]) + point.kind_name(nxt)

func use(_p: Player) -> void:
	if locked or choices.is_empty():
		return
	idx = (idx + 1) % choices.size()
	point.kind = str(choices[idx])
	point.reset_hp()
	Sfx.play("ui")
