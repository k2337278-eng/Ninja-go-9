class_name PressurePlate
extends Node3D
## Pressed only by crates (standing on it does not count).

signal changed(pressed: bool)

var flag_id := ""
var pressed := false
var forced := false
var disc: MeshInstance3D
var mat: StandardMaterial3D

func _ready() -> void:
	disc = MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 1.0
	cm.bottom_radius = 1.0
	cm.height = 0.1
	cm.radial_segments = 16
	cm.rings = 1
	mat = StandardMaterial3D.new()
	mat.emission_enabled = true
	cm.material = mat
	disc.mesh = cm
	disc.position.y = 0.05
	disc.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(disc)
	_visual()
	if flag_id != "" and GameState.flags.get(flag_id, false):
		forced = true
		_set_pressed(true)

func _visual() -> void:
	var c := Color(0.3, 1.0, 0.4) if pressed else Color(0.45, 0.5, 0.65)
	mat.albedo_color = c
	mat.emission = c if pressed else Color.BLACK
	disc.position.y = 0.02 if pressed else 0.05

func _physics_process(_d: float) -> void:
	if forced:
		return
	var now := false
	for c in get_tree().get_nodes_in_group("crate"):
		var d := Vector2(c.global_position.x - global_position.x, c.global_position.z - global_position.z).length()
		if d < 0.8 and c.global_position.y < 2.0:
			now = true
			break
	if now != pressed:
		_set_pressed(now)

func _set_pressed(v: bool) -> void:
	pressed = v
	_visual()
	if v:
		Sfx.play("ui")
		if flag_id != "":
			GameState.flags[flag_id] = true
	changed.emit(v)
