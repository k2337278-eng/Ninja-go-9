class_name LoreScroll
extends Interactable
## Readable scroll / tablet. counts=true -> collectible (id saved). flag_id marks story tablets.

var scroll_id := 0
var counts := true
var flag_id := ""
var title: Array = ["Old Scroll", "لفافة قديمة"]
var text: Array = ["...", "..."]
var isl: Node

func _ready() -> void:
	super()
	radius = 2.4
	prompt = ["Read", "اقرأ"]
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.12
	cm.bottom_radius = 0.12
	cm.height = 0.8
	cm.radial_segments = 8
	cm.rings = 1
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(0.95, 0.9, 0.7)
	m.emission_enabled = true
	m.emission = Color(0.9, 0.8, 0.4)
	m.emission_energy_multiplier = 0.4
	cm.material = m
	mi.mesh = cm
	mi.rotation.z = PI / 2.0
	mi.position.y = 0.5
	add_child(mi)

func use(_p: Player) -> void:
	if isl != null:
		await isl.talk([[Loc.pick(title), Loc.pick(text)]])
	if flag_id != "":
		GameState.flags[flag_id] = true
	if counts and not GameState.collected.has(scroll_id):
		GameState.collected.append(scroll_id)
		GameState.stat("scrolls")
		if isl != null:
			isl.hud.toast(Loc.pick(["Scroll collected (%d/6)", "تم جمع لفافة (%d/6)"]) % GameState.count_ids(200, 299))
			isl._check_side_quests()
