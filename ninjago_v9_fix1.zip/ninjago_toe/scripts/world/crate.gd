class_name Crate
extends RigidBody3D
## Pushable crate. Fighters push it via Fighter._move (slide collisions).

func _ready() -> void:
	add_to_group("crate")
	mass = 14.0
	linear_damp = 5.0
	angular_damp = 100.0
	axis_lock_angular_x = true
	axis_lock_angular_y = true
	axis_lock_angular_z = true
	var cs := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = Vector3(1.2, 1.2, 1.2)
	cs.shape = bs
	add_child(cs)
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(1.2, 1.2, 1.2)
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(0.55, 0.38, 0.2)
	bm.material = m
	mi.mesh = bm
	add_child(mi)
	var band := MeshInstance3D.new()
	var bb := BoxMesh.new()
	bb.size = Vector3(1.24, 0.18, 1.24)
	var bmat := StandardMaterial3D.new()
	bmat.albedo_color = Color(0.3, 0.2, 0.1)
	bb.material = bmat
	band.mesh = bb
	add_child(band)
