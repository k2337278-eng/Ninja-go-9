class_name Door
extends Interactable
## Sliding barrier (sinks into the ground). Opened by code, a plate/lever, or a key.
## flag_id persists the opened state.

var size := Vector3(4, 4, 1)
var color := Color(0.4, 0.35, 0.3)
var alpha := 1.0
var flag_id := ""
var key_id := ""
var opened := false
var body: StaticBody3D

func _ready() -> void:
	if key_id != "":
		super()
	prompt = ["Unlock the door", "افتح الباب"]
	radius = 3.5
	var mesh := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(color, alpha)
	m.roughness = 0.8
	if alpha < 1.0:
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mesh.mesh = bm
	mesh.material_override = m
	add_child(mesh)
	body = StaticBody3D.new()
	var cs := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = size
	cs.shape = bs
	body.add_child(cs)
	add_child(body)
	if flag_id != "" and GameState.flags.get(flag_id, false):
		open(true)

func can_use(_p: Player) -> bool:
	return key_id != "" and not opened

func use(p: Player) -> void:
	if GameState.flags.get("key_" + key_id, false):
		open()
	else:
		p.feedback.emit(Loc.pick(["The door is locked. You need a key.", "الباب مقفل. تحتاج إلى مفتاح."]))

func open(instant := false) -> void:
	if opened:
		return
	opened = true
	if flag_id != "":
		GameState.flags[flag_id] = true
	remove_from_group("interactable")
	var dest := position + Vector3(0, -(size.y + 0.3), 0)
	if instant:
		position = dest
		body.collision_layer = 0
	else:
		Sfx.play("quake")
		var tw := create_tween()
		tw.tween_property(self, "position", dest, 1.2)
		tw.tween_callback(func(): body.collision_layer = 0)
