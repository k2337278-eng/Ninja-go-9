class_name StoryStone
extends Interactable
## A glowing stone the story asks you to USE (focus your power, break the staff, call a dragon...).
## Set `color` and `prompt` BEFORE add_child().

signal triggered

var done := false
var color := Color(1.0, 0.85, 0.3)
var mat: StandardMaterial3D

func _ready() -> void:
	super()
	radius = 3.2
	var base := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.5
	cm.bottom_radius = 0.7
	cm.height = 0.5
	cm.radial_segments = 8
	cm.rings = 1
	base.mesh = cm
	base.position.y = 0.25
	add_child(base)
	var mi := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.55
	sm.height = 1.1
	sm.radial_segments = 8
	sm.rings = 4
	mat = StandardMaterial3D.new()
	mat.albedo_color = color
	mat.emission_enabled = true
	mat.emission = color
	sm.material = mat
	mi.mesh = sm
	mi.position.y = 1.3
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mi)

func can_use(_p: Player) -> bool:
	return not done

func use(_p: Player) -> void:
	if done:
		return
	done = true
	visible = false
	remove_from_group("interactable")
	Effects.burst(self, global_position + Vector3(0, 1.3, 0), color, 30, 6.0)
	Sfx.play("win", 1.2)
	triggered.emit()
