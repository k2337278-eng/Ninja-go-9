extends Node3D
## Chen's Island (original layout inspired by season 4) + Chapter 1 story flow:
## arrival -> walk to arena -> contestants welcomed -> match 1 -> match 2 -> end.
## The world is built from code primitives (no external assets).

const ARENA_C := Vector3(0, 0, -6)

var player: Player
var cam_rig: CameraRig
var hud: Hud
var cine: Camera3D
var sun: DirectionalLight3D
var companions: Array = []
var npc_rigs: Array = []
var chen: Minifig
var contestants: Array = []
var coins: Array = []
var marker: MeshInstance3D
var step := 0
var _cine_on := false
var _cine_look := Vector3.ZERO
var _mats := {}
var _t := 0.0
var story: Chapters
var vessels := {}
var grotto_gate: Door
var ruins_gate: Door
var captive_rigs := {}
var chapter_t0 := 0
var _prompt_target: Interactable
var _zone_t := 0.0
var party_ids: Array = []
var env: Environment
var sky_mat: ProceduralSkyMaterial

func L(en: String, ar: String) -> String:
	return en if Loc.lang == "en" else ar

# ---------------------------------------------------------------- setup ----
func _ready() -> void:
	step = GameState.story_step
	story = Chapters.new()
	story.isl = self
	var meta: Dictionary = Chapters.meta_for_step(step)
	GameState.selected_char = str(meta["player"])
	party_ids = (meta["party"] as Array).duplicate()
	GameState.powers_stolen = []
	GameState.captured = []
	chapter_t0 = Time.get_ticks_msec()
	add_child(story)
	_setup_environment()
	set_mood(str(meta["mood"]))
	_build_world()
	_spawn_actors()
	_build_ui()
	Engine.max_fps = 60
	apply_quality()
	Sfx.start_music()
	var t := Timer.new()
	t.wait_time = 45.0
	t.autostart = true
	t.timeout.connect(GameState.save_game)
	add_child(t)
	_run_story.call_deferred()

func _setup_environment() -> void:
	env = Environment.new()
	var sky := Sky.new()
	sky_mat = ProceduralSkyMaterial.new()
	sky.sky_material = sky_mat
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	sun = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-50, -35, 0)
	sun.light_energy = 1.1
	add_child(sun)
	cine = Camera3D.new()
	cine.far = 260.0
	add_child(cine)

func apply_quality() -> void:
	var q := int(GameState.settings.get("quality", 1))
	sun.shadow_enabled = q >= 1
	sun.directional_shadow_max_distance = 45.0 if q == 1 else 80.0
	get_viewport().msaa_3d = Viewport.MSAA_2X if q == 2 else Viewport.MSAA_DISABLED
	for r in npc_rigs:
		if is_instance_valid(r) and r.has_meta("spectator"):
			r.visible = q >= 1

func _mat(c: Color, emissive := false) -> StandardMaterial3D:
	var key := str(c) + str(emissive)
	if _mats.has(key):
		return _mats[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = 0.65
	if emissive:
		m.emission_enabled = true
		m.emission = c
		m.emission_energy_multiplier = 1.5
	_mats[key] = m
	return m

func _block(pos: Vector3, size: Vector3, c: Color, collide := true, emissive := false, rot_y := 0.0) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = _mat(c, emissive)
	mi.position = pos
	mi.rotation.y = rot_y
	if emissive:
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mi)
	if collide:
		var sb := StaticBody3D.new()
		var cs := CollisionShape3D.new()
		var bs := BoxShape3D.new()
		bs.size = size
		cs.shape = bs
		sb.add_child(cs)
		mi.add_child(sb)
	return mi

func _cylinder(pos: Vector3, rt: float, rb: float, h: float, c: Color, collide := true) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = rt
	cm.bottom_radius = rb
	cm.height = h
	cm.radial_segments = 12
	cm.rings = 1
	mi.mesh = cm
	mi.material_override = _mat(c)
	mi.position = pos
	add_child(mi)
	if collide and rt > 0.01:
		var sb := StaticBody3D.new()
		var cs := CollisionShape3D.new()
		var sh := CylinderShape3D.new()
		sh.radius = maxf(rt, rb)
		sh.height = h
		cs.shape = sh
		sb.add_child(cs)
		mi.add_child(sb)
	return mi

func _wall(pos: Vector3, size: Vector3) -> void:
	var sb := StaticBody3D.new()
	var cs := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = size
	cs.shape = bs
	sb.position = pos
	sb.add_child(cs)
	add_child(sb)

func _instances(mesh: Mesh, xforms: Array) -> void:
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.mesh = mesh
	mm.instance_count = xforms.size()
	for i in xforms.size():
		mm.set_instance_transform(i, xforms[i])
	var mmi := MultiMeshInstance3D.new()
	mmi.multimesh = mm
	add_child(mmi)

## First mesh of a .glb scene (null when the asset is missing, so callers can fall back).
func _glb_mesh(path: String) -> Mesh:
	if not ResourceLoader.exists(path):
		return null
	var ps := load(path) as PackedScene
	if ps == null:
		return null
	var inst := ps.instantiate()
	var result: Mesh = null
	for n in inst.find_children("*", "MeshInstance3D", true, false):
		result = (n as MeshInstance3D).mesh
		break
	inst.free()
	return result

func _blocked_spot(p: Vector3) -> bool:
	if Vector2(p.x - ARENA_C.x, p.z - ARENA_C.z).length() < 23.0:
		return true
	if absf(p.x) < 6.0 and p.z > -30.0:
		return true
	if p.z < -36.0 and absf(p.x) < 28.0:
		return true
	if p.z < -22.0 and p.z > -36.0 and absf(p.x) < 22.0:
		return true
	if p.z > 33.0:
		return true
	if Vector2(p.x - 48.0, p.z + 6.0).length() < 14.0:
		return true
	if Vector2(p.x + 52.0, p.z + 12.0).length() < 14.0:
		return true
	if Vector2(p.x + 30.0, p.z - 20.0).length() < 14.0:
		return true
	if Vector2(p.x - 29.0, p.z - 28.0).length() < 16.0:
		return true
	if Vector2(p.x - 58.0, p.z + 40.0).length() < 14.0:
		return true
	if Vector2(p.x - 38.0, p.z + 58.0).length() < 16.0:
		return true
	if Vector2(p.x + 48.0, p.z + 52.0).length() < 22.0:
		return true
	if Vector2(p.x - 62.0, p.z + 6.0).length() < 10.0:
		return true
	if absf(p.x) < 4.5 and p.z > 8.0:
		return true
	return false

func _build_world() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 4242
	var grass := Color(0.28, 0.55, 0.22)
	var stone := Color(0.62, 0.6, 0.58)
	# ground, beach, sea, boundaries
	_block(Vector3(0, -1.5, 0), Vector3(150, 3, 150), grass)
	_block(Vector3(0, -0.49, 50), Vector3(150, 1.02, 28), Color(0.86, 0.78, 0.55), false)
	var sea := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(700, 700)
	sea.mesh = pm
	sea.material_override = _mat(Color(0.1, 0.42, 0.72))
	sea.position = Vector3(0, -1.0, 0)
	sea.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(sea)
	_wall(Vector3(0, 3, 66), Vector3(150, 8, 2))
	_wall(Vector3(0, 3, -72), Vector3(150, 8, 2))
	_wall(Vector3(74, 3, 0), Vector3(2, 8, 150))
	_wall(Vector3(-74, 3, 0), Vector3(2, 8, 150))
	# path beach -> arena
	_block(Vector3(0, 0.03, 25), Vector3(5, 0.06, 32), Color(0.5, 0.47, 0.42), false)
	# arena (sloped platform, convex collision) + marking
	var plat := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 14.5
	cm.bottom_radius = 17.5
	cm.height = 0.4
	cm.radial_segments = 32
	cm.rings = 1
	plat.mesh = cm
	plat.material_override = _mat(stone)
	plat.position = ARENA_C
	add_child(plat)
	plat.create_convex_collision()
	var ring := _cylinder(ARENA_C + Vector3(0, 0.205, 0), 9.0, 9.0, 0.02, Color(0.3, 0.12, 0.12), false)
	ring.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	for i in 12:
		var a := TAU * i / 12.0
		var pp := ARENA_C + Vector3(cos(a), 0, sin(a)) * 19.0
		_cylinder(pp + Vector3(0, 3, 0), 0.7, 0.8, 6.0, Color(0.75, 0.73, 0.7))
		_block(pp + Vector3(0, 6.3, 0), Vector3(0.6, 0.6, 0.6), Color(1.0, 0.5, 0.1), false, true)
	# bleachers
	for i in 3:
		var h := 1.5 * (i + 1)
		_block(Vector3(0, h * 0.5, -24.0 - i * 2.5), Vector3(36, h, 2.5), Color(0.5, 0.35, 0.2))
	# palace + towers + balcony
	_block(Vector3(0, 8, -52), Vector3(44, 16, 14), Color(0.55, 0.5, 0.65))
	for sx in [-24.0, 24.0]:
		_cylinder(Vector3(sx, 11, -52), 3.0, 3.0, 22.0, Color(0.6, 0.55, 0.7))
		_cylinder(Vector3(sx, 24.5, -52), 0.0, 3.8, 5.0, Color(0.6, 0.12, 0.15), false)
	_block(Vector3(0, 4, -44.9), Vector3(6, 8, 0.3), Color(0.08, 0.06, 0.1), false)
	_block(Vector3(0, 9.7, -42.0), Vector3(12, 0.6, 6), Color(0.45, 0.4, 0.5))
	_block(Vector3(0, 10.6, -39.1), Vector3(12, 1.2, 0.3), Color(0.45, 0.4, 0.5))
	chen = Minifig.new()
	add_child(chen)
	chen.build({"suit": Color(0.35, 0.05, 0.1), "style": "bare", "robe": Color(0.3, 0.0, 0.35),
		"hat": Color(0.2, 0.0, 0.2), "scale": 1.25})
	chen.position = Vector3(0, 10.0, -42.5)
	chen.rotation.y = PI
	npc_rigs.append(chen)
	# spectators on bleachers
	var scol := [Color(0.8, 0.3, 0.3), Color(0.3, 0.5, 0.8), Color(0.8, 0.7, 0.2), Color(0.4, 0.7, 0.4), Color(0.6, 0.4, 0.7), Color(0.9, 0.5, 0.2)]
	for i in 6:
		var sp := Minifig.new()
		add_child(sp)
		sp.build({"suit": scol[i], "style": "bare", "hair": Color(0.15, 0.1, 0.05)})
		sp.position = Vector3(-10.0 + i * 4.0, 4.5, -29.0)
		sp.set_meta("spectator", true)
		npc_rigs.append(sp)
	# temple (east)
	_block(Vector3(48, 0.05, -6), Vector3(16, 0.1, 16), Color(0.7, 0.68, 0.62), false)
	for i in 8:
		var a := TAU * i / 8.0
		_cylinder(Vector3(48 + cos(a) * 6.5, 3, -6 + sin(a) * 6.5), 0.6, 0.6, 6.0, Color(0.8, 0.78, 0.72))
	_block(Vector3(48, 6.5, -6), Vector3(18, 1.0, 18), Color(0.6, 0.55, 0.5), false)
	_block(Vector3(48, 0.6, -6), Vector3(3, 1.2, 3), Color(0.5, 0.45, 0.4))
	# cave (west): walls + roof, open to the east
	_block(Vector3(-50, 3, -19), Vector3(14, 6, 1), Color(0.35, 0.33, 0.33))
	_block(Vector3(-50, 3, -5), Vector3(14, 6, 1), Color(0.35, 0.33, 0.33))
	_block(Vector3(-57, 3, -12), Vector3(1, 6, 15), Color(0.3, 0.28, 0.28))
	_block(Vector3(-50, 6.5, -12), Vector3(15, 1, 15), Color(0.3, 0.28, 0.28), false)
	_block(Vector3(-56, 2.5, -12), Vector3(0.4, 0.4, 0.4), Color(0.4, 0.8, 1.0), false, true)
	# boat on the beach
	_block(Vector3(-14, 0.5, 60), Vector3(7, 1.2, 2.6), Color(0.45, 0.28, 0.15))
	_cylinder(Vector3(-14, 3, 60), 0.12, 0.12, 5.0, Color(0.4, 0.25, 0.12), false)
	# forest trees (MultiMesh visuals + one static body)
	var trunks: Array = []
	var crowns: Array = []
	var tree_body := StaticBody3D.new()
	add_child(tree_body)
	var tries := 0
	while trunks.size() < 55 and tries < 800:
		tries += 1
		var p := Vector3(rng.randf_range(-70, 70), 0, rng.randf_range(-68, 34))
		if _blocked_spot(p):
			continue
		var s := rng.randf_range(0.8, 1.4)
		var bs := Basis.from_scale(Vector3(s, s, s))
		trunks.append(Transform3D(bs, p + Vector3(0, 1.5 * s, 0)))
		crowns.append(Transform3D(bs, p + Vector3(0, 5.2 * s, 0)))
		var cs := CollisionShape3D.new()
		var sh := CylinderShape3D.new()
		sh.radius = 0.5 * s
		sh.height = 3.0 * s
		cs.shape = sh
		cs.position = p + Vector3(0, 1.5 * s, 0)
		tree_body.add_child(cs)
	var tm := CylinderMesh.new()
	tm.top_radius = 0.3
	tm.bottom_radius = 0.4
	tm.height = 3.0
	tm.radial_segments = 8
	tm.rings = 1
	tm.material = _mat(Color(0.4, 0.26, 0.14))
	var km := CylinderMesh.new()
	km.top_radius = 0.0
	km.bottom_radius = 2.2
	km.height = 4.5
	km.radial_segments = 8
	km.rings = 1
	km.material = _mat(Color(0.12, 0.42, 0.16))
	var tree_mesh := _glb_mesh("res://assets/models/tree_pine.glb")
	if tree_mesh != null:
		var txf: Array = []
		for t in trunks:
			var tsc: float = t.basis.x.length()
			txf.append(Transform3D(t.basis, t.origin - Vector3(0, 1.5 * tsc, 0)))
		_instances(tree_mesh, txf)
	else:
		_instances(tm, trunks)
		_instances(km, crowns)
	# palms on the beach
	var ptr: Array = []
	var pcr: Array = []
	for i in 8:
		var px := -50.0 + i * 14.0 + rng.randf_range(-3, 3)
		var pz := rng.randf_range(40, 55)
		if absf(px) < 6.0:
			continue
		ptr.append(Transform3D(Basis(), Vector3(px, 2.0, pz)))
		pcr.append(Transform3D(Basis(), Vector3(px, 4.4, pz)))
	var ptm := CylinderMesh.new()
	ptm.top_radius = 0.2
	ptm.bottom_radius = 0.3
	ptm.height = 4.0
	ptm.radial_segments = 6
	ptm.rings = 1
	ptm.material = _mat(Color(0.55, 0.4, 0.2))
	var pcm := SphereMesh.new()
	pcm.radius = 1.6
	pcm.height = 1.6
	pcm.radial_segments = 8
	pcm.rings = 3
	pcm.material = _mat(Color(0.2, 0.6, 0.25))
	var palm_mesh := _glb_mesh("res://assets/models/palm.glb")
	if palm_mesh != null:
		var pxf: Array = []
		for t in ptr:
			pxf.append(Transform3D(Basis(), t.origin - Vector3(0, 2.0, 0)))
		_instances(palm_mesh, pxf)
	else:
		_instances(ptm, ptr)
		_instances(pcm, pcr)
	var rock_mesh := _glb_mesh("res://assets/models/rock.glb")
	# rocks (collidable)
	for i in 14:
		var rp := Vector3(rng.randf_range(-68, 68), 0.0, rng.randf_range(-66, 30))
		if _blocked_spot(rp):
			continue
		var rm := MeshInstance3D.new()
		var sm := SphereMesh.new()
		sm.radius = 1.0
		sm.height = 1.6
		sm.radial_segments = 8
		sm.rings = 4
		if rock_mesh != null:
			rm.mesh = rock_mesh
		else:
			rm.mesh = sm
			rm.material_override = _mat(Color(0.45, 0.45, 0.47))
		rm.position = rp
		rm.scale = Vector3(rng.randf_range(0.8, 2.0), rng.randf_range(0.6, 1.4), rng.randf_range(0.8, 2.0))
		add_child(rm)
		rm.create_convex_collision()
	# coins (collectibles, collected ids are saved)
	var cpos := [
		Vector3(0, 0.9, 44), Vector3(0, 0.9, 36), Vector3(2, 0.9, 28), Vector3(-2, 0.9, 20), Vector3(0, 0.9, 14),
		Vector3(10, 0.9, -6), Vector3(-10, 0.9, -6), Vector3(0, 0.9, -14), Vector3(0, 0.9, 2),
		Vector3(46, 0.9, -6), Vector3(50, 0.9, -6), Vector3(48, 0.9, -3),
		Vector3(-52, 0.9, -12), Vector3(-54, 0.9, -9), Vector3(-54, 0.9, -15),
		Vector3(30, 0.9, 10), Vector3(-28, 0.9, 12), Vector3(35, 0.9, -25), Vector3(-35, 0.9, -28), Vector3(20, 0.9, 30),
	]
	var coin_mesh := CylinderMesh.new()
	coin_mesh.top_radius = 0.3
	coin_mesh.bottom_radius = 0.3
	coin_mesh.height = 0.06
	coin_mesh.radial_segments = 12
	coin_mesh.rings = 1
	coin_mesh.material = _mat(Color(1.0, 0.8, 0.1), true)
	for i in cpos.size():
		if GameState.collected.has(i):
			continue
		var ci := MeshInstance3D.new()
		ci.mesh = coin_mesh
		ci.position = cpos[i]
		ci.rotation.x = PI / 2.0
		ci.set_meta("id", i)
		ci.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(ci)
		coins.append(ci)
	# objective marker (light pillar)
	marker = MeshInstance3D.new()
	var mk := CylinderMesh.new()
	mk.top_radius = 0.8
	mk.bottom_radius = 0.8
	mk.height = 8.0
	mk.radial_segments = 12
	mk.rings = 1
	var mkm := StandardMaterial3D.new()
	mkm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mkm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mkm.albedo_color = Color(1.0, 0.9, 0.2, 0.35)
	mk.material = mkm
	marker.mesh = mk
	marker.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	marker.visible = false
	add_child(marker)
	IslandExtras.build(self)

func _spawn_actors() -> void:
	cam_rig = CameraRig.new()
	add_child(cam_rig)
	var spawn := story.spawn_for(step)
	player = Player.new()
	player.setup_character(GameState.selected_char, true)
	SkillTree.apply(player)
	player.position = spawn
	player.cam_rig = cam_rig
	add_child(player)
	cam_rig.target = player
	cam_rig.global_position = spawn + Vector3(0, 1.3, 0)
	var slot := 0
	for id in others_ids():
		_spawn_companion(id, slot, spawn + Vector3(-3.0 + slot * 2.0, 0.2, 3.0))
		slot += 1
	player.died.connect(_on_player_died)
	player.interact_pressed.connect(_on_interact)

func _build_ui() -> void:
	hud = Hud.new()
	add_child(hud)
	hud.bind(player)
	player.bind_controls(hud.controls)
	player.pause_requested.connect(hud.open_pause)
	player.feedback.connect(hud.toast)

func _on_interact() -> void:
	if _prompt_target != null and is_instance_valid(_prompt_target):
		_prompt_target.use(player)
		return
	var best: Companion = null
	var bd := 4.0
	for c in companions:
		var d := player.global_position.distance_to(c.global_position)
		if d < bd:
			bd = d
			best = c
	if best == null:
		return
	var line := _companion_line(best)
	await talk([[best.display_name, line]])

const BANTER := {
	"kai": [["I'm ready. Let the flames do the talking.", "أنا مستعد. دع النار تتحدث."], ["Stay close, I'll cover you.", "ابقَ قريبًا، سأغطيك."], ["Something's burning here, and it isn't just me.", "هناك شيء يحترق هنا، وليس أنا فقط."]],
	"jay": [["Did you hear that thunder? That was me being nervous.", "هل سمعت الرعد؟ كان هذا أنا من التوتر."], ["Let's wrap this up fast, I'm full of energy!", "لننهِ هذا بسرعة، أنا مليء بالطاقة!"], ["I've got your back. And a few sparks.", "أنا خلفك. ومعي بعض الشرر."]],
	"cole": [["Steady feet, steady hands. We'll be fine.", "أقدام ثابتة، أيدٍ ثابتة. سنكون بخير."], ["If something blocks the way, I'll move it.", "إن سد شيء الطريق فسأزيحه."], ["I don't like how quiet this place is.", "لا يعجبني هدوء هذا المكان."]],
	"zane": [["My sensors detect no immediate threat. Stay alert anyway.", "لا ترصد حساساتي تهديدًا مباشرًا. ابقَ متيقظًا مع ذلك."], ["The odds favor us if we stay together.", "الاحتمالات في صالحنا إن بقينا معًا."], ["Cold focus wins fights.", "التركيز البارد يربح المعارك."]],
	"lloyd": [["I'll do whatever it takes to protect everyone.", "سأفعل أي شيء لحماية الجميع."], ["Let's keep moving. We're closer than we think.", "لنواصل التقدم. نحن أقرب مما نظن."], ["I believe in this team.", "أؤمن بهذا الفريق."]],
	"skylor": [["I can feel the stolen power pulling at me. We must hurry.", "أشعر بالقوة المسلوبة تشدني. يجب أن نسرع."], ["Trust me. I know how this staff works.", "ثق بي. أعرف كيف تعمل هذه العصا."], ["Stay near me and I'll keep you strong.", "ابقَ قريبًا مني وسأبقيك قويًا."]],
}

func _companion_line(c: Companion) -> String:
	if c.power_stolen:
		return L("My power... I can't feel it anymore.", "قوتي... لم أعد أشعر بها.")
	var pool: Array = BANTER.get(c.char_id, [["Ready.", "جاهز."]])
	return Loc.pick(pool[randi() % pool.size()])

# -------------------------------------------------------------- per frame ---
func _process(delta: float) -> void:
	_t += delta
	if _cine_on:
		cine.look_at(_cine_look)
	for r in npc_rigs:
		if is_instance_valid(r) and r.visible:
			r.update_anim(delta, 0.0, false)
	for c in coins:
		if not is_instance_valid(c):
			continue
		c.rotation.z += delta * 3.0
		if player != null and player.global_position.distance_to(c.global_position) < 1.4:
			_collect(c)
	coins = coins.filter(func(x): return is_instance_valid(x) and not x.is_queued_for_deletion())
	if marker.visible:
		marker.scale.y = 1.0 + sin(_t * 3.0) * 0.1
	_update_world(delta)

# ------------------------------------------------------------ story flow ----
func _set_step(s: int) -> void:
	step = s
	GameState.story_step = s
	GameState.max_step = maxi(GameState.max_step, s)
	GameState.save_game()

func _cine_start(from: Vector3, look: Vector3) -> void:
	_cine_look = look
	_cine_on = true
	cine.global_position = from
	cine.make_current()
	cine.look_at(look)

func _cine_stop() -> void:
	_cine_on = false
	cam_rig.cam.make_current()

func _cutscene_begin() -> void:
	player.input_locked = true
	hud.set_gameplay_visible(false)

func _cutscene_end() -> void:
	_cine_stop()
	player.input_locked = false
	hud.set_gameplay_visible(true)

func _alive() -> bool:
	return is_inside_tree() and player != null and is_instance_valid(player)

func _run_story() -> void:
	await story.run()

func _on_enemy_died(f: Fighter) -> void:
	var e := f as Enemy
	if e == null:
		return
	GameState.add_xp(e.xp_reward)
	GameState.add_coins(e.coin_reward)
	GameState.stat("kills")
	if e.kind == "dummy" and e.is_in_group("practice"):
		GameState.stat("dummies")
		_check_side_quests()

# ============================================================ v2 services ===
const ZONES := [
	{"id": "beach", "name": ["Sunset Beach", "شاطئ الغروب"], "pos": Vector3(0, 0, 52), "r": 16.0},
	{"id": "arena", "name": ["Tournament Arena", "ساحة البطولة"], "pos": Vector3(0, 0, -6), "r": 20.0},
	{"id": "palace", "name": ["Chen's Palace", "قصر تشِن"], "pos": Vector3(0, 0, -38), "r": 10.0},
	{"id": "temple", "name": ["Elemental Temple", "معبد العناصر"], "pos": Vector3(48, 0, -6), "r": 12.0},
	{"id": "cave", "name": ["Whispering Cave", "الكهف الهامس"], "pos": Vector3(-50, 0, -12), "r": 9.0},
	{"id": "ruins", "name": ["Crumbled Ruins", "الأطلال المنهارة"], "pos": Vector3(-30, 0, 20), "r": 10.0},
	{"id": "shrines", "name": ["Elemental Shrines", "مزارات العناصر"], "pos": Vector3(29, 0, 28), "r": 14.0},
	{"id": "cliff", "name": ["Northeast Cliff", "جرف الشمال الشرقي"], "pos": Vector3(58, 0, -30), "r": 9.0},
	{"id": "grotto", "name": ["Hidden Grotto", "الكهف الخفي"], "pos": Vector3(38, 0, -58), "r": 10.0},
	{"id": "serpent", "name": ["Serpent Ruins", "أطلال الثعابين"], "pos": Vector3(-48, 0, -52), "r": 14.0},
]

## Allies for the CURRENT beat (the story decides, see ChapterBase.beat).
func others_ids() -> Array:
	return party_ids

func _spawn_companion(id: String, slot: int, pos: Vector3) -> Companion:
	var c := Companion.new()
	c.setup_character(id)
	c.team = "player"
	c.leader = player
	c.slot = slot
	c.position = pos
	SkillTree.apply(c, false)
	add_child(c)
	companions.append(c)
	return c

func add_companion(id: String, pos: Vector3) -> void:
	if comp_by_id(id) != null:
		return
	var c := _spawn_companion(id, companions.size(), pos)
	Effects.burst(c, pos + Vector3(0, 1.0, 0), Color(1, 1, 0.6), 20, 5.0)

func remove_companion(id: String) -> void:
	var c := comp_by_id(id)
	if c == null:
		return
	Effects.ring(c, c.global_position, 3.5, Color(0.5, 0.1, 0.7))
	companions.erase(c)
	c.queue_free()

func comp_by_id(id: String) -> Companion:
	for c in companions:
		if is_instance_valid(c) and c.char_id == id:
			return c
	return null

func fighter_by_id(id: String) -> Fighter:
	if player.char_id == id:
		return player
	return comp_by_id(id)

func talk(lines: Array) -> void:
	var was := player.input_locked
	player.input_locked = true
	await hud.dialogue.play(lines)
	player.input_locked = was

func spawn_enemy(kind: String, pos: Vector3) -> Enemy:
	var e := Enemy.make(kind)
	e.position = pos
	e.died.connect(_on_enemy_died)
	add_child(e)
	return e

func spawn_boss(id: String, pos: Vector3) -> Boss:
	var b := Boss.build(id)
	b.position = pos
	b.died.connect(_on_enemy_died)
	b.phase_changed.connect(_on_boss_phase)
	b.summon_requested.connect(_on_boss_summon)
	add_child(b)
	hud.set_boss(b)
	return b

func _on_boss_phase(_b, n: int) -> void:
	hud.banner(L("Phase %d", "المرحلة %d") % n, 1.2)

func _on_boss_summon(b, kind: String, count: int) -> void:
	var alive := 0
	for n in get_tree().get_nodes_in_group("enemies"):
		if n != b and not n.is_in_group("practice") and not (n is Boss):
			alive += 1
	for k in mini(count, maxi(0, 5 - alive)):
		var a := randf() * TAU
		spawn_enemy(kind, b.global_position + Vector3(cos(a), 0.3, sin(a)) * 5.0)

func clear_enemies() -> void:
	for n in get_tree().get_nodes_in_group("enemies"):
		if n.is_in_group("practice"):
			continue
		n.remove_from_group("fighters")
		n.remove_from_group("enemies")
		n.queue_free()
	hud.set_boss(null)

func wait_enemies_dead(arr: Array) -> bool:
	while true:
		await get_tree().create_timer(0.25).timeout
		if not _alive() or player.state == Fighter.S.DEAD:
			return false
		var alive := 0
		for e in arr:
			if is_instance_valid(e) and e.state != Fighter.S.DEAD:
				alive += 1
		if alive == 0:
			return true
	return false

func teleport_party(pos: Vector3) -> void:
	await hud.fade(1.0, 0.4)
	player.global_position = pos
	player.velocity = Vector3.ZERO
	cam_rig.global_position = pos + Vector3(0, 1.3, 0)
	for c in companions:
		if is_instance_valid(c):
			c.global_position = pos + Vector3(randf_range(-3.0, 3.0), 0.2, randf_range(2.0, 4.0))
	await hud.fade(0.0, 0.4)

func make_beacon(pos: Vector3, color: Color, h := 7.0) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.9
	cm.bottom_radius = 0.9
	cm.height = h
	cm.radial_segments = 12
	cm.rings = 1
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.albedo_color = Color(color, 0.35)
	cm.material = m
	mi.mesh = cm
	mi.position = pos + Vector3(0, h * 0.5, 0)
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mi)
	return mi

func make_cage(pos: Vector3, id: String) -> Door:
	var d := Door.new()
	d.size = Vector3(3.4, 3.0, 3.4)
	d.color = Color(0.3, 0.3, 0.35)
	d.alpha = 0.35
	d.position = pos + Vector3(0, 1.5, 0)
	add_child(d)
	var rig := Minifig.new()
	add_child(rig)
	rig.build({"suit": CharacterDB.DATA[id]["suit"], "style": "ninja"})
	rig.position = pos
	npc_rigs.append(rig)
	captive_rigs[id] = rig
	return d

func free_captive(id: String) -> void:
	if captive_rigs.has(id):
		var r: Minifig = captive_rigs[id]
		npc_rigs.erase(r)
		r.queue_free()
		captive_rigs.erase(id)

func add_relic(pos: Vector3, id: int) -> void:
	if GameState.collected.has(id):
		return
	var mi := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.32
	sm.height = 0.64
	sm.radial_segments = 4
	sm.rings = 2
	sm.material = _mat(Color(0.3, 0.9, 1.0), true)
	mi.mesh = sm
	mi.position = pos
	mi.set_meta("id", id)
	mi.set_meta("kind", "relic")
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mi)
	coins.append(mi)

func _collect(c: Node3D) -> void:
	GameState.collected.append(int(c.get_meta("id")))
	if str(c.get_meta("kind", "coin")) == "relic":
		GameState.stat("relics")
		hud.toast(L("Relic found (%d/12)", "عثرت على أثر (%d/12)") % GameState.count_ids(100, 199))
		Sfx.play("win", 1.5)
	else:
		GameState.add_coins(1)
		GameState.stat("coins_collected")
		Sfx.play("coin")
	c.queue_free()
	_check_side_quests()

func flag(id: String) -> bool:
	return bool(GameState.flags.get(id, false))

func _check_side_quests() -> void:
	if not flag("sq_bricks") and GameState.count_ids(100, 199) >= 6:
		GameState.flags["sq_bricks"] = true
		GameState.skill_points += 1
		hud.toast(L("Side mission complete: Lost Relics (+1 skill point)", "اكتملت مهمة جانبية: الآثار المفقودة (+1 نقطة مهارة)"))
	if not flag("sq_scrolls") and GameState.count_ids(200, 299) >= 6:
		GameState.flags["sq_scrolls"] = true
		GameState.add_coins(150)
		hud.toast(L("Side mission complete: Scroll Scholar (+150 coins)", "اكتملت مهمة جانبية: عالِم اللفائف (+150 عملة)"))
	if not flag("sq_dummies") and int(GameState.stats.get("dummies", 0)) >= 10:
		GameState.flags["sq_dummies"] = true
		GameState.add_xp(150)
		hud.toast(L("Side mission complete: Arena Practice (+150 XP)", "اكتملت مهمة جانبية: تدريب الساحة (+150 خبرة)"))

func steal_power(id: String) -> void:
	GameState.steal_power(id)
	var f := fighter_by_id(id)
	if f != null:
		Effects.ring(f, f.global_position, 4.0, Color(0.5, 0.1, 0.7))
		Effects.burst(f, f.global_position + Vector3(0, 1.2, 0), Color(0.6, 0.2, 0.8), 30, 7.0)
		f.apply_stagger(0.8)
	Sfx.play("zap", 0.6)
	hud.toast(L("%s's elemental power was stolen!", "سُلبت قوة %s العنصرية!") % CharacterDB.name_of(id))

func restore_power(id: String) -> void:
	GameState.restore_power(id)
	var f := fighter_by_id(id)
	if f != null:
		Effects.ring(f, f.global_position, 4.0, Color(1.0, 0.8, 0.2))
		Effects.burst(f, f.global_position + Vector3(0, 1.2, 0), Color(1.0, 0.85, 0.3), 30, 7.0)
	Sfx.play("win", 1.3)
	hud.toast(L("%s's power is restored!", "عادت قوة %s!") % CharacterDB.name_of(id))

func chapter_start() -> void:
	chapter_t0 = Time.get_ticks_msec()

func finish_chapter(n: int, par: float, show := true, extra: Array = []) -> void:
	var secs := (Time.get_ticks_msec() - chapter_t0) / 1000.0
	var d := GameState.deaths_chapter
	var rating := "B"
	if d == 0 and secs <= par:
		rating = "S"
	elif d <= 1:
		rating = "A"
	var order := {"S": 3, "A": 2, "B": 1}
	var best := str(GameState.ratings.get(str(n), ""))
	if best == "" or int(order[rating]) > int(order.get(best, 0)):
		GameState.ratings[str(n)] = rating
	var sp := 2 if rating == "S" else 1
	var first := not flag("done_ch%d" % n)
	if first:
		GameState.flags["done_ch%d" % n] = true
		GameState.skill_points += sp
		GameState.add_coins(100)
		GameState.add_xp(60 * n)
	GameState.deaths_chapter = 0
	if rating == "S":
		GameState.award("perfectionist")
	GameState.save_game()
	if show:
		var lines: Array = extra.duplicate()
		lines.append(L("Rating: %s", "التقييم: %s") % rating)
		lines.append(L("Time: %d s", "الوقت: %d ث") % int(secs))
		if first:
			lines.append(L("Skill points +%d   Coins +100", "نقاط المهارة +%d   العملات +100") % sp)
		await hud.show_results(L("Chapter %d complete", "اكتمل الفصل %d") % n, lines)

func show_results(title: String, lines: Array) -> void:
	await hud.show_results(title, lines)

func _on_player_died(_f) -> void:
	GameState.deaths_chapter += 1
	GameState.save_game()
	hud.show_defeat()

func _update_world(delta: float) -> void:
	_zone_t -= delta
	if _zone_t <= 0.0:
		_zone_t = 0.5
		for z in ZONES:
			var fid := "zone_" + str(z["id"])
			if flag(fid):
				continue
			var zp: Vector3 = z["pos"]
			if Vector2(player.global_position.x - zp.x, player.global_position.z - zp.z).length() < float(z["r"]):
				GameState.flags[fid] = true
				GameState.stat("zones")
				hud.toast(L("Discovered: ", "اكتشفت: ") + Loc.pick(z["name"]))
	_check_grotto()
	var best: Interactable = null
	var bd := 1.0e9
	if not player.input_locked and hud.hud_root.visible:
		for n in get_tree().get_nodes_in_group("interactable"):
			var it := n as Interactable
			if it == null or not it.visible:
				continue
			var d := player.global_position.distance_to(it.global_position)
			if d < it.radius and d < bd and it.can_use(player):
				bd = d
				best = it
	_prompt_target = best
	hud.set_prompt(best.prompt_text() if best != null else "")

## Optional side puzzle: the three sigils open the Hidden Grotto gate (no boss any more).
func _check_grotto() -> void:
	if grotto_gate != null and not grotto_gate.opened and flag("sigil_a") and flag("sigil_b") and flag("sigil_c"):
		grotto_gate.open()
		hud.toast(L("The Hidden Grotto gate opens.", "تنفتح بوابة الكهف الخفي."))

# ===================================================== story services (v3) ===
## Sky/light mood of a beat: "" normal, "digi" (Digiverse), "snow" (Zane's blizzard dream), "dusk" (final battle).
func set_mood(m: String) -> void:
	if sky_mat == null:
		return
	match m:
		"digi":
			sky_mat.sky_top_color = Color(0.0, 0.2, 0.28)
			sky_mat.sky_horizon_color = Color(0.0, 0.55, 0.6)
			sky_mat.ground_horizon_color = Color(0.0, 0.45, 0.5)
			sky_mat.ground_bottom_color = Color(0.0, 0.1, 0.15)
			sun.light_color = Color(0.5, 1.0, 1.0)
		"snow":
			sky_mat.sky_top_color = Color(0.62, 0.72, 0.85)
			sky_mat.sky_horizon_color = Color(0.9, 0.94, 1.0)
			sky_mat.ground_horizon_color = Color(0.85, 0.9, 0.95)
			sky_mat.ground_bottom_color = Color(0.7, 0.78, 0.88)
			sun.light_color = Color(0.85, 0.92, 1.0)
		"gloom":
			sky_mat.sky_top_color = Color(0.45, 0.52, 0.62)
			sky_mat.sky_horizon_color = Color(0.7, 0.75, 0.8)
			sky_mat.ground_horizon_color = Color(0.7, 0.75, 0.8)
			sun.light_color = Color(0.8, 0.88, 1.0)
		"dusk":
			sky_mat.sky_top_color = Color(0.25, 0.1, 0.35)
			sky_mat.sky_horizon_color = Color(0.9, 0.4, 0.25)
			sky_mat.ground_horizon_color = Color(0.7, 0.3, 0.25)
			sun.light_color = Color(1.0, 0.6, 0.45)

## Save and rebuild the scene so the next beat gets its own player/party/mood.
func reload_story() -> void:
	GameState.save_game()
	get_tree().reload_current_scene()

## CUTSCENE HOOK. A real cinematic registered in Cutscenes.CUSTOM replaces the placeholder:
## a camera framing + a narrator card. The id is also saved as flag hook_<id>.
func play_hook(id: String, en: String, ar: String, cam_from := Vector3.ZERO, cam_look := Vector3.ZERO) -> void:
	if not _alive():
		return
	GameState.flags["hook_" + id] = true
	if OS.is_debug_build():
		print("[CUTSCENE HOOK] ", id)
		hud.toast("[HOOK] " + id)
	_cutscene_begin()
	if Cutscenes.has(id):
		await Cutscenes.play(self, id)
	else:
		if cam_from != Vector3.ZERO:
			_cine_start(cam_from, cam_look)
		else:
			_cine_start(player.global_position + Vector3(0, 5, 9), player.global_position + Vector3(0, 1.5, 0))
		await hud.dialogue.play([[Loc.t("narrator"), L(en, ar)]])
	if _alive():
		_cutscene_end()
