class_name Conveyor
extends Node3D
## A conveyor belt (noodle factory, ch. 4): pushes every fighter standing on it along `dir`.
## Set `size`, `dir` and `speed` BEFORE add_child().

var size := Vector3(10, 0.3, 4)
var dir := Vector3(1, 0, 0)
var speed := 3.5
var stripes: Array = []
var phase := 0.0

func _ready() -> void:
	var base := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	base.mesh = bm
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(0.2, 0.2, 0.24)
	base.material_override = m
	base.position.y = size.y * 0.5
	add_child(base)
	var n := int(size.x / 1.6)
	for i in n:
		var st := MeshInstance3D.new()
		var sm := BoxMesh.new()
		sm.size = Vector3(0.35, 0.05, size.z * 0.9)
		st.mesh = sm
		var sm2 := StandardMaterial3D.new()
		sm2.albedo_color = Color(1.0, 0.8, 0.2)
		sm2.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		st.material_override = sm2
		add_child(st)
		stripes.append(st)
	rotation.y = atan2(dir.x, dir.z) - PI * 0.5
	_place_stripes()

func _place_stripes() -> void:
	var n := stripes.size()
	if n == 0:
		return
	var step := size.x / float(n)
	for i in n:
		var st: MeshInstance3D = stripes[i]
		var x := fposmod(float(i) * step + phase, size.x) - size.x * 0.5
		st.position = Vector3(x, size.y + 0.03, 0)

func _physics_process(delta: float) -> void:
	phase += speed * delta
	_place_stripes()
	for n in get_tree().get_nodes_in_group("fighters"):
		var f := n as Fighter
		if f == null or f.state == Fighter.S.DEAD:
			continue
		var lp := to_local(f.global_position)
		if absf(lp.x) < size.x * 0.5 and absf(lp.z) < size.z * 0.5 and lp.y > -0.5 and lp.y < 2.2:
			f.global_position += dir.normalized() * speed * delta
