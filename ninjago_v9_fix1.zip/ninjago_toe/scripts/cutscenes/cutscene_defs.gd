class_name CutsceneDefs
extends RefCounted
## Registry + helpers for scene definitions (see CutscenePlayer for the format).
## Scenes: cutscene_defs_a.gd (ch. 1-2), cutscene_defs_b.gd (ch. 3), cutscene_defs_c.gd (ch. 4-5).
## All dialogue/narration here is ORIGINAL wording. Anything not confirmed by STORY_SPEC.md is marked VERIFY
## in docs/CUTSCENE_HOOKS.md. Add ch. 6-10 scenes the same way (delivery B).

static var _defs: Dictionary = {}

static func _ensure() -> void:
	if _defs.is_empty():
		_defs.merge(CutsceneDefsA.build())
		_defs.merge(CutsceneDefsB.build())
		_defs.merge(CutsceneDefsC.build())
		_defs.merge(CutsceneDefsD.build())
		_defs.merge(CutsceneDefsE.build())
		_defs.merge(CutsceneDefsF.build())
		_defs.merge(CutsceneDefsG.build())

static func has(id: String) -> bool:
	_ensure()
	return _defs.has(id)

static func get_def(id: String) -> Dictionary:
	_ensure()
	return _defs[id]

# ---- helpers used by the def files ----
## One spoken/narrated subtitle: Q("kai", "english", "عربي"). who = character id or "narrator".
static func Q(who: String, en: String, ar: String) -> Array:
	return [who, en, ar]

## A shot. f = camera, l = look-at, d = seconds, mv = static|dolly|orbit|crane|hand; ex = extra keys (t, l2, arc, say, act, fx, mood, ez).
static func sh(f: Vector3, l: Vector3, d: float, mv := "static", fov := 60.0, ex := {}) -> Dictionary:
	var s := {"f": f, "l": l, "d": d, "mv": mv, "fov": fov}
	for k in ex.keys():
		s[k] = ex[k]
	return s

## A puppet of a playable character (or a custom figure when cfg is given).
static func ch(id: String, who: String, pos: Vector3, at := Vector3.ZERO) -> Dictionary:
	var d := {"id": id, "char": who, "pos": pos}
	if at != Vector3.ZERO:
		d["yaw"] = atan2(-(at.x - pos.x), -(at.z - pos.z))
	return d

static func fig(id: String, cfg: Dictionary, pos: Vector3, at := Vector3.ZERO) -> Dictionary:
	var d := {"id": id, "cfg": cfg, "pos": pos}
	if at != Vector3.ZERO:
		d["yaw"] = atan2(-(at.x - pos.x), -(at.z - pos.z))
	return d

static func glow(pts: Array, r: float, color: Color, taper := 0.0) -> Dictionary:
	return {"pts": pts, "r": r, "color": color, "taper": taper}

## Points along a curved chain (dragon body).
static func chain(center: Vector3, radius: float, n: int, height: float) -> Array:
	var out: Array = []
	for i in n:
		var a := float(i) * 0.45
		out.append(center + Vector3(cos(a) * radius, height + sin(a * 1.3) * 1.2, sin(a) * radius))
	return out

static func walk(w: String, to: Vector3, d: float) -> Dictionary:
	return {"w": w, "do": "walk", "to": to, "d": d}

static func anim(w: String, a: String, d := 0.8) -> Dictionary:
	return {"w": w, "do": "anim", "a": a, "d": d}
