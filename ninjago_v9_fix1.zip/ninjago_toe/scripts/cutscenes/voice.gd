class_name Voice
extends RefCounted
## Arabic voice playback. Order: assets/voice/<line_id>.ogg|mp3|wav  ->  DisplayServer.tts_speak (temporary,
## system voice)  ->  subtitles only. line_id = "v_" + first 10 hex chars of md5(Arabic text), so ids stay
## stable when lines move; docs/VOICE_LINES.csv lists every id (tools/gen_voice_csv.py regenerates it).
## data/voice_map.json maps character ids (and "narrator") to a voice slot + pitch + rate.
## NO audio from the show is used or expected: record/generate your own voices.

const MAP_PATH := "res://data/voice_map.json"
static var _map: Dictionary = {}
static var _loaded := false
static var _player: AudioStreamPlayer

static func line_id(ar_text: String) -> String:
	return "v_" + ar_text.md5_text().substr(0, 10)

static func _load_map() -> void:
	if _loaded:
		return
	_loaded = true
	if not FileAccess.file_exists(MAP_PATH):
		return
	var f := FileAccess.open(MAP_PATH, FileAccess.READ)
	if f == null:
		return
	var p = JSON.parse_string(f.get_as_text())
	if typeof(p) == TYPE_DICTIONARY:
		_map = p

static func enabled() -> bool:
	return float(GameState.settings.get("voice", 1.0)) > 0.0

static func speak(char_id: String, text: String, lid: String) -> void:
	stop()
	if not enabled() or text == "":
		return
	_load_map()
	for ext in ["ogg", "mp3", "wav"]:
		var path := "res://assets/voice/%s.%s" % [lid, ext]
		if ResourceLoader.exists(path):
			var st = load(path)
			if st is AudioStream:
				if _player == null or not is_instance_valid(_player):
					_player = AudioStreamPlayer.new()
					var host: Node = Sfx
					host.add_child(_player)
				_player.stream = st
				_player.volume_db = linear_to_db(maxf(0.001, float(GameState.settings.get("voice", 1.0))))
				_player.play()
				return
	if not DisplayServer.has_feature(DisplayServer.FEATURE_TEXT_TO_SPEECH):
		return
	var voices: PackedStringArray = DisplayServer.tts_get_voices_for_language(Loc.lang)
	if voices.is_empty():
		return
	var cfg: Dictionary = _map.get(char_id, _map.get("narrator", {}))
	var slot := int(cfg.get("slot", 0))
	DisplayServer.tts_speak(text, voices[slot % voices.size()], int(100.0 * float(GameState.settings.get("voice", 1.0))),
		float(cfg.get("pitch", 1.0)), float(cfg.get("rate", 1.0)), 0, true)

static func stop() -> void:
	if _player != null and is_instance_valid(_player):
		_player.stop()
	if DisplayServer.has_feature(DisplayServer.FEATURE_TEXT_TO_SPEECH):
		DisplayServer.tts_stop()
