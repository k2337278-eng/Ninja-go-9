class_name CutscenePlayer
extends Node
## Data-driven cinematic runner (v4). Scene definitions live in cutscene_defs*.gd.
##   def  = {"mood": String, "music": String, "cast": [cast], "shots": [shot]}
##   cast = {"id": key, "char": CharacterDB id (optional), "cfg": Minifig cfg (optional), "pos": Vector3, "yaw": float}
##   shot = {"f": camera start, "l": look start, "t": camera end (optional), "l2": look end (optional),
##           "mv": "static"|"dolly"|"orbit"|"crane"|"hand", "arc": orbit degrees, "fov": float, "d": seconds,
##           "ez": "sine"|"cubic"|"lin", "say": [[who, en, ar]], "act": [action], "fx": "fade_in"|"fade_out"|"flash"|"shake"}
##   prop = {"pts": [Vector3], "r": radius, "color": Color}  (glowing spheres: dragon body, scattered pieces, a scroll)
##   action = {"w": cast id, "do": "walk"|"face"|"anim"|"pos", "to": Vector3, "at": Vector3|cast id, "d": secs, "a": anim name}
## Real fighters (player + companions) are hidden while it plays; puppets (Minifig) act instead.
## Everything is built from primitives; nothing is copied from the show.

var isl: Node3D
var skip := false
var puppets := {}
var props: Array = []
var walkers: Array = []
var revert: Array = []
var _layer: CanvasLayer
var _top: ColorRect
var _bot: ColorRect
var _fade: ColorRect
var _sub_name: Label
var _sub_txt: Label
var _sub_panel: PanelContainer
var _hidden: Array = []
var _saved := {}
var _running := false

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS

# ------------------------------------------------------------------ run ----
func run(def: Dictionary) -> void:
	_running = true
	_build_ui()
	_hide_fighters()
	_apply_mood(str(def.get("mood", "")))
	var music := str(def.get("music", ""))
	if music != "":
		Sfx.play_theme(music)
	_spawn_cast(def.get("cast", []))
	var tw := create_tween()
	tw.tween_property(_top, "offset_bottom", 64.0, 0.5)
	tw.parallel().tween_property(_bot, "offset_top", -64.0, 0.5)
	var first := true
	for shot in def.get("shots", []):
		if skip:
			break
		await _run_shot(shot as Dictionary, first)
		first = false
	await _cleanup()

func _on_skip() -> void:
	skip = true

# ------------------------------------------------------------------ ui -----
func _build_ui() -> void:
	_layer = CanvasLayer.new()
	_layer.layer = 30
	add_child(_layer)
	_top = ColorRect.new()
	_top.color = Color.BLACK
	_top.anchor_right = 1.0
	_top.offset_bottom = 0.0
	_top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_layer.add_child(_top)
	_bot = ColorRect.new()
	_bot.color = Color.BLACK
	_bot.anchor_top = 1.0
	_bot.anchor_right = 1.0
	_bot.anchor_bottom = 1.0
	_bot.offset_top = 0.0
	_bot.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_layer.add_child(_bot)
	_sub_panel = PanelContainer.new()
	_sub_panel.anchor_left = 0.1
	_sub_panel.anchor_right = 0.9
	_sub_panel.anchor_top = 0.72
	_sub_panel.anchor_bottom = 0.9
	_sub_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.0, 0.0, 0.0, 0.55)
	sb.set_corner_radius_all(10)
	sb.set_content_margin_all(10)
	_sub_panel.add_theme_stylebox_override("panel", sb)
	_sub_panel.visible = false
	_layer.add_child(_sub_panel)
	var vb := VBoxContainer.new()
	_sub_panel.add_child(vb)
	_sub_name = Label.new()
	_sub_name.add_theme_font_size_override("font_size", 26)
	_sub_name.add_theme_color_override("font_color", Color(1, 0.85, 0.3))
	vb.add_child(_sub_name)
	_sub_txt = Label.new()
	_sub_txt.add_theme_font_size_override("font_size", 28)
	_sub_txt.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	vb.add_child(_sub_txt)
	_fade = ColorRect.new()
	_fade.color = Color(0, 0, 0, 0)
	_fade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_layer.add_child(_fade)
	var b := Button.new()
	b.text = Loc.pick(["Skip", "تخطي"])
	b.add_theme_font_size_override("font_size", 26)
	b.anchor_left = 1.0
	b.anchor_right = 1.0
	b.offset_left = -170
	b.offset_right = -20
	b.offset_top = 74
	b.offset_bottom = 134
	b.pressed.connect(_on_skip)
	_layer.add_child(b)

# ----------------------------------------------------------------- world ---
func _hide_fighters() -> void:
	for n in get_tree().get_nodes_in_group("fighters"):
		var f := n as Fighter
		if f != null and f.team == "player" and f.visible:
			f.visible = false
			_hidden.append(f)

func _spawn_cast(cast: Array) -> void:
	for c in cast:
		var cd: Dictionary = c
		if cd.has("pts"):
			_spawn_spheres(cd)
			continue
		var cfg: Dictionary = {}
		if cd.has("char"):
			var id := str(cd["char"])
			cfg = {"suit": CharacterDB.DATA[id]["suit"], "style": "ninja", "weapon": Minifig.WEAPONS.get(id, "")}
		if cd.has("cfg"):
			for k in (cd["cfg"] as Dictionary).keys():
				cfg[k] = cd["cfg"][k]
		var m := Minifig.new()
		isl.add_child(m)
		m.build(cfg)
		m.position = cd["pos"] as Vector3
		m.rotation.y = float(cd.get("yaw", 0.0))
		puppets[str(cd["id"])] = m

func _spawn_spheres(cd: Dictionary) -> void:
	var col: Color = cd.get("color", Color(0.9, 0.9, 1.0))
	var mat := StandardMaterial3D.new()
	mat.albedo_color = col
	mat.emission_enabled = true
	mat.emission = col
	var pts: Array = cd["pts"]
	for i in pts.size():
		var mi := MeshInstance3D.new()
		var sm := SphereMesh.new()
		sm.radius = float(cd.get("r", 0.5)) * (1.0 - 0.5 * float(i) / maxf(1.0, pts.size()) * float(cd.get("taper", 0.0)))
		sm.height = sm.radius * 2.0
		sm.radial_segments = 8
		sm.rings = 4
		sm.material = mat
		mi.mesh = sm
		mi.position = pts[i] as Vector3
		mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		isl.add_child(mi)
		props.append(mi)

func _apply_mood(m: String) -> void:
	if m == "" or isl.sun == null:
		return
	var sky: ProceduralSkyMaterial = isl.sky_mat
	_saved = {"sun_c": isl.sun.light_color, "sun_e": isl.sun.light_energy, "fog": isl.env.fog_enabled,
		"fog_c": isl.env.fog_light_color, "fog_d": isl.env.fog_density,
		"top": sky.sky_top_color, "hor": sky.sky_horizon_color}
	var top := Color(0.385, 0.454, 0.55)
	var hor := Color(0.646, 0.654, 0.67)
	var fog_c := Color(0.5, 0.5, 0.55)
	var fog_d := 0.0
	var sun_c := Color(1, 1, 1)
	var sun_e := 1.1
	match m:
		"dusk":
			top = Color(0.25, 0.1, 0.35)
			hor = Color(0.9, 0.4, 0.25)
			fog_c = Color(0.8, 0.4, 0.3)
			fog_d = 0.006
			sun_c = Color(1.0, 0.6, 0.4)
			sun_e = 0.8
		"night":
			top = Color(0.02, 0.03, 0.1)
			hor = Color(0.08, 0.1, 0.22)
			fog_c = Color(0.05, 0.06, 0.14)
			fog_d = 0.01
			sun_c = Color(0.5, 0.6, 1.0)
			sun_e = 0.35
		"dawn":
			top = Color(0.35, 0.4, 0.65)
			hor = Color(1.0, 0.75, 0.5)
			fog_c = Color(1.0, 0.8, 0.6)
			fog_d = 0.005
			sun_c = Color(1.0, 0.85, 0.65)
		"gloom":
			top = Color(0.2, 0.22, 0.28)
			hor = Color(0.4, 0.4, 0.45)
			fog_c = Color(0.35, 0.35, 0.4)
			fog_d = 0.012
			sun_e = 0.6
		"snow":
			top = Color(0.62, 0.72, 0.85)
			hor = Color(0.9, 0.94, 1.0)
			fog_c = Color(0.85, 0.9, 0.95)
			fog_d = 0.012
			sun_c = Color(0.85, 0.92, 1.0)
			sun_e = 0.8
		"digi":
			top = Color(0.0, 0.2, 0.28)
			hor = Color(0.0, 0.55, 0.6)
			fog_c = Color(0.0, 0.5, 0.55)
			fog_d = 0.008
			sun_c = Color(0.5, 1.0, 1.0)
	sky.sky_top_color = top
	sky.sky_horizon_color = hor
	isl.env.fog_enabled = fog_d > 0.0
	isl.env.fog_light_color = fog_c
	isl.env.fog_density = fog_d
	isl.sun.light_color = sun_c
	isl.sun.light_energy = sun_e

func _restore_mood() -> void:
	if _saved.is_empty():
		return
	var sky: ProceduralSkyMaterial = isl.sky_mat
	isl.sun.light_color = _saved["sun_c"]
	isl.sun.light_energy = float(_saved["sun_e"])
	isl.env.fog_enabled = bool(_saved["fog"])
	isl.env.fog_light_color = _saved["fog_c"]
	isl.env.fog_density = float(_saved["fog_d"])
	sky.sky_top_color = _saved["top"]
	sky.sky_horizon_color = _saved["hor"]
	_saved = {}

# ------------------------------------------------------------------ shots --
func _ease(k: float, mode: String) -> float:
	match mode:
		"lin":
			return k
		"cubic":
			return k * k * (3.0 - 2.0 * k)
	return 0.5 - 0.5 * cos(PI * k)

func _say_time(txt: String) -> float:
	return maxf(1.8, txt.length() / 15.0)

func _run_shot(shot: Dictionary, first: bool) -> void:
	var from: Vector3 = shot["f"]
	var look: Vector3 = shot["l"]
	var to: Vector3 = shot.get("t", from)
	var look2: Vector3 = shot.get("l2", look)
	var mv := str(shot.get("mv", "static"))
	var fov := float(shot.get("fov", 60.0))
	var says: Array = shot.get("say", [])
	var total := float(shot.get("d", 4.0))
	var spans: Array = []
	var acc := 0.0
	for s in says:
		var txt: String = Loc.pick([str(s[1]), str(s[2])])
		spans.append(acc + _say_time(txt))
		acc += _say_time(txt)
	total = maxf(total, acc + 0.3)
	if first:
		isl._cine_start(from, look)
	var fx := str(shot.get("fx", ""))
	if fx == "fade_in":
		_fade.color.a = 1.0
		create_tween().tween_property(_fade, "color:a", 0.0, 0.8)
	elif fx == "fade_out":
		create_tween().tween_property(_fade, "color:a", 1.0, maxf(0.6, total * 0.8))
	elif fx == "flash":
		_fade.color = Color(1, 1, 1, 0.9)
		create_tween().tween_property(_fade, "color:a", 0.0, 0.5)
	elif fx == "shake":
		Effects.shake(isl, 0.5)
	if shot.has("mood"):
		_restore_mood()
		_apply_mood(str(shot["mood"]))
	if mv != "static" and mv != "hand" and not first:
		Sfx.play("whoosh")
	if fx == "flash":
		Sfx.play("elem")
	elif fx == "shake":
		Sfx.play("impact")
	if shot.has("sfx"):
		Sfx.play(str(shot["sfx"]))
	for a in shot.get("act", []):
		_do_act(a as Dictionary)
	var si := -1
	var t := 0.0
	var radius := Vector2(from.x - look.x, from.z - look.z).length()
	var a0 := atan2(from.z - look.z, from.x - look.x)
	while t < total and not skip:
		await get_tree().process_frame
		var dt := get_process_delta_time()
		t += dt
		var k := clampf(t / total, 0.0, 1.0)
		var e := _ease(k, str(shot.get("ez", "sine")))
		var pos := from
		var lk := look
		match mv:
			"dolly", "crane":
				pos = from.lerp(to, e)
				lk = look.lerp(look2, e)
			"orbit":
				var ang := a0 + deg_to_rad(float(shot.get("arc", 40.0))) * e
				pos = Vector3(look.x + cos(ang) * radius, lerpf(from.y, to.y, e), look.z + sin(ang) * radius)
			"hand":
				pos = from + Vector3(sin(t * 1.7) * 0.07, sin(t * 2.3) * 0.05, cos(t * 1.3) * 0.06)
				lk = look + Vector3(sin(t * 2.1) * 0.05, 0.0, cos(t * 1.9) * 0.05)
		isl.cine.global_position = pos
		isl._cine_look = lk
		isl.cine.fov = lerpf(isl.cine.fov, fov, 1.0 - exp(-4.0 * dt))
		var want := spans.size()
		for i in spans.size():
			if t < float(spans[i]):
				want = i
				break
		if want != si:
			si = want
			if si < says.size():
				var s: Array = says[si]
				_sub_name.text = _speaker_name(str(s[0]))
				_sub_txt.text = Loc.pick([str(s[1]), str(s[2])])
				_sub_panel.visible = true
				Voice.speak(str(s[0]), Loc.pick([str(s[1]), str(s[2])]), Voice.line_id(str(s[2])))
			else:
				_sub_panel.visible = false
	_sub_panel.visible = false
	Voice.stop()

func _speaker_name(id: String) -> String:
	if id == "narrator":
		return Loc.t("narrator")
	if ChapterBase.NAMES.has(id):
		return Loc.pick(ChapterBase.NAMES[id])
	return CharacterDB.name_of(id)

# ---------------------------------------------------------------- actors ---
func _target_pos(at) -> Vector3:
	if at is Vector3:
		return at
	var m: Minifig = puppets.get(str(at))
	return m.position if m != null else Vector3.ZERO

func _yaw_to(from: Vector3, to: Vector3) -> float:
	var d := to - from
	return atan2(-d.x, -d.z)

func _do_act(a: Dictionary) -> void:
	var m: Minifig = puppets.get(str(a["w"]))
	if m == null:
		return
	match str(a["do"]):
		"walk":
			walkers.append({"p": m, "from": m.position, "to": a["to"], "t": 0.0, "d": maxf(0.1, float(a.get("d", 2.0)))})
		"face":
			m.rotation.y = _yaw_to(m.position, _target_pos(a["at"]))
		"pos":
			m.position = a["to"]
		"anim":
			m.play(str(a["a"]), float(a.get("d", 0.6)))
			match str(a["a"]):
				"heavy":
					Sfx.play("thud")
				"cast":
					Sfx.play("elem")
				"stagger":
					Sfx.play("hurt")
			revert.append({"p": m, "left": float(a.get("d", 0.6)) + 0.3})

func _process(delta: float) -> void:
	if not _running:
		return
	var moving: Array = []
	for w in walkers:
		var m: Minifig = w["p"]
		if not is_instance_valid(m):
			continue
		w["t"] = float(w["t"]) + delta
		var k := clampf(float(w["t"]) / float(w["d"]), 0.0, 1.0)
		var np: Vector3 = (w["from"] as Vector3).lerp(w["to"] as Vector3, k)
		if k < 1.0:
			m.rotation.y = _yaw_to(m.position, np) if (np - m.position).length() > 0.001 else m.rotation.y
			moving.append(m)
		m.position = np
	walkers = walkers.filter(func(w): return float(w["t"]) < float(w["d"]))
	for r in revert:
		r["left"] = float(r["left"]) - delta
		if float(r["left"]) <= 0.0 and is_instance_valid(r["p"]):
			(r["p"] as Minifig).play("idle")
	revert = revert.filter(func(r): return float(r["left"]) > 0.0)
	for id in puppets.keys():
		var pm: Minifig = puppets[id]
		pm.update_anim(delta, 0.8 if moving.has(pm) else 0.0, false)

# --------------------------------------------------------------- cleanup ---
func _cleanup() -> void:
	_running = false
	Voice.stop()
	Sfx.stop_theme()
	if skip:
		_fade.color.a = 1.0
	for id in puppets.keys():
		if is_instance_valid(puppets[id]):
			puppets[id].queue_free()
	puppets.clear()
	for pr in props:
		if is_instance_valid(pr):
			pr.queue_free()
	props.clear()
	for f in _hidden:
		if is_instance_valid(f):
			f.visible = true
	_hidden.clear()
	_restore_mood()
	isl.cine.fov = 75.0
	if skip:
		var tw := create_tween()
		tw.tween_property(_fade, "color:a", 0.0, 0.4)
		await tw.finished
	_layer.queue_free()
