class_name Cutscenes
extends RefCounted
## Registry of REAL cinematics. A hook id with a definition in CutsceneDefs plays through CutscenePlayer;
## any other hook id still plays the placeholder card (Island.play_hook). Hooks list: docs/CUTSCENE_HOOKS.md.
## To add a scene: add a def (see CutscenePlayer header) to CutsceneDefs, nothing else to register.

static func has(id: String) -> bool:
	return CutsceneDefs.has(id)

static func play(isl: Node, id: String) -> void:
	var cp := CutscenePlayer.new()
	cp.isl = isl
	isl.add_child(cp)
	await cp.run(CutsceneDefs.get_def(id))
	cp.queue_free()
