class_name CutsceneDefsD
extends RefCounted
## Scenes for chapters 6-8. Original wording. Dragon/transformation visuals are glowing-sphere placeholders (VERIFY vs the show).

static func build() -> Dictionary:
	var out := {}
	var cfg_chen := {"suit": Color(0.45, 0.15, 0.5), "style": "bare", "hair": Color(0.1, 0.1, 0.1), "scale": 1.25}
	var cfg_clouse := {"suit": Color(0.35, 0.2, 0.4), "style": "bare", "hair": Color(0.1, 0.1, 0.12), "scale": 1.4}
	var cfg_garm := {"suit": Color(0.15, 0.1, 0.15), "style": "bare", "hair": Color(0.1, 0.05, 0.05), "scale": 1.3}
	var cfg_skylor := {"suit": CharacterDB.DATA["skylor"]["suit"], "style": "ninja", "weapon": "fan"}
	var cfg_guard := {"suit": Color(0.25, 0.25, 0.3), "style": "bare", "hair": Color(0.1, 0.1, 0.1)}

	out["ch06_energy_dragon"] = {"mood": "dusk", "music": "action", "cast": [
		CutsceneDefs.ch("lloyd", "lloyd", Vector3(30, 0.2, -22), Vector3(30, 5, -30)),
		CutsceneDefs.glow(CutsceneDefs.chain(Vector3(30, 0, -22), 5.0, 16, 4.0), 0.8, Color(0.4, 1.0, 0.5), 0.6)], "shots": [
		CutsceneDefs.sh(Vector3(24, 1.4, -17), Vector3(30, 1.5, -22), 4.5, "hand", 45, {"fx": "fade_in", "say": [
			CutsceneDefs.Q("lloyd", "Something is waking up inside me.", "شيء ما يستيقظ بداخلي.")]}),
		CutsceneDefs.sh(Vector3(30, 14, -10), Vector3(30, 4, -22), 6.0, "orbit", 62, {"arc": 100.0, "fx": "flash", "say": [
			CutsceneDefs.Q("narrator", "A dragon of green light rises, coiling over the clearing.", "ينهض تنين من ضوء أخضر، ملتفًّا فوق المساحة.")]}),
		CutsceneDefs.sh(Vector3(30, 1.5, -18), Vector3(30, 7, -24), 4.5, "crane", 70, {"t": Vector3(30, 3, -19), "fx": "shake"}),
		CutsceneDefs.sh(Vector3(36, 2, -16), Vector3(30, 1.6, -22), 4.0, "static", 50, {"say": [
			CutsceneDefs.Q("lloyd", "It is mine. It was always mine.", "إنه لي. كان لي دائمًا.")]})]}

	out["ch06_garmadon_past"] = {"mood": "dusk", "music": "sad", "cast": [
		CutsceneDefs.fig("chen", cfg_chen, Vector3(28, 0.2, -16), Vector3(32, 0.2, -18)), CutsceneDefs.fig("clouse", cfg_clouse, Vector3(30, 0.2, -19), Vector3(32, 0.2, -18)),
		CutsceneDefs.fig("garm", cfg_garm, Vector3(34, 0.2, -18), Vector3(30, 0.2, -18)), CutsceneDefs.ch("lloyd", "lloyd", Vector3(24, 0.2, -12), Vector3(30, 0.2, -18))], "shots": [
		CutsceneDefs.sh(Vector3(26, 4, -8), Vector3(31, 1.5, -18), 5.5, "dolly", 52, {"t": Vector3(27, 3, -10), "fx": "fade_in", "say": [
			CutsceneDefs.Q("narrator", "Long ago, three young men stood on one side of a war.", "منذ زمن بعيد، وقف ثلاثة شبّان في صف واحد من حرب.")]}),
		CutsceneDefs.sh(Vector3(30, 1.7, -14), Vector3(31, 1.5, -18), 5.0, "orbit", 48, {"arc": 70.0, "say": [
			CutsceneDefs.Q("narrator", "Their enemy then was the Serpentine, the villains of that age.", "وكان عدوّهم حينها السيربنتين، أشرار ذلك العصر.")]}),
		CutsceneDefs.sh(Vector3(22, 1.7, -10), Vector3(24, 1.6, -12), 4.0, "hand", 40, {"say": [
			CutsceneDefs.Q("lloyd", "My father stood with them?", "أبي كان معهم؟")]}),
		CutsceneDefs.sh(Vector3(31, 6, -26), Vector3(31, 1.5, -18), 4.0, "crane", 55, {"t": Vector3(33, 11, -30), "fx": "fade_out"})]}

	out["ch06_misako_letter"] = {"mood": "dawn", "music": "mystery", "cast": [
		CutsceneDefs.ch("lloyd", "lloyd", Vector3(28, 0.2, -12), Vector3(30, 1.4, -14)), CutsceneDefs.ch("kai", "kai", Vector3(26, 0.2, -13), Vector3(30, 1.4, -14)),
		CutsceneDefs.ch("jay", "jay", Vector3(27, 0.2, -10), Vector3(30, 1.4, -14)), CutsceneDefs.glow([Vector3(30, 1.2, -14)], 0.35, Color(1.0, 0.95, 0.7))], "shots": [
		CutsceneDefs.sh(Vector3(33, 2.6, -8), Vector3(29, 1.4, -13), 6.0, "dolly", 52, {"t": Vector3(31, 2.2, -9), "fx": "fade_in", "say": [
			CutsceneDefs.Q("narrator", "Folded into an old book, a letter in Misako's handwriting.", "مطوية داخل كتاب قديم، رسالة بخط ميساكو.")]}),
		CutsceneDefs.sh(Vector3(30, 1.7, -12), Vector3(30, 1.2, -14), 5.5, "dolly", 36, {"t": Vector3(30, 1.5, -12.8)}),
		CutsceneDefs.sh(Vector3(25, 1.6, -10), Vector3(27, 1.5, -11), 5.5, "hand", 40, {"say": [
			CutsceneDefs.Q("jay", "Whatever is in there, it changes how we see him.", "مهما كان فيها، فهي تغيّر نظرتنا إليه.")]})]}

	out["ch07_kai_betrays"] = {"mood": "dusk", "music": "sad", "cast": [
		CutsceneDefs.ch("kai", "kai", Vector3(-2, 0.2, -38), Vector3(-10, 0.2, -30)), CutsceneDefs.ch("jay", "jay", Vector3(-10, 0.2, -30), Vector3(-2, 0.2, -38)),
		CutsceneDefs.ch("lloyd", "lloyd", Vector3(-12, 0.2, -31), Vector3(-2, 0.2, -38)), CutsceneDefs.fig("chen", cfg_chen, Vector3(4, 0.2, -40), Vector3(-2, 0.2, -38))], "shots": [
		CutsceneDefs.sh(Vector3(-7, 1.7, -33), Vector3(-2, 1.6, -38), 5.0, "hand", 42, {"say": [
			CutsceneDefs.Q("jay", "Kai? Kai, come back here.", "كاي؟ كاي، عد إلى هنا.")]}),
		CutsceneDefs.sh(Vector3(-4, 1.6, -41), Vector3(-2, 1.6, -38), 5.0, "hand", 38, {"act": [CutsceneDefs.walk("kai", Vector3(2, 0.2, -39), 3.5)], "say": [
			CutsceneDefs.Q("kai", "I will be back. I need answers first.", "سأعود. أحتاج إلى إجابات أولًا.")]}),
		CutsceneDefs.sh(Vector3(-14, 2, -26), Vector3(-10, 1.5, -30), 4.0, "static", 44, {"say": [
			CutsceneDefs.Q("narrator", "His friends watch him walk to the other side.", "يراقب أصدقاؤه وهو يمشي إلى الجهة الأخرى.")]}),
		CutsceneDefs.sh(Vector3(0, 9, -26), Vector3(0, 1.5, -38), 4.0, "crane", 55, {"t": Vector3(0, 13, -22), "fx": "fade_out"})]}

	out["ch07_staff_break"] = {"mood": "night", "music": "tense", "cast": [
		CutsceneDefs.ch("kai", "kai", Vector3(0, 0.2, -38), Vector3(0, 2, -41)), CutsceneDefs.glow([Vector3(0, 1.6, -41)], 0.5, Color(0.7, 0.2, 0.9))], "shots": [
		CutsceneDefs.sh(Vector3(6, 2, -33), Vector3(0, 1.6, -40), 5.0, "dolly", 50, {"t": Vector3(4, 1.8, -36), "fx": "fade_in", "say": [
			CutsceneDefs.Q("narrator", "The staff hums, and its power crawls up Kai's arm.", "تطنّ العصا، وتزحف قوتها إلى ذراع كاي.")]}),
		CutsceneDefs.sh(Vector3(0, 1.4, -36.5), Vector3(0, 1.6, -41), 4.5, "hand", 40, {"act": [CutsceneDefs.anim("kai", "heavy", 0.9)], "say": [
			CutsceneDefs.Q("kai", "No more. This ends now.", "لا مزيد. هذا ينتهي الآن.")]}),
		CutsceneDefs.sh(Vector3(-5, 4, -30), Vector3(0, 1.6, -41), 4.0, "orbit", 55, {"arc": 60.0, "fx": "flash"}),
		CutsceneDefs.sh(Vector3(0, 6, -28), Vector3(0, 1.6, -41), 3.5, "static", 60, {"fx": "shake"})]}

	out["ch07_powers_return"] = {"mood": "dawn", "music": "hope", "cast": [
		CutsceneDefs.ch("kai", "kai", Vector3(0, 0.2, -36), Vector3(0, 8, -40)),
		CutsceneDefs.glow([Vector3(-6, 5, -38), Vector3(-3, 7, -40), Vector3(0, 9, -42), Vector3(3, 7, -40), Vector3(6, 5, -38)], 0.55, Color(1.0, 0.85, 0.4))], "shots": [
		CutsceneDefs.sh(Vector3(0, 3, -26), Vector3(0, 7, -40), 6.0, "crane", 62, {"t": Vector3(0, 10, -24), "fx": "fade_in", "say": [
			CutsceneDefs.Q("narrator", "The stolen powers stream out of the broken staff like sparks.", "تنساب القوى المسروقة من العصا المكسورة كالشرر.")]}),
		CutsceneDefs.sh(Vector3(14, 3, -20), Vector3(8, 4, -8), 5.5, "dolly", 55, {"t": Vector3(12, 4, -14), "say": [
			CutsceneDefs.Q("narrator", "Each one finds its master again.", "وتجد كل واحدة سيّدها من جديد.")]}),
		CutsceneDefs.sh(Vector3(-2, 1.6, -33), Vector3(0, 1.6, -36), 5.5, "hand", 42, {"say": [
			CutsceneDefs.Q("kai", "I broke it. I really broke it.", "كسرتها. كسرتها فعلًا.")]})]}

	out["ch08_kai_dragon"] = {"mood": "dusk", "music": "action", "cast": [
		CutsceneDefs.ch("kai", "kai", Vector3(0, 0.2, 2), Vector3(0, 6, -6)), CutsceneDefs.glow(CutsceneDefs.chain(Vector3(0, 0, 2), 6.0, 18, 4.5), 0.85, Color(1.0, 0.45, 0.1), 0.6)], "shots": [
		CutsceneDefs.sh(Vector3(-5, 1.5, 6), Vector3(0, 1.6, 2), 4.5, "hand", 42, {"fx": "fade_in", "say": [
			CutsceneDefs.Q("kai", "Come on. I know you are in there.", "هيا. أعرف أنك هناك.")]}),
		CutsceneDefs.sh(Vector3(0, 16, 12), Vector3(0, 4, 2), 6.0, "orbit", 62, {"arc": 100.0, "fx": "flash", "say": [
			CutsceneDefs.Q("narrator", "A dragon of fire answers, wrapping the arena in light.", "يجيب تنين من نار، ويلفّ الساحة بالضوء.")]}),
		CutsceneDefs.sh(Vector3(0, 1.5, 4), Vector3(0, 7, 0), 4.5, "crane", 72, {"t": Vector3(0, 3, 5), "fx": "shake"}),
		CutsceneDefs.sh(Vector3(6, 2, 8), Vector3(0, 1.6, 2), 3.5, "static", 48, {"say": [
			CutsceneDefs.Q("kai", "There you are.", "ها أنت ذا.")]})]}

	return out
