class_name CutsceneDefsE
extends RefCounted
## Scenes for chapters 9-10. Original wording. v6: ch10 follows STORY_SPEC v2 (Pythor's plan, Garmadon's
## sacrifice, the generals' curse, the statue). VERIFY: which Serpentine/generals appear (generic), Skylor's goodbye.

static func build() -> Dictionary:
	var out := {}
	var cfg_chen := {"suit": Color(0.45, 0.15, 0.5), "style": "bare", "hair": Color(0.1, 0.1, 0.1), "scale": 1.5}
	var cfg_ana := {"suit": Color(0.3, 0.12, 0.4), "style": "ninja", "hat": Color(0.15, 0.4, 0.15)}
	var cfg_garm := {"suit": Color(0.15, 0.1, 0.15), "style": "bare", "hair": Color(0.1, 0.05, 0.05), "scale": 1.3}
	var cfg_py := {"suit": CharacterDB.DATA["pythor"]["suit"], "style": "ninja"}
	var cfg_py_small := {"suit": CharacterDB.DATA["pythor"]["suit"], "style": "ninja", "scale": 0.6}
	var cfg_gen := {"suit": CharacterDB.DATA["general"]["suit"], "style": "ninja", "scale": 1.2}
	var cfg_statue := {"suit": Color(0.55, 0.55, 0.58), "style": "bare", "hair": Color(0.45, 0.45, 0.48), "scale": 3.0}
	var cfg_spirit := {"suit": Color(0.8, 0.75, 0.5), "style": "ninja", "scale": 1.8}
	var cfg_skylor := {"suit": CharacterDB.DATA["skylor"]["suit"], "style": "ninja", "weapon": "fan"}

	out["ch09_race_begins"] = {"mood": "dusk", "music": "action", "cast": [
		CutsceneDefs.ch("lloyd", "lloyd", Vector3(-44, 0.2, 40), Vector3(-58, 0, 16)), CutsceneDefs.ch("kai", "kai", Vector3(-42, 0.2, 41), Vector3(-58, 0, 16)),
		CutsceneDefs.ch("jay", "jay", Vector3(-46, 0.2, 41), Vector3(-58, 0, 16)), CutsceneDefs.ch("zane", "zane", Vector3(-43, 0.2, 43), Vector3(-58, 0, 16)),
		CutsceneDefs.fig("a1", cfg_ana, Vector3(-30, 0.2, 44), Vector3(-58, 0, 16)), CutsceneDefs.fig("a2", cfg_ana, Vector3(-28, 0.2, 46), Vector3(-58, 0, 16))], "shots": [
		CutsceneDefs.sh(Vector3(-34, 8, 52), Vector3(-44, 1.5, 40), 5.0, "crane", 58, {"t": Vector3(-38, 4, 47), "fx": "fade_in", "say": [
			CutsceneDefs.Q("narrator", "Two groups stand at the edge of the city, both racing for the same prison.", "مجموعتان تقفان عند حافة المدينة، وكلتاهما تتسابق إلى السجن نفسه.")]}),
		CutsceneDefs.sh(Vector3(-36, 1.8, 46), Vector3(-29, 1.6, 45), 4.5, "hand", 42, {"act": [CutsceneDefs.walk("a1", Vector3(-40, 0.2, 38), 3.5), CutsceneDefs.walk("a2", Vector3(-38, 0.2, 40), 3.5)]}),
		CutsceneDefs.sh(Vector3(-40, 1.6, 44), Vector3(-44, 1.6, 40), 4.5, "static", 45, {"say": [
			CutsceneDefs.Q("lloyd", "Whoever reaches Pythor first decides how this ends.", "من يصل إلى بايثور أولًا يقرّر كيف ينتهي هذا.")]}),
		CutsceneDefs.sh(Vector3(-44, 1.2, 38), Vector3(-58, 1.5, 16), 4.0, "dolly", 60, {"t": Vector3(-46, 1.2, 34), "act": [
			CutsceneDefs.walk("lloyd", Vector3(-52, 0.2, 28), 3.8), CutsceneDefs.walk("kai", Vector3(-50, 0.2, 29), 3.8), CutsceneDefs.walk("jay", Vector3(-54, 0.2, 29), 3.8)], "fx": "fade_out"})]}

	out["ch09_pythor_reached"] = {"mood": "gloom", "music": "mystery", "cast": [
		CutsceneDefs.fig("py", cfg_py_small, Vector3(-48, 0.2, -60), Vector3(-48, 0.2, -50)), CutsceneDefs.ch("lloyd", "lloyd", Vector3(-48, 0.2, -50), Vector3(-48, 0.2, -60)),
		CutsceneDefs.ch("kai", "kai", Vector3(-45, 0.2, -49), Vector3(-48, 0.2, -60)), CutsceneDefs.ch("zane", "zane", Vector3(-51, 0.2, -49), Vector3(-48, 0.2, -60))], "shots": [
		CutsceneDefs.sh(Vector3(-40, 5, -38), Vector3(-48, 1.5, -58), 5.5, "crane", 55, {"t": Vector3(-42, 3, -46), "fx": "fade_in", "say": [
			CutsceneDefs.Q("narrator", "In the deepest cell of the Kryptarium, something small moves in the dark.", "في أعمق زنزانة في Kryptarium، يتحرك شيء صغير في العتمة.")]}),
		CutsceneDefs.sh(Vector3(-48, 1.4, -56), Vector3(-48, 1.7, -60), 4.5, "dolly", 40, {"t": Vector3(-48, 1.5, -57.5), "say": [
			CutsceneDefs.Q("pythor", "Visitors. How unusual. Nobody comes here willingly.", "زوّار. كم هذا غريب. لا أحد يأتي إلى هنا طوعًا.")]}),
		CutsceneDefs.sh(Vector3(-44, 1.7, -47), Vector3(-48, 1.6, -50), 4.5, "hand", 40, {"say": [
			CutsceneDefs.Q("lloyd", "We are not here for old grudges. We need you.", "لسنا هنا من أجل الضغائن القديمة. نحتاج إليك.")]}),
		CutsceneDefs.sh(Vector3(-48, 6, -44), Vector3(-48, 1.5, -57), 4.0, "orbit", 55, {"arc": 60.0})]}

	out["ch10_army"] = {"mood": "dusk", "music": "action", "cast": [
		CutsceneDefs.fig("a1", cfg_ana, Vector3(-6, 0.2, -16), Vector3(0, 0.2, 20)), CutsceneDefs.fig("a2", cfg_ana, Vector3(0, 0.2, -18), Vector3(0, 0.2, 20)),
		CutsceneDefs.fig("a3", cfg_ana, Vector3(6, 0.2, -16), Vector3(0, 0.2, 20)), CutsceneDefs.fig("a4", cfg_ana, Vector3(-3, 0.2, -22), Vector3(0, 0.2, 20)),
		CutsceneDefs.fig("a5", cfg_ana, Vector3(3, 0.2, -22), Vector3(0, 0.2, 20)), CutsceneDefs.ch("lloyd", "lloyd", Vector3(0, 0.2, 18), Vector3(0, 0.2, -16)),
		CutsceneDefs.ch("kai", "kai", Vector3(-3, 0.2, 19), Vector3(0, 0.2, -16)), CutsceneDefs.ch("jay", "jay", Vector3(3, 0.2, 19), Vector3(0, 0.2, -16))], "shots": [
		CutsceneDefs.sh(Vector3(0, 12, 22), Vector3(0, 3, -12), 5.5, "crane", 60, {"t": Vector3(0, 6, 14), "fx": "fade_in", "say": [
			CutsceneDefs.Q("narrator", "The Anacondrai pour into the arena in a dark, hissing line.", "يتدفق الأناكوندراي إلى الساحة في صف مظلم هسهس.")]}),
		CutsceneDefs.sh(Vector3(0, 1.4, -6), Vector3(0, 1.8, -16), 4.5, "dolly", 55, {"t": Vector3(0, 1.4, -9), "act": [
			CutsceneDefs.walk("a2", Vector3(0, 0.2, -10), 4.0), CutsceneDefs.walk("a1", Vector3(-6, 0.2, -9), 4.0), CutsceneDefs.walk("a3", Vector3(6, 0.2, -9), 4.0)]}),
		CutsceneDefs.sh(Vector3(-5, 1.7, 15), Vector3(0, 1.6, 18), 4.5, "hand", 42, {"say": [
			CutsceneDefs.Q("kai", "There are a lot of them.", "عددهم كبير."),
			CutsceneDefs.Q("jay", "I prefer to call it a lot of opportunities.", "أفضّل أن أسمّيها فرصًا كثيرة.")]}),
		CutsceneDefs.sh(Vector3(0, 2, 22), Vector3(0, 1.8, 18), 3.5, "static", 55, {"fx": "shake"})]}

	out["ch10_allies"] = {"mood": "dusk", "music": "hope", "cast": [
		CutsceneDefs.fig("g1", cfg_gen, Vector3(12, 0.2, 14), Vector3(0, 0.2, -4)), CutsceneDefs.fig("g2", cfg_gen, Vector3(8, 0.2, 18), Vector3(0, 0.2, -4)),
		CutsceneDefs.fig("g3", cfg_gen, Vector3(-12, 0.2, 16), Vector3(0, 0.2, -4)), CutsceneDefs.ch("lloyd", "lloyd", Vector3(0, 0.2, 4), Vector3(0, 0.2, -12)),
		CutsceneDefs.ch("kai", "kai", Vector3(-3, 0.2, 5), Vector3(0, 0.2, -12))], "shots": [
		CutsceneDefs.sh(Vector3(0, 6, 20), Vector3(0, 1.5, 6), 6.5, "crane", 58, {"t": Vector3(0, 3, 12), "fx": "fade_in", "say": [
			CutsceneDefs.Q("narrator", "A hiss rises from the edge of the arena. The old Serpentine tribes have come.", "يرتفع فحيح من حافة الساحة. لقد جاءت قبائل السيربنتين القديمة.")]}),
		CutsceneDefs.sh(Vector3(10, 1.8, 10), Vector3(12, 1.7, 14), 5.5, "hand", 42, {"act": [CutsceneDefs.walk("g1", Vector3(5, 0.2, 7), 4.0), CutsceneDefs.walk("g2", Vector3(3, 0.2, 9), 4.0), CutsceneDefs.walk("g3", Vector3(-5, 0.2, 8), 4.0)], "say": [
			CutsceneDefs.Q("general", "We fought you once. Today the greater enemy stands on the other side.", "قاتلناكم يومًا. واليوم العدو الأكبر يقف في الجهة الأخرى.")]}),
		CutsceneDefs.sh(Vector3(0, 1.6, 8), Vector3(0, 1.6, -4), 3.5, "static", 55, {"say": [
			CutsceneDefs.Q("lloyd", "Then stand with us, and let us finish this together.", "إذن قفوا معنا، ولننهِ هذا معًا.")]})]}

	out["ch10_pythor_idea"] = {"mood": "night", "music": "mystery", "cast": [
		CutsceneDefs.fig("py", cfg_py, Vector3(-8, 0.2, 10), Vector3(0, 0.2, 4)), CutsceneDefs.ch("lloyd", "lloyd", Vector3(0, 0.2, 4), Vector3(-8, 0.2, 10)),
		CutsceneDefs.fig("garm", cfg_garm, Vector3(6, 0.2, 4), Vector3(0, 0.2, 4)), CutsceneDefs.ch("kai", "kai", Vector3(3, 0.2, 5), Vector3(-8, 0.2, 10))], "shots": [
		CutsceneDefs.sh(Vector3(-2, 1.8, 14), Vector3(-8, 1.7, 10), 4.5, "dolly", 50, {"t": Vector3(-4, 1.8, 12), "fx": "fade_in", "act": [CutsceneDefs.walk("py", Vector3(-4, 0.2, 7), 3.5)], "say": [
			CutsceneDefs.Q("narrator", "Pythor staggers across the arena, hugging a heavy old book.", "يترنح بايثور عبر الساحة وهو يضمّ كتابًا قديمًا ثقيلًا.")]}),
		CutsceneDefs.sh(Vector3(-3, 1.6, 8), Vector3(-5, 1.7, 7), 5.0, "hand", 40, {"say": [
			CutsceneDefs.Q("pythor", "There is a spell in here that can end this war. It will cost someone everything.", "في هذا الكتاب تعويذة قادرة على إنهاء هذه الحرب. وستكلّف أحدًا كل شيء.")]}),
		CutsceneDefs.sh(Vector3(2, 1.6, 7), Vector3(0, 1.6, 4), 5.0, "static", 42, {"say": [
			CutsceneDefs.Q("pythor", "Someone must banish himself to the Cursed Realm and call back the first Anacondrai generals. They will deal with their own cultists.", "على أحدهم أن ينفي نفسه إلى عالم اللعنة ويستدعي جنرالات الأناكوندراي الأوائل. وهم سيتولّون أتباعهم بأنفسهم.")]}),
		CutsceneDefs.sh(Vector3(8, 1.6, 8), Vector3(6, 1.7, 4), 4.5, "dolly", 40, {"t": Vector3(7, 1.6, 6.5), "say": [
			CutsceneDefs.Q("garmadon", "Then that someone is me.", "إذن هذا الأحد هو أنا.")]})]}

	out["ch10_garmadon"] = {"mood": "night", "music": "sad", "cast": [
		CutsceneDefs.fig("garm", cfg_garm, Vector3(0, 0.2, -10), Vector3(0, 0.2, -16)), CutsceneDefs.fig("chen", cfg_chen, Vector3(0, 0.2, -18), Vector3(0, 0.2, -10)),
		CutsceneDefs.fig("a1", cfg_ana, Vector3(-6, 0.2, -20), Vector3(0, 0.2, -10)), CutsceneDefs.fig("a2", cfg_ana, Vector3(6, 0.2, -20), Vector3(0, 0.2, -10)),
		CutsceneDefs.fig("s1", cfg_spirit, Vector3(-5, 0.2, -13), Vector3(0, 0.2, -18)), CutsceneDefs.fig("s2", cfg_spirit, Vector3(5, 0.2, -13), Vector3(0, 0.2, -18)),
		CutsceneDefs.ch("lloyd", "lloyd", Vector3(0, 0.2, 6), Vector3(0, 0.2, -10)), CutsceneDefs.glow(CutsceneDefs.chain(Vector3(0, 0, -13), 3.0, 12, 2.0), 0.5, Color(0.7, 0.4, 1.0), 0.4)], "shots": [
		CutsceneDefs.sh(Vector3(0, 8, 18), Vector3(0, 2, -12), 5.5, "crane", 58, {"t": Vector3(0, 4, 8), "fx": "fade_in", "say": [
			CutsceneDefs.Q("narrator", "Garmadon opens the old book and begins to read.", "يفتح غارمادون الكتاب القديم ويبدأ بالقراءة.")]}),
		CutsceneDefs.sh(Vector3(-4, 1.6, -7), Vector3(0, 1.7, -10), 5.0, "hand", 40, {"say": [
			CutsceneDefs.Q("garmadon", "Look after your mother. And live, Lloyd. That is all I ask.", "اعتنِ بأمك. وعِش يا لويد. هذا كل ما أطلبه.")]}),
		CutsceneDefs.sh(Vector3(2, 1.6, 4), Vector3(0, 1.6, 6), 4.5, "static", 42, {"say": [
			CutsceneDefs.Q("lloyd", "Dad... no.", "أبي... لا.")]}),
		CutsceneDefs.sh(Vector3(0, 6, -4), Vector3(0, 2, -14), 5.0, "orbit", 60, {"arc": 70.0, "fx": "flash", "say": [
			CutsceneDefs.Q("narrator", "The ground opens. Pale spirits rise from it: the first Anacondrai generals.", "تنفتح الأرض. وترتفع منها أرواح شاحبة: جنرالات الأناكوندراي الأوائل.")]}),
		CutsceneDefs.sh(Vector3(0, 2, -10), Vector3(0, 1.8, -18), 5.0, "dolly", 48, {"t": Vector3(0, 2, -13), "say": [
			CutsceneDefs.Q("general", "You wore our name and our shape. Now carry our curse.", "لبستم اسمنا وشكلنا. والآن احملوا لعنتنا.")]}),
		CutsceneDefs.sh(Vector3(0, 10, -2), Vector3(0, 1.6, -18), 5.0, "crane", 60, {"t": Vector3(0, 14, 0), "fx": "flash", "act": [
			CutsceneDefs.walk("chen", Vector3(0, 0.2, -70), 4.5), CutsceneDefs.walk("a1", Vector3(-6, 0.2, -70), 4.5), CutsceneDefs.walk("a2", Vector3(6, 0.2, -70), 4.5)], "say": [
			CutsceneDefs.Q("narrator", "The cursed cultists are dragged into the Cursed Realm, and the arena falls silent.", "تُجرّ الأتباع الملعونون إلى عالم اللعنة، وتصمت الساحة.")]})]}

	out["ch10_victory"] = {"mood": "dawn", "music": "hope", "cast": [
		CutsceneDefs.ch("lloyd", "lloyd", Vector3(0, 0.2, 2), Vector3(0, 0.2, -12)), CutsceneDefs.ch("kai", "kai", Vector3(-3, 0.2, 3), Vector3(0, 0.2, -12)),
		CutsceneDefs.ch("jay", "jay", Vector3(3, 0.2, 3), Vector3(0, 0.2, -12)), CutsceneDefs.ch("cole", "cole", Vector3(-5, 0.2, 5), Vector3(0, 0.2, -12)),
		CutsceneDefs.ch("zane", "zane", Vector3(5, 0.2, 5), Vector3(0, 0.2, -12)), CutsceneDefs.fig("statue", cfg_statue, Vector3(0, 0.2, -14), Vector3(0, 0.2, 10)),
		CutsceneDefs.fig("py", cfg_py, Vector3(9, 0.2, 7), Vector3(0, 0.2, -2)), CutsceneDefs.glow([Vector3(0.6, 1.0, 1.0), Vector3(0.4, 1.3, 0.9)], 0.35, Color(1.0, 0.6, 0.2))], "shots": [
		CutsceneDefs.sh(Vector3(0, 10, 16), Vector3(0, 3, -8), 5.5, "crane", 58, {"t": Vector3(0, 5, 10), "fx": "fade_in", "say": [
			CutsceneDefs.Q("narrator", "At the Corridor of Elders, a new face has been carved into the rock: a statue of Garmadon.", "في ممر الحكماء، نُحت وجه جديد في الصخر: تمثال لغارمادون.")]}),
		CutsceneDefs.sh(Vector3(-2, 1.6, 6), Vector3(0, 1.6, 0), 4.5, "hand", 40, {"say": [
			CutsceneDefs.Q("lloyd", "He made one choice, and it saved all of us.", "اتخذ قرارًا واحدًا، وأنقذنا جميعًا.")]}),
		CutsceneDefs.sh(Vector3(2, 1.4, 4), Vector3(0.5, 1.1, 1.0), 4.5, "static", 40, {"say": [
			CutsceneDefs.Q("narrator", "Lloyd drops the old Book of Spells into the fire. Too many people have been hurt by it.", "يُلقي لويد كتاب التعاويذ القديم في النار. لقد أُوذي بسببه ناس كثيرون.")]}),
		CutsceneDefs.sh(Vector3(11, 1.8, 9), Vector3(9, 1.7, 7), 4.0, "static", 42, {"say": [
			CutsceneDefs.Q("pythor", "Do not thank me. Just tell nobody I helped.", "لا تشكروني. فقط لا تخبروا أحدًا أنني ساعدت.")]})]}

	out["ch10_skylor_leaves"] = {"mood": "dawn", "music": "sad", "cast": [
		CutsceneDefs.fig("skylor", cfg_skylor, Vector3(6, 0.2, 6), Vector3(0, 0.2, 0)), CutsceneDefs.ch("kai", "kai", Vector3(0, 0.2, 0), Vector3(6, 0.2, 6))], "shots": [
		CutsceneDefs.sh(Vector3(3, 2.6, 10), Vector3(3, 1.6, 3), 5.0, "dolly", 48, {"t": Vector3(2, 2.2, 8), "fx": "fade_in", "say": [
			CutsceneDefs.Q("narrator", "Skylor stands at the edge of the arena with a small bag over her shoulder.", "تقف سكايلور عند حافة الساحة وعلى كتفها حقيبة صغيرة.")]}),
		CutsceneDefs.sh(Vector3(7, 1.6, 2), Vector3(6, 1.6, 6), 4.5, "hand", 40, {"say": [
			CutsceneDefs.Q("skylor", "I need to find my own road. Do not follow me.", "أحتاج أن أجد طريقي الخاص. لا تتبعني.")]}),
		CutsceneDefs.sh(Vector3(-2, 1.6, 4), Vector3(0, 1.6, 0), 4.5, "static", 42, {"say": [
			CutsceneDefs.Q("kai", "I will wait. I am good at waiting. Ask anyone.", "سأنتظر. أنا جيد في الانتظار. اسألي أي أحد.")]}),
		CutsceneDefs.sh(Vector3(6, 4, 14), Vector3(6, 1.6, 6), 4.5, "crane", 55, {"t": Vector3(8, 7, 18), "act": [CutsceneDefs.walk("skylor", Vector3(10, 0.2, 14), 4.0)]})]}

	out["ch10_ending"] = {"mood": "dawn", "music": "hope", "cast": [
		CutsceneDefs.ch("lloyd", "lloyd", Vector3(0, 0.2, 30), Vector3(0, 0.2, 48)), CutsceneDefs.ch("kai", "kai", Vector3(-2, 0.2, 31), Vector3(0, 0.2, 48)),
		CutsceneDefs.ch("jay", "jay", Vector3(2, 0.2, 31), Vector3(0, 0.2, 48)), CutsceneDefs.ch("cole", "cole", Vector3(-4, 0.2, 33), Vector3(0, 0.2, 48)),
		CutsceneDefs.ch("zane", "zane", Vector3(4, 0.2, 33), Vector3(0, 0.2, 48))], "shots": [
		CutsceneDefs.sh(Vector3(0, 14, 40), Vector3(0, 3, -10), 5.0, "crane", 58, {"t": Vector3(0, 8, 24), "fx": "fade_in", "say": [
			CutsceneDefs.Q("narrator", "Dawn comes slowly over the island, golden on the empty arena.", "يأتي الفجر ببطء فوق الجزيرة، ذهبيًّا على الساحة الخالية.")]}),
		CutsceneDefs.sh(Vector3(0, 1.8, 26), Vector3(0, 1.6, 32), 5.5, "hand", 42, {"act": [
			CutsceneDefs.walk("lloyd", Vector3(0, 0.2, 46), 6.0), CutsceneDefs.walk("kai", Vector3(-2, 0.2, 47), 6.0), CutsceneDefs.walk("jay", Vector3(2, 0.2, 47), 6.0),
			CutsceneDefs.walk("cole", Vector3(-4, 0.2, 49), 6.0), CutsceneDefs.walk("zane", Vector3(4, 0.2, 49), 6.0)], "say": [
			CutsceneDefs.Q("cole", "So. Where to next?", "إذن. إلى أين الآن؟")]}),
		CutsceneDefs.sh(Vector3(0, 1.6, 42), Vector3(0, 1.6, 50), 4.5, "dolly", 45, {"t": Vector3(0, 1.8, 40), "say": [
			CutsceneDefs.Q("zane", "There is a seat on the boat that still needs filling.", "هناك مقعد في القارب لا يزال ينتظر من يملؤه.")]}),
		CutsceneDefs.sh(Vector3(0, 6, 52), Vector3(0, 2, 20), 4.5, "crane", 62, {"t": Vector3(0, 18, 64), "fx": "fade_out"})]}
	return out
