#!/usr/bin/env python3
"""Generates REAL glTF-2.0 binary (.glb) assets with pure Python + numpy (no Blender needed):
  - minifig.glb : skinned LEGO-style minifigure, 9-bone skeleton, 15 skeletal animation clips
  - weapon_*.glb: 11 static weapons (attached to the hand bone in Godot)
  - tree_pine.glb, palm.glb, rock.glb: environment meshes
Front of every model faces -Z (Godot forward). Material names are used by Godot code to recolour."""
import json, math, os, struct, sys
import numpy as np

OUT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets", "models")
os.makedirs(OUT, exist_ok=True)

# ----------------------------------------------------------------- math ------
def rotx(a): c, s = math.cos(a), math.sin(a); return np.array([[1,0,0],[0,c,-s],[0,s,c]], float)
def roty(a): c, s = math.cos(a), math.sin(a); return np.array([[c,0,s],[0,1,0],[-s,0,c]], float)
def rotz(a): c, s = math.cos(a), math.sin(a); return np.array([[c,-s,0],[s,c,0],[0,0,1]], float)
def euler_yxz(x, y, z): return roty(y) @ rotx(x) @ rotz(z)   # Godot default Euler order
def mat_to_quat(R):
    t = R[0,0] + R[1,1] + R[2,2]
    if t > 0:
        s = math.sqrt(t + 1.0) * 2; w = 0.25 * s
        x = (R[2,1] - R[1,2]) / s; y = (R[0,2] - R[2,0]) / s; z = (R[1,0] - R[0,1]) / s
    elif R[0,0] > R[1,1] and R[0,0] > R[2,2]:
        s = math.sqrt(1.0 + R[0,0] - R[1,1] - R[2,2]) * 2; w = (R[2,1] - R[1,2]) / s
        x = 0.25 * s; y = (R[0,1] + R[1,0]) / s; z = (R[0,2] + R[2,0]) / s
    elif R[1,1] > R[2,2]:
        s = math.sqrt(1.0 + R[1,1] - R[0,0] - R[2,2]) * 2; w = (R[0,2] - R[2,0]) / s
        x = (R[0,1] + R[1,0]) / s; y = 0.25 * s; z = (R[1,2] + R[2,1]) / s
    else:
        s = math.sqrt(1.0 + R[2,2] - R[0,0] - R[1,1]) * 2; w = (R[1,0] - R[0,1]) / s
        x = (R[0,2] + R[2,0]) / s; y = (R[1,2] + R[2,1]) / s; z = 0.25 * s
    q = np.array([x, y, z, w]); return q / np.linalg.norm(q)
def lerp(a, b, t): return a + (b - a) * t
def ease(x, c):  # Godot's ease()
    x = min(max(x, 0.0), 1.0)
    if c > 0: return 1 - (1 - x) ** (1 / c) if c < 1 else x ** c
    return x

# ------------------------------------------------------------- geometry ------
class Geo:
    def __init__(s): s.p = []; s.n = []; s.i = []; s.j = []
    def _tri(s, pts, nrm, j):
        b = len(s.p)
        for p in pts: s.p.append(np.asarray(p, float)); s.n.append(np.asarray(nrm, float)); s.j.append(j)
        for k in range(1, len(pts) - 1): s.i += [b, b + k, b + k + 1]
def add_box(g, c, size, j=0, R=None):
    h = np.array(size, float) / 2; c = np.array(c, float)
    for a in range(3):
        for sg in (1, -1):
            u, v = (a + 1) % 3, (a + 2) % 3
            quad = [(-1,-1),(1,-1),(1,1),(-1,1)]
            if sg < 0: quad = quad[::-1]
            pts = []
            for qu, qv in quad:
                p = np.zeros(3); p[a] = sg * h[a]; p[u] = qu * h[u]; p[v] = qv * h[v]
                pts.append(c + (R @ p if R is not None else p))
            n = np.zeros(3); n[a] = sg
            g._tri(pts, R @ n if R is not None else n, j)
def add_cyl(g, c, rt, rb, h, j=0, seg=12, R=None, caps=True):
    c = np.array(c, float); slope = (rb - rt) / h
    rot = (lambda p: R @ p) if R is not None else (lambda p: p)
    base = len(g.p)
    for k in range(seg + 1):
        th = 2 * math.pi * k / seg; cs, sn = math.cos(th), math.sin(th)
        n = np.array([cs, slope, sn]); n /= np.linalg.norm(n)
        g.p.append(c + rot(np.array([rb*cs, -h/2, rb*sn]))); g.n.append(rot(n)); g.j.append(j)
        g.p.append(c + rot(np.array([rt*cs, h/2, rt*sn]))); g.n.append(rot(n)); g.j.append(j)
    for k in range(seg):
        a = base + 2*k; b = a + 1; c2 = a + 2; d = a + 3
        g.i += [a, b, c2, b, d, c2]
    if caps:
        for top, rr, y in ((True, rt, h/2), (False, rb, -h/2)):
            if rr <= 1e-6: continue
            ctr = len(g.p); nn = np.array([0, 1 if top else -1, 0.0])
            g.p.append(c + rot(np.array([0, y, 0.0]))); g.n.append(rot(nn)); g.j.append(j)
            ring = len(g.p)
            for k in range(seg + 1):
                th = 2 * math.pi * k / seg
                g.p.append(c + rot(np.array([rr*math.cos(th), y, rr*math.sin(th)]))); g.n.append(rot(nn)); g.j.append(j)
            for k in range(seg):
                g.i += [ctr, ring + k + 1, ring + k] if top else [ctr, ring + k, ring + k + 1]
def add_sphere(g, c, r, j=0, rings=6, seg=10):
    c = np.array(c, float); base = len(g.p)
    for i in range(rings + 1):
        ph = math.pi * i / rings
        for k in range(seg + 1):
            th = 2 * math.pi * k / seg
            n = np.array([math.sin(ph)*math.cos(th), math.cos(ph), math.sin(ph)*math.sin(th)])
            g.p.append(c + n * r); g.n.append(n); g.j.append(j)
    for i in range(rings):
        for k in range(seg):
            a = base + i*(seg+1) + k; b = a + seg + 1
            g.i += [a, a + 1, b, a + 1, b + 1, b]
    # fix winding to outward
    for t in range(len(g.i) - rings*seg*6, len(g.i), 3):
        a, b, c3 = g.i[t:t+3]
        n = np.cross(g.p[b] - g.p[a], g.p[c3] - g.p[a])
        if np.dot(n, g.n[a]) < 0: g.i[t+1], g.i[t+2] = g.i[t+2], g.i[t+1]
def add_flat(g, verts, faces, j=0):
    for f in faces:
        pts = [verts[k] for k in f]; n = np.cross(pts[1] - pts[0], pts[2] - pts[0])
        ln = np.linalg.norm(n)
        if ln < 1e-9: continue
        g._tri(pts, n / ln, j)

# ----------------------------------------------------------------- glTF ------
class GLB:
    def __init__(s): s.bin = bytearray(); s.views = []; s.acc = []; s.nodes = []; s.meshes = []; s.mats = []; s.mat_idx = {}; s.skins = []; s.anims = []
    def view(s, data, target=None):
        while len(s.bin) % 4: s.bin.append(0)
        v = {"buffer": 0, "byteOffset": len(s.bin), "byteLength": len(data)}
        if target: v["target"] = target
        s.bin += data; s.views.append(v); return len(s.views) - 1
    def accessor(s, arr, ctype, atype, target=None, minmax=False):
        arr = np.ascontiguousarray(arr)
        a = {"bufferView": s.view(arr.tobytes(), target), "componentType": ctype, "count": int(arr.shape[0]), "type": atype}
        if minmax:
            a["min"] = np.atleast_1d(arr.min(axis=0)).astype(float).tolist(); a["max"] = np.atleast_1d(arr.max(axis=0)).astype(float).tolist()
        s.acc.append(a); return len(s.acc) - 1
    def material(s, name, rgb, rough=0.45, emissive=None):
        if name in s.mat_idx: return s.mat_idx[name]
        m = {"name": name, "pbrMetallicRoughness": {"baseColorFactor": [rgb[0], rgb[1], rgb[2], 1.0], "metallicFactor": 0.0, "roughnessFactor": rough}}
        if emissive: m["emissiveFactor"] = list(emissive)
        s.mats.append(m); s.mat_idx[name] = len(s.mats) - 1; return s.mat_idx[name]
    def mesh(s, name, parts, skinned=False):
        """parts: {material_name: (Geo, rgb)}"""
        prims = []
        for mname, (g, rgb) in parts.items():
            if not g.i: continue
            pos = np.array(g.p, np.float32); nor = np.array(g.n, np.float32)
            at = {"POSITION": s.accessor(pos, 5126, "VEC3", 34962, True), "NORMAL": s.accessor(nor, 5126, "VEC3", 34962)}
            if skinned:
                jt = np.zeros((len(g.j), 4), np.uint8); jt[:, 0] = g.j
                wt = np.zeros((len(g.j), 4), np.float32); wt[:, 0] = 1.0
                at["JOINTS_0"] = s.accessor(jt, 5121, "VEC4", 34962); at["WEIGHTS_0"] = s.accessor(wt, 5126, "VEC4", 34962)
            assert len(g.p) < 65535
            prims.append({"attributes": at, "indices": s.accessor(np.array(g.i, np.uint16), 5123, "SCALAR", 34963), "material": s.material(mname, rgb), "mode": 4})
        s.meshes.append({"name": name, "primitives": prims}); return len(s.meshes) - 1
    def save(s, path, scene_nodes):
        doc = {"asset": {"version": "2.0", "generator": "ninjago_toe tools/gen_assets.py"}, "scene": 0, "scenes": [{"nodes": scene_nodes}],
               "nodes": s.nodes, "meshes": s.meshes, "materials": s.mats, "accessors": s.acc, "bufferViews": s.views,
               "buffers": [{"byteLength": len(s.bin)}]}
        if s.skins: doc["skins"] = s.skins
        if s.anims: doc["animations"] = s.anims
        js = json.dumps(doc, separators=(",", ":")).encode()
        while len(js) % 4: js += b" "
        b = bytes(s.bin)
        while len(b) % 4: b += b"\0"
        total = 12 + 8 + len(js) + 8 + len(b)
        with open(path, "wb") as f:
            f.write(struct.pack("<4sII", b"glTF", 2, total))
            f.write(struct.pack("<II", len(js), 0x4E4F534A)); f.write(js)
            f.write(struct.pack("<II", len(b), 0x004E4942)); f.write(b)
        print("wrote", os.path.relpath(path), os.path.getsize(path), "bytes", len(s.nodes), "nodes", len(s.anims), "anims")

# ------------------------------------------------------------ minifigure -----
SKIN = (0.98, 0.8, 0.12)
JOINTS = [  # name, parent, rest translation
    ("root", -1, (0, 0, 0)), ("hips", 0, (0, 0.62, 0)), ("torso", 1, (0, 0, 0)), ("head", 2, (0, 0.63, 0)),
    ("arm_l", 2, (-0.34, 0.56, 0)), ("arm_r", 2, (0.34, 0.56, 0)), ("hand_r", 5, (0, -0.5, 0)),
    ("leg_l", 1, (-0.12, -0.07, 0)), ("leg_r", 1, (0.12, -0.07, 0))]
J = {n: i for i, (n, _, _) in enumerate(JOINTS)}
def world_pos():
    w = []
    for n, p, t in JOINTS: w.append(np.array(t, float) + (w[p] if p >= 0 else 0))
    return w

def minifig_parts():
    body = {k: Geo() for k in ("suit", "legs", "accent", "skin")}
    add_box(body["legs"], (-0.12, 0.275, 0), (0.22, 0.55, 0.28), J["leg_l"]); add_box(body["legs"], (0.12, 0.275, 0), (0.22, 0.55, 0.28), J["leg_r"])
    add_box(body["legs"], (0, 0.62, 0), (0.48, 0.16, 0.3), J["hips"])
    add_box(body["suit"], (0, 0.975, 0), (0.52, 0.55, 0.32), J["torso"])
    add_box(body["accent"], (0, 0.74, 0), (0.54, 0.07, 0.34), J["torso"]); add_box(body["accent"], (0, 1.05, -0.165), (0.18, 0.18, 0.02), J["torso"])
    add_box(body["suit"], (-0.34, 0.95, 0), (0.15, 0.46, 0.17), J["arm_l"]); add_box(body["suit"], (0.34, 0.95, 0), (0.15, 0.46, 0.17), J["arm_r"])
    add_sphere(body["skin"], (-0.34, 0.68, 0), 0.085, J["arm_l"]); add_sphere(body["skin"], (0.34, 0.68, 0), 0.085, J["hand_r"])
    hy = 1.25
    hood = {k: Geo() for k in ("hood", "skin", "black")}
    add_cyl(hood["hood"], (0, hy + 0.16, 0), 0.26, 0.26, 0.32, J["head"], 16); add_cyl(hood["hood"], (0, hy + 0.355, 0), 0.1, 0.1, 0.07, J["head"], 12)
    add_box(hood["skin"], (0, hy + 0.17, -0.255), (0.3, 0.1, 0.03), J["head"])
    for x in (-0.07, 0.07): add_box(hood["black"], (x, hy + 0.17, -0.272), (0.045, 0.05, 0.02), J["head"])
    bare = {k: Geo() for k in ("skin", "black", "mouth")}
    add_cyl(bare["skin"], (0, hy + 0.16, 0), 0.26, 0.26, 0.32, J["head"], 16); add_cyl(bare["skin"], (0, hy + 0.355, 0), 0.1, 0.1, 0.07, J["head"], 12)
    for x in (-0.07, 0.07): add_box(bare["black"], (x, hy + 0.19, -0.262), (0.045, 0.05, 0.02), J["head"])
    add_box(bare["mouth"], (0, hy + 0.09, -0.262), (0.14, 0.025, 0.02), J["head"])
    hair = {"hair": Geo()}; add_cyl(hair["hair"], (0, hy + 0.29, 0), 0.275, 0.275, 0.12, J["head"], 16)
    hat = {"hat": Geo()}; add_cyl(hat["hat"], (0, hy + 0.52, 0), 0.0, 0.36, 0.4, J["head"], 16)
    robe = {"robe": Geo()}; add_box(robe["robe"], (0, 0.45, 0), (0.64, 0.64, 0.44), J["hips"])
    return {"body": body, "head_hood": hood, "head_bare": bare, "opt_hair": hair, "opt_hat": hat, "opt_robe": robe}

COLORS = {"suit": (0.8, 0.1, 0.1), "legs": (0.55, 0.07, 0.07), "accent": (1.0, 0.45, 0.4), "skin": SKIN, "hood": (0.7, 0.09, 0.09),
          "black": (0.02, 0.02, 0.02), "mouth": (0.4, 0.1, 0.1), "hair": (0.15, 0.1, 0.05), "hat": (0.3, 0.1, 0.3), "robe": (0.3, 0.0, 0.35)}

def pose(**kw):
    d = dict(ll=0, lr=0, al=0, ar=0, alz=-0.08, arz=0.08, lean=0, twist=0, dy=0, dz=0, spin=0); d.update(kw); return d
def sin(x): return math.sin(x)
def clip_fn(name):
    def idle(k): ph = 2*math.pi*k; return pose(alz=-0.08 + sin(ph)*0.02, arz=0.08 - sin(ph)*0.02, dy=sin(ph)*0.008, lean=sin(ph)*0.01)
    def walk(k):
        ph = 2*math.pi*k; ll = sin(ph)*0.72; return pose(ll=ll, lr=-ll, al=-ll*0.8, ar=ll*0.8, twist=sin(ph)*0.08, dy=abs(sin(ph))*0.03)
    def run(k):
        ph = 2*math.pi*k; ll = sin(ph)*1.17; return pose(ll=ll, lr=-ll, al=-ll*0.8, ar=ll*0.8, lean=-0.22, twist=sin(ph)*0.12, dy=abs(sin(ph))*0.06)
    def jump(k): b = min(1, k*3); return pose(al=2.4*b, ar=2.4*b, ll=0.4*b, lr=-0.3*b)
    def l1(k): return pose(ar=lerp(-1.4, 2.1, ease(k, 0.35)), twist=lerp(0.5, -0.5, k))
    def l2(k): return pose(al=lerp(-1.4, 2.1, ease(k, 0.35)), twist=lerp(-0.5, 0.5, k))
    def l3(k): a = lerp(-0.5, 2.4, ease(k, 0.3)); return pose(al=a, ar=a, lean=lerp(0.1, -0.45, k), ll=0.8, lr=-0.6, dz=-0.3*k)
    def heavy(k):
        if k < 0.5: a = lerp(0, 3.0, k*2); ln = lerp(0, 0.25, k*2)
        else: a = lerp(3.0, 0.3, ease(k*2 - 1, 0.3)); ln = lerp(0.25, -0.5, k*2 - 1)
        return pose(al=a, ar=a, lean=ln)
    def cast(k): b = min(1, k*6); a = 1.55*b + sin(k*10)*0.12*b; return pose(al=a, ar=a, lean=-0.12*b)
    def eatk(k): e = ease(k, 4.0); return pose(ar=lerp(-1.6, 2.2, e), lean=lerp(0.25, -0.3, e))
    def dodge(k): b = min(1, k*6); return pose(lean=-0.7*b, ll=1.0*b, lr=-1.0*b, al=-0.8*b, ar=-0.8*b, dy=-0.12*b)
    def stagger(k): b = min(1, k*5); return pose(lean=0.45*b, al=0.9*b, ar=0.9*b, alz=-0.08 - 0.62*b, arz=0.08 + 0.62*b)
    def block(k): return pose(al=1.4, ar=1.4, alz=0.55, arz=-0.55, lean=-0.05)
    def spin(k): return pose(alz=-1.45, arz=1.45, spin=4*math.pi*k)
    def climb(k): ph = 2*math.pi*k; return pose(al=2.6 + sin(ph)*0.6, ar=2.6 - sin(ph)*0.6, ll=sin(ph)*0.7, lr=-sin(ph)*0.7, lean=0.15)
    return {"idle": (idle, 2.0), "walk": (walk, 0.8), "run": (run, 0.55), "jump": (jump, 0.7), "light1": (l1, 1.0), "light2": (l2, 1.0),
            "light3": (l3, 1.0), "heavy": (heavy, 1.0), "cast": (cast, 1.0), "enemy_atk": (eatk, 1.0), "dodge": (dodge, 1.0),
            "stagger": (stagger, 1.0), "block": (block, 1.0), "spin": (spin, 0.6), "climb": (climb, 0.8)}[name]
CLIPS = ["idle", "walk", "run", "jump", "light1", "light2", "light3", "heavy", "cast", "enemy_atk", "dodge", "stagger", "block", "spin", "climb"]

def pose_to_tracks(p):
    return {"root": ("r", euler_yxz(0, p["spin"], 0)), "hips": ("t", (0, 0.62 + p["dy"], p["dz"])), "torso": ("r", euler_yxz(p["lean"], p["twist"], 0)),
            "arm_l": ("r", euler_yxz(p["al"], 0, p["alz"])), "arm_r": ("r", euler_yxz(p["ar"], 0, p["arz"])),
            "leg_l": ("r", euler_yxz(p["ll"], 0, 0)), "leg_r": ("r", euler_yxz(p["lr"], 0, 0))}

def build_minifig():
    g = GLB(); wp = world_pos()
    parts = minifig_parts()
    mesh_nodes = []
    first_mesh_node = len(JOINTS) + 1
    # nodes: 0 scene root, 1..9 joints, then meshes
    g.nodes.append({"name": "Minifig", "children": [1]})
    for n, p, t in JOINTS:
        g.nodes.append({"name": n, "translation": list(map(float, t)), "rotation": [0, 0, 0, 1]})
    for i, (n, p, t) in enumerate(JOINTS):
        if p >= 0: g.nodes[1 + p].setdefault("children", []).append(1 + i)
    ibm = np.zeros((len(JOINTS), 16), np.float32)
    for i, w in enumerate(wp):
        m = np.eye(4); m[:3, 3] = -w; ibm[i] = m.T.reshape(16)   # column-major
    g.skins.append({"joints": [1 + i for i in range(len(JOINTS))], "skeleton": 1, "inverseBindMatrices": g.accessor(ibm, 5126, "MAT4")})
    for mname, mp in parts.items():
        mi = g.mesh(mname, {k: (v, COLORS[k]) for k, v in mp.items()}, skinned=True)
        g.nodes.append({"name": mname, "mesh": mi, "skin": 0}); g.nodes[0]["children"].append(len(g.nodes) - 1)
    # animations
    F = 24
    for cname in CLIPS:
        fn, D = clip_fn(cname)
        ks = [i / F for i in range(F + 1)]
        times = np.array([k * D for k in ks], np.float32)
        tin = g.accessor(times, 5126, "SCALAR", None, True)
        samplers, channels = [], []
        series = {}
        for k in ks:
            for jn, (kind, val) in pose_to_tracks(fn(k)).items():
                series.setdefault(jn, (kind, []))[1].append(val)
        for jn, (kind, vals) in series.items():
            if kind == "r": arr = np.array([mat_to_quat(v) for v in vals], np.float32); typ = "VEC4"; path = "rotation"
            else: arr = np.array(vals, np.float32); typ = "VEC3"; path = "translation"
            # keep quaternion sign continuous
            if kind == "r":
                for i in range(1, len(arr)):
                    if np.dot(arr[i], arr[i-1]) < 0: arr[i] = -arr[i]
            samplers.append({"input": tin, "output": g.accessor(arr, 5126, typ), "interpolation": "LINEAR"})
            channels.append({"sampler": len(samplers) - 1, "target": {"node": 1 + J[jn], "path": path}})
        g.anims.append({"name": cname, "samplers": samplers, "channels": channels})
    g.save(os.path.join(OUT, "minifig.glb"), [0])

# --------------------------------------------------------------- weapons -----
WC = {"metal": (0.82, 0.84, 0.9), "wood": (0.4, 0.26, 0.12), "gold": (1.0, 0.8, 0.2), "bladegreen": (0.45, 1.0, 0.55),
      "bladegold": (1.0, 0.8, 0.2), "fabric": (1.0, 0.6, 0.1), "stone": (0.45, 0.45, 0.5), "purple": (0.25, 0.1, 0.3), "orb": (0.7, 0.2, 0.9)}
def weapon(kind):
    G = {k: Geo() for k in WC}
    if kind in ("sword", "sword_green", "sword_gold"):
        bl = {"sword": "metal", "sword_green": "bladegreen", "sword_gold": "bladegold"}[kind]
        add_box(G["wood"], (0, 0, 0), (0.05, 0.14, 0.05)); add_box(G["gold"], (0, 0.08, 0), (0.22, 0.035, 0.07)); add_box(G[bl], (0, 0.5, 0), (0.06, 0.8, 0.02))
        add_box(G[bl], (0, 0.93, 0), (0.035, 0.08, 0.018))
    elif kind == "nunchaku":
        add_box(G["wood"], (0, 0.1, 0), (0.045, 0.4, 0.045)); add_box(G["metal"], (0, 0.4, 0), (0.015, 0.22, 0.015))
        add_box(G["wood"], (0, 0.66, 0.1), (0.045, 0.4, 0.045), R=rotx(0.4))
    elif kind == "scythe":
        add_box(G["wood"], (0, 0.55, 0), (0.05, 1.5, 0.05)); add_box(G["metal"], (0.24, 1.3, 0), (0.55, 0.07, 0.03), R=rotz(-0.35)); add_box(G["metal"], (0.5, 1.2, 0), (0.12, 0.05, 0.03), R=rotz(-0.9))
    elif kind == "shuriken":
        add_box(G["metal"], (0, 0.05, 0), (0.3, 0.02, 0.3)); add_box(G["metal"], (0, 0.05, 0), (0.3, 0.02, 0.3), R=roty(math.pi / 4))
    elif kind == "fan":
        add_box(G["fabric"], (0, 0.3, 0), (0.5, 0.4, 0.02)); add_box(G["gold"], (0, 0.5, 0), (0.5, 0.04, 0.03)); add_box(G["gold"], (0, 0.05, 0), (0.04, 0.2, 0.03))
    elif kind == "club":
        add_cyl(G["wood"], (0, 0.25, 0), 0.09, 0.05, 0.6, seg=8)
    elif kind == "hammer":
        add_box(G["wood"], (0, 0.4, 0), (0.06, 1.0, 0.06)); add_box(G["stone"], (0, 0.95, 0), (0.55, 0.3, 0.3))
    elif kind == "spear":
        add_box(G["wood"], (0, 0.7, 0), (0.05, 1.8, 0.05)); add_box(G["metal"], (0, 1.75, 0), (0.1, 0.3, 0.03)); add_box(G["metal"], (0, 1.95, 0), (0.05, 0.12, 0.025))
    elif kind == "staff":
        add_box(G["purple"], (0, 0.6, 0), (0.05, 1.7, 0.05)); add_sphere(G["orb"], (0, 1.5, 0), 0.12)
    g = GLB(); mi = g.mesh("weapon", {k: (v, WC[k]) for k, v in G.items()})
    g.nodes.append({"name": "Weapon", "children": [1]}); g.nodes.append({"name": "mesh", "mesh": mi})
    g.save(os.path.join(OUT, "weapon_%s.glb" % kind), [0])

# ---------------------------------------------------------- environment ------
def pine():
    bark, leaf = Geo(), Geo()
    add_cyl(bark, (0, 1.5, 0), 0.3, 0.42, 3.0, seg=8)
    for i, (r, y, h) in enumerate([(2.4, 3.3, 2.4), (2.0, 4.5, 2.2), (1.5, 5.6, 2.0), (1.0, 6.6, 1.8)]):
        add_cyl(leaf, (0, y, 0), 0.0, r, h, seg=8, R=roty(i * 0.4))
    g = GLB(); mi = g.mesh("pine", {"bark": (bark, (0.4, 0.26, 0.14)), "leaf": (leaf, (0.12, 0.42, 0.16))})
    g.nodes += [{"name": "Pine", "children": [1]}, {"name": "mesh", "mesh": mi}]; g.save(os.path.join(OUT, "tree_pine.glb"), [0])
def palm():
    bark, leaf = Geo(), Geo(); x = 0.0
    for i in range(6):
        add_cyl(bark, (x, 0.35 + i * 0.7, 0), 0.16 - i * 0.01, 0.2 - i * 0.01, 0.75, seg=6, R=rotz(-0.06)); x += 0.04
    top = np.array([x, 4.3, 0.0])
    for k in range(7):
        yaw = 2 * math.pi * k / 7; R = roty(yaw) @ rotx(0.45)
        add_box(leaf, top + roty(yaw) @ np.array([0, -0.35, -0.95]), (0.34, 0.05, 2.0), R=R)
    add_sphere(bark, top + np.array([0, -0.1, 0]), 0.22, rings=4, seg=6)
    g = GLB(); mi = g.mesh("palm", {"bark": (bark, (0.55, 0.4, 0.2)), "leaf": (leaf, (0.2, 0.6, 0.25))})
    g.nodes += [{"name": "Palm", "children": [1]}, {"name": "mesh", "mesh": mi}]; g.save(os.path.join(OUT, "palm.glb"), [0])
def rock():
    t = (1 + math.sqrt(5)) / 2
    v = [(-1, t, 0), (1, t, 0), (-1, -t, 0), (1, -t, 0), (0, -1, t), (0, 1, t), (0, -1, -t), (0, 1, -t), (t, 0, -1), (t, 0, 1), (-t, 0, -1), (-t, 0, 1)]
    f = [(0,11,5),(0,5,1),(0,1,7),(0,7,10),(0,10,11),(1,5,9),(5,11,4),(11,10,2),(10,7,6),(7,1,8),(3,9,4),(3,4,2),(3,2,6),(3,6,8),(3,8,9),(4,9,5),(2,4,11),(6,2,10),(8,6,7),(9,8,1)]
    verts = [np.array(p, float) / np.linalg.norm(p) for p in v]
    rng = np.random.default_rng(7)
    verts = [p * (0.8 + 0.35 * rng.random()) * np.array([1.0, 0.7, 1.0]) for p in verts]
    verts = [p + np.array([0, 0.45, 0]) for p in verts]
    G = Geo(); add_flat(G, verts, f)
    g = GLB(); mi = g.mesh("rock", {"rock": (G, (0.45, 0.45, 0.47))})
    g.nodes += [{"name": "Rock", "children": [1]}, {"name": "mesh", "mesh": mi}]; g.save(os.path.join(OUT, "rock.glb"), [0])

if __name__ == "__main__":
    build_minifig()
    for k in ("sword", "sword_green", "sword_gold", "nunchaku", "scythe", "shuriken", "fan", "club", "hammer", "spear", "staff"): weapon(k)
    pine(); palm(); rock()
