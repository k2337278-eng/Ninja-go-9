#!/usr/bin/env python3
"""Structural checks that need no Godot: bracket balance (comments/strings ignored), tab indentation, duplicate
functions/vars in a file, subclass members that redefine a parent member (this once broke the build), calls from
chapters to isl/hud/ChapterBase helpers that do not exist, and members the v7-v9 code relies on.
It does NOT check types: type errors only show up in the real Godot build."""
import re, glob, sys
src = {f: open(f, encoding='utf-8').read() for f in glob.glob('scripts/**/*.gd', recursive=True)}
problems = 0
def p(*a):
    global problems; problems += 1; print(*a)
def code(s):
    s = '\n'.join(l for l in s.split('\n') if not re.match(r'^\s*#', l))
    s = re.sub(r'"(?:\\.|[^"\\])*"', '""', s)
    return re.sub(r'#.*', '', s)
for f, s in src.items():
    t = code(s)
    if not (t.count('(') == t.count(')') and t.count('[') == t.count(']') and t.count('{') == t.count('}')): p("UNBALANCED", f)
    if any(re.match(r'^ +\S', l) for l in s.split('\n')): p("SPACE-INDENT", f)
by = {}
for f, s in src.items():
    m = re.search(r'^class_name\s+(\w+)', s, re.M)
    if m: by[m.group(1)] = f
def members(f):
    s = src[f]
    return set(re.findall(r'^(?:@export\s+|@onready\s+)?(?:var|const)\s+(\w+)', s, re.M)) | set(re.findall(r'^signal\s+(\w+)', s, re.M))
for f, s in src.items():
    fn = re.findall(r'^(?:static\s+)?func\s+(\w+)', s, re.M)
    for x in {x for x in fn if fn.count(x) > 1}: p("DUP FUNC", f, x)
    v = re.findall(r'^(?:@export\s+|@onready\s+)?(?:var|const)\s+(\w+)', s, re.M)
    for x in {x for x in v if v.count(x) > 1}: p("DUP VAR", f, x)
    ex = re.search(r'^extends\s+(\w+)', s, re.M); par = ex.group(1) if ex else None
    while par in by:
        d = members(f) & members(by[par])
        if d: p("DUP MEMBER", f, by[par], sorted(d))
        e2 = re.search(r'^extends\s+(\w+)', src[by[par]], re.M); par = e2.group(1) if e2 else None
def names(f):
    s = src[f]
    return set(re.findall(r'^\s*(?:static\s+)?func\s+(\w+)', s, re.M)) | set(re.findall(r'^\s*(?:var|const|signal)\s+(\w+)', s, re.M))
isl = names('scripts/world/island.gd') | names('scripts/world/island_extras.gd'); hud = names('scripts/ui/hud.gd'); cb = names('scripts/world/chapter_base.gd')
inherited = {'get_tree', 'add_child', 'queue_free'}
builtin = set('func if elif while for match return await and or not in is as print Vector2 Vector3 Color float int str abs sin cos min max clampf lerpf randf randi randf_range randi_range range len bool Array Dictionary String sqrt floor ceil pow sign maxf minf absf mini maxi fposmod atan2 is_instance_valid'.split())
for f in glob.glob('scripts/world/chapters/*.gd') + ['scripts/world/chapter_base.gd']:
    s = src[f]; own = names(f)
    for m in re.finditer(r'\bisl\.hud\.(\w+)\(', s):
        if m.group(1) not in hud: p("MISSING hud.", f, m.group(1))
    for m in re.finditer(r'\bisl\.(\w+)\(', s):
        n = m.group(1)
        if n not in isl and n not in inherited and n != 'hud': p("MISSING isl.", f, n)
    if 'chapters/' in f:
        for m in re.finditer(r'(?<![\.\w])(\w+)\(', s):
            n = m.group(1)
            if n in own or n in cb or n in builtin: continue
            p("UNRESOLVED call", f, n)
need = [('Player', 'controls'), ('Player', 'input_locked'), ('Fighter', 'face_dir'), ('CameraRig', 'lock_target'),
        ('TouchControls', 'action_pressed'), ('TouchControls', 'move_vector'), ('Fighter', 'rig'), ('Fighter', 'tornado')]
for c, m in need:
    f = by.get(c)
    if not (f and re.search(r'(var|signal)\s+%s\b' % m, src[f])): p("MISSING member", c, m)
print("structure problems:", problems)
sys.exit(1 if problems else 0)
