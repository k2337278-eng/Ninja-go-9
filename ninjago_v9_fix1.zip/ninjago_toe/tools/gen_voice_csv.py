#!/usr/bin/env python3
"""Regenerates docs/VOICE_LINES.csv from the source: every ln()/me()/nr() line in
scripts/world/chapters/ch01..ch10.gd and every D.Q() line in scripts/cutscenes/cutscene_defs_*.gd.
id = "v_" + md5(arabic text)[:10] (same as Voice.line_id), so recorded files assets/voice/<id>.ogg|mp3|wav
are picked up automatically. Columns: id, character, tts_text, emotion  (+ en_text, source for reference)."""
import csv, hashlib, os, re
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
S = r'"((?:\\.|[^"\\])*)"'
unesc = lambda s: s.replace('\\"', '"').replace('\\n', '\n').replace('\\\\', '\\')
FIX = {"Kryptarium": "كريبتاريوم", "D.B. Express": "دي بي إكسبرس", "Digiverse": "ديجيفيرس", "P.I.X.A.L.": "بيكسال", "Thunderblade": "ثاندربليد", "D.B. Express": "دي بي إكسبرس"}

def tts(t):
    t = re.sub(r"\(VERIFY[^)]*\)|\(VERIFY:[^)]*\)|VERIFY[:：]?\s*", "", t)
    for k, v in FIX.items():
        t = t.replace(k, v)
    return re.sub(r"\s+", " ", t).strip()

def emotion(t, who):
    if "!" in t: return "excited"
    if "..." in t or "…" in t: return "hesitant"
    if "?" in t or "؟" in t: return "curious"
    if who in ("chen", "karlof", "clouse", "garmadon"): return "stern"
    return "neutral"

rows, seen = [], set()
def add(who, en, ar, src):
    ar = unesc(ar); en = unesc(en)
    i = "v_" + hashlib.md5(ar.encode("utf-8")).hexdigest()[:10]
    if i in seen: return
    seen.add(i)
    rows.append([i, who, tts(ar), emotion(ar, who), en, src])

for n in range(1, 11):
    p = f"scripts/world/chapters/ch{n:02d}.gd"
    t = open(os.path.join(root, p), encoding="utf-8").read()
    players = {fn: pl for pl, fn in re.findall(r'beat\("\w+", "(\w+)", \[.*?\], Vector3\(.*?\), (_\w+)', t)}
    parts = re.split(r"(?m)^func (\w+)\(", t)
    for k in range(1, len(parts), 2):
        fn, body = parts[k], parts[k + 1]
        for who, en, ar in re.findall(r'\bln\("(\w+)", ' + S + ', ' + S + r'\)', body):
            add(who, en, ar, p)
        for en, ar in re.findall(r'\bnr\(' + S + ', ' + S + r'\)', body):
            add("narrator", en, ar, p)
        for en, ar in re.findall(r'\bme\(' + S + ', ' + S + r'\)', body):
            add(players.get(fn, "kai"), en, ar, p)
for f in sorted(os.listdir(os.path.join(root, "scripts/cutscenes"))):
    if f.startswith("cutscene_defs_"):
        t = open(os.path.join(root, "scripts/cutscenes", f), encoding="utf-8").read()
        for who, en, ar in re.findall(r'CutsceneDefs\.Q\("(\w+)", ' + S + ', ' + S + r'\)', t):
            add(who, en, ar, "cutscene:" + f)
with open(os.path.join(root, "docs/VOICE_LINES.csv"), "w", encoding="utf-8-sig", newline="") as fh:
    w = csv.writer(fh)
    w.writerow(["id", "character", "tts_text", "emotion", "en_text", "source"])
    w.writerows(rows)
print(len(rows), "lines")
