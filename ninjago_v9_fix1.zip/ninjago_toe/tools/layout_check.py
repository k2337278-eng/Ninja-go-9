#!/usr/bin/env python3
"""Layout sanity check (no Godot needed): every Vector3 in the chapter scripts must lie on the island plane
(+-330 of 700x700, y in [-3, 40]); rail-run paths are rebuilt like ChapterBase.snake() and every obstacle
distance must be shorter than the path. It cannot see props/buildings: positions still need a real playtest."""
import re, glob, math, sys
bad = 0
for f in sorted(glob.glob('scripts/world/chapters/*.gd')) + ['scripts/world/chapter_base.gd']:
    s = open(f, encoding='utf-8').read()
    for m in re.finditer(r'Vector3\(\s*(-?[\d\.]+)\s*,\s*(-?[\d\.]+)\s*,\s*(-?[\d\.]+)\s*\)', s):
        x, y, z = (float(v) for v in m.groups())
        if abs(x) > 330 or abs(z) > 330 or y < -3 or y > 40:
            print("OUT OF RANGE", f, m.group(0)); bad += 1
def snake_len(a, b, n, amp):
    fwd = (b[0]-a[0], b[2]-a[2]); L = math.hypot(*fwd)
    r = (-fwd[1]/L, fwd[0]/L)  # perpendicular
    pts = []
    for i in range(n+1):
        t = i/n
        off = math.sin(i*1.1) * amp * math.sin(t*math.pi)
        pts.append((a[0]+(b[0]-a[0])*t + r[0]*off, a[2]+(b[2]-a[2])*t + r[1]*off))
    pts[n] = (b[0], b[2])
    return sum(math.hypot(pts[i+1][0]-pts[i][0], pts[i+1][1]-pts[i][1]) for i in range(n))
runs = {
  "ch04 skate":   (((-140, .2, 90), (140, .2, 90), 15, 22.0), 12.0, max(9*34.0, 40+4*70.0)),
  "ch08 vehicle": (((120, .2, 110), (-36, .2, -4), 13, 16.0), 12.5, max(5*36.0, 150.0)),
  "ch08 dragon":  (((0, .2, 10), (-80, .2, 230), 14, 20.0), 15.0, 8*30.0),
}
for name, (args, speed, max_s) in runs.items():
    L = snake_len(*args)
    ok = max_s < L - 6
    print("%-13s length %.0f m, ~%.0f s at base speed, last obstacle at %.0f m -> %s" % (name, L, L/speed, max_s, "ok" if ok else "OBSTACLE BEYOND END"))
    if not ok: bad += 1
print("layout problems:", bad)
sys.exit(1 if bad else 0)
