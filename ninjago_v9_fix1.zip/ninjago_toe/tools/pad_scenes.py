#!/usr/bin/env python3
"""Lengthens cutscene shots (+0.5 s each pass) until every scene's estimated length is >= 16 s (the checker needs 15-45).
Usage: python3 tools/pad_scenes.py scripts/cutscenes/cutscene_defs_f.gd"""
import re, sys
def est(body):
    tot = 0
    for sh in body.split("CutsceneDefs.sh(")[1:]:
        m = re.match(r"Vector3\([^)]*\), Vector3\([^)]*\), ([\d.]+)", sh); d = float(m.group(1)) if m else 0
        say = sum(max(1.8, len(a) / 15.0) for a in re.findall(r'CutsceneDefs\.Q\("\w+", "(?:\\.|[^"\\])*", "((?:\\.|[^"\\])*)"\)', sh))
        tot += max(d, say + 0.3)
    return tot
for f in sys.argv[1:]:
    t = open(f, encoding="utf-8").read()
    parts = re.split(r'(?m)^(\tout\["\w+"\] = )', t)
    out = [parts[0]]
    for k in range(1, len(parts), 2):
        body = parts[k + 1]; g = 0
        while est(body) < 16 and g < 12:
            g += 1
            body = re.sub(r'(CutsceneDefs\.sh\(Vector3\([^)]*\), Vector3\([^)]*\), )([\d.]+)', lambda m: m.group(1) + str(round(float(m.group(2)) + 0.5, 1)), body)
        out += [parts[k], body]
    open(f, "w", encoding="utf-8").write("".join(out))
