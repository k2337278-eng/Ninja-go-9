#!/usr/bin/env python3
"""Static sanity checks (NOT a substitute for running the game in Godot).
Checks: tab-only indentation, bracket balance, res:// paths exist, class_name
uniqueness, scene scripts exist."""
import os, re, sys
root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
errs = []
gd = []
for d, _, fs in os.walk(root):
    for f in fs:
        if f.endswith(".gd"):
            gd.append(os.path.join(d, f))
classes = {}
for p in gd:
    t = open(p, encoding="utf-8").read()
    m = re.search(r"^class_name (\w+)", t, re.M)
    if m:
        if m.group(1) in classes:
            errs.append("duplicate class_name " + m.group(1))
        classes[m.group(1)] = p
for p in gd:
    rel = os.path.relpath(p, root)
    t = open(p, encoding="utf-8").read()
    for i, line in enumerate(t.split("\n"), 1):
        if re.match(r"^ +\S", line):
            errs.append(f"{rel}:{i} space indentation")
    stripped = re.sub(r'"(\\.|[^"\\])*"', '""', t)
    stripped = re.sub(r"#.*", "", stripped)
    for a, b in ("()", "[]", "{}"):
        if stripped.count(a) != stripped.count(b):
            errs.append(f"{rel}: unbalanced {a}{b} ({stripped.count(a)} vs {stripped.count(b)})")
    for m in re.finditer(r'res://[\w/\.\-]+', t):
        if not os.path.exists(os.path.join(root, m.group(0)[6:])):
            errs.append(f"{rel}: missing {m.group(0)}")
for d, _, fs in os.walk(root):
    for f in fs:
        if f.endswith((".tscn", ".godot")):
            t = open(os.path.join(d, f), encoding="utf-8").read()
            for m in re.finditer(r'res://[\w/\.\-]+', t):
                if not os.path.exists(os.path.join(root, m.group(0)[6:])):
                    errs.append(f"{f}: missing {m.group(0)}")
print(f"{len(gd)} .gd files, {len(classes)} class_names")
if errs:
    print("\n".join(errs)); sys.exit(1)
print("static checks passed")
