extends SceneTree
## Run (needs Godot 4.3+):  godot --headless --path . -s tests/test_data.gd
## NOT YET EXECUTED in the authoring environment (no Godot available there).

func _init() -> void:
	var fails := 0
	for id in CharacterDB.ORDER:
		var d: Dictionary = CharacterDB.DATA[id]
		for k in ["name", "element", "suit", "hp", "speed", "light", "heavy", "poise", "ability"]:
			if not d.has(k):
				print("FAIL missing %s.%s" % [id, k])
				fails += 1
		var ab: Dictionary = d["ability"]
		for k in ["name", "kind", "damage", "cooldown", "color"]:
			if not ab.has(k):
				print("FAIL missing %s.ability.%s" % [id, k])
				fails += 1
		if ab.get("kind", "") == "projectile":
			for k in ["range", "speed", "radius"]:
				if not ab.has(k):
					print("FAIL projectile %s missing %s" % [id, k])
					fails += 1
		if ab.get("kind", "") == "aoe" and not ab.has("radius"):
			print("FAIL aoe %s missing radius" % id)
			fails += 1
	for id in CharacterDB.EXTRA:
		if not CharacterDB.DATA.has(id):
			print("FAIL missing EXTRA character %s" % id)
			fails += 1
	# story plan: 10 chapters, every beat has a valid player/party and a callable
	var firsts: Array = Chapters.first_steps()
	if firsts.size() != 10:
		print("FAIL expected 10 chapters, got %d" % firsts.size())
		fails += 1
	for d in Chapters.plan():
		if not CharacterDB.DATA.has(str(d["player"])):
			print("FAIL beat %s: unknown player" % str(d["id"]))
			fails += 1
		for pid in d["party"]:
			if not CharacterDB.DATA.has(str(pid)) or str(pid) == str(d["player"]):
				print("FAIL beat %s: bad party member %s" % [str(d["id"]), str(pid)])
				fails += 1
		if not (d["run"] as Callable).is_valid():
			print("FAIL beat %s: run callable invalid" % str(d["id"]))
			fails += 1
	for bid in ["karlof", "ash", "chamille", "clouse", "chen"]:
		var b := Boss.build(bid)
		if b.max_health <= 0.0:
			fails += 1
		b.free()
	print("character + story data checks done, failures: %d" % fails)
	quit(1 if fails > 0 else 0)
