# Story progress (v8) - read this first when resuming

## v8: what changed in each chapter (STORY_SPEC v2 review + Phase 1)
- **Ch.2:** Karlof's match now has Chen's buttons/traps (`trap_duel`); TAG tutorial toast and an optional perfect-TAG goal; Jadeblade (bag + message).
- **Ch.3:** Kai vs Ash uses the traps; Jay vs Cole is now a no-punch match (3 trap rounds, Cole safe, accept his concession); Cole's Jadeblade handover (**VERIFY**).
- **Ch.4:** Lloyd vs Chamille with traps; Jadeblade (charm + lantern).
- **Ch.5:** Jadeblade (guard's note + flower).
- **Ch.6 (rewritten):** was Lloyd alone, Skylor revealed at the end. Now: Chen lures the contestants into hunting Nya (Eyezor/Kapau/Chope as the hunters), Kai and Skylor search together,
  Chen's men seize the D.B. Express (Eyezor duel), Lloyd's energy dragon (Jay with him), the letter shows Garmadon's and Chen's past (author/content VERIFY, no invented text),
  flashback of the Anacondrai war with General Arcturus, Kai learns Skylor is Chen's daughter and they quarrel. Hooks added: kai_skylor_search, db_express_seized, arcturus_flashback.
  The old narrator-told "garmadon_past" is now the letter's past.
- **Ch.7 (rewritten):** was a Lloyd match + Kai secret + solo staff break. Now: Chen needs only Lloyd's power; Skylor (not Chen) carries the promise of the secrets of Kai's parents (content NOT invented);
  Kai's betrayal is marked VERIFY (ruse or not); Lloyd faces the Staff of Elements in element stages; Kai AND Skylor break the staff (Kai chooses the timing); the Masters take the island.
  Hooks added: chen_needs_lloyd, masters_control.
- **Ch.8 (rewritten):** was Kai captive and the dragons in the wrong order. Now: Chen finds Skylor can complete the spell, she sends an SOS, the rescue race, Zane + P.I.X.A.L. (inner conflict, Titanium Dragon) FIRST,
  Kapau starts the spell and Chope completes it, followers become Anacondrai, Kai's fire dragon is THIRD (after Lloyd's and Zane's), the Masters flee on their dragons. The "captive" hook/scene was removed.
  Hooks added: chen_discovers, skylor_sos, rescue_convoy, dragons_escape.
- **Ch.9:** Wu meets the ninja (new scene) and joins; Warden Noble at the Kryptarium gate (new scene); escort of tiny Pythor; prison riot; Pythor is seized (new scene). `RUINS` constant restored.
- **Ch.10:** Wu's plan (new scene), rally of citizens/Serpentine/Masters, 3-gate defense, Chen in 3 phases, Garmadon playable at the ritual circle (new scene), aftermath.

# Story progress (v5) - read this first when resuming

## v5 (all 10 chapters) - what was added
- Chapters 1-5 got more content (extra waves, hold-outs, lever/plate/climb parts, timed runs) to reach a >=10 min estimate.
- Chapters 6-10 rewritten to the same level (4-6 goals, 3+ mid events, 2+ puzzle/climb/stealth parts, 2+ optional notes, more beats = more save points).
- 24 new scenes (ch. 6-10, `cutscene_defs_d.gd` / `_e.gd`): 48 scenes total = every hook. The two ch. 10 mid-fight hooks (`ch10_allies`, `ch10_pythor_idea`) now
  play as blocking cutscenes with the enemies frozen (`ChapterBase.freeze_foes`).
- Audio: settings sliders for voice / music / effects (`scripts/ui/audio_settings.gd`, in the main-menu settings and the pause menu, saved in GameState.settings);
  generated effects (whoosh, thud, impact, elem, ui_open, ui_back, rumble) wired to cutscene shots and to heavy hits / deaths.
- Checks: `tests/story_check.py` now covers all 10 chapters (scenes, goals, events, puzzles, side notes, 10-minute estimate, voice map) and writes
  `docs/CHAPTER_CHECKLIST.md` + `docs/CUTSCENES.md`. `docs/VOICE_LINES.csv` has 278 lines.
- Playtime numbers are a cost-model MINIMUM, never measured. Nothing has been compiled or run.

## v4 notes (still valid)

## v4 (delivery A: engine + chapters 1-5) - what was added
- Cutscene engine: `scripts/cutscenes/cutscene_player.gd` (shots: dolly/orbit/crane/handheld, FOV, easing, puppets that walk/face/animate,
  letterbox, fade/flash/shake, mood lighting, generated music themes in `Sfx.play_theme`, skip button, subtitles + voice).
- 24 real scenes for the hooks of ch. 1-5 in `cutscene_defs_a/b/c.gd` (list: `docs/CUTSCENES.md`). Ch. 6-10 hooks still placeholders (delivery B).
- On-screen objective list (`Hud.set_goals`, `ChapterBase.goals/goal_done`), plus reusable activities in `chapter_base.gd`:
  `waves`, `survive`, `plate_door`, `lever_door`, `climb_lever`, `stealth`, `checkpoints`, `note` (optional finds), `side_reward`.
- Chapters 1-5 rewritten with 3-5 goals, 2+ mid-chapter events, a puzzle/climb/stealth part, optional notes, more beats (= more save points).
- Voice: `scripts/cutscenes/voice.gd` (assets/voice/<id>.ogg|mp3|wav -> system TTS -> subtitles), `data/voice_map.json`,
  `docs/VOICE_LINES.csv` (regenerate with `python3 tools/gen_voice_csv.py`, covers all 10 chapters + the 24 scenes).
- Save version is now 3 (story progress reset for older saves; upgrades/coins kept) because beat numbering changed.

## v3 notes (still valid)

Source of truth: `docs/STORY_SPEC.md`. The old invented plan (STORY_PLAN.md, Arena Warden, Anacondrai
Warlord, Tournament Champion, power-theft-from-ninja, cage rescues) is DELETED.

## Where things are
- `scripts/world/chapters.gd`: coordinator (beat plan, runner, mission-select helpers).
- `scripts/world/chapter_base.gd`: shared helpers (dialogue, hook, duel, fight, survive, checkpoints, stealth, dragon_strike).
- `scripts/world/chapters/ch01.gd ... ch10.gd`: one file per episode (35-44). Each has its own header with Hooks + VERIFY.
- `scripts/cutscenes/cutscenes.gd`: registry for REAL cinematics (empty). Hooks: `docs/CUTSCENE_HOOKS.md` (generated).
- Saves: version 2. `story_step` = beat index (old v1 saves have their story progress reset on load).

## Status per chapter (all WRITTEN, none RUN; see REPORT.md). v4 beat counts: ch1=4 ch2=3 ch3=3 ch4=3 ch5=4 (ch6-10 unchanged)

1 Invitation (2 beats) | 2 Only One Can Remain (2) | 3 Versus (3) | 4 Ninja Roll (3) | 5 Spy for a Spy (3)
6 Spellbound (3) | 7 Forgotten Element (3) | 8 Day of the Dragon (4) | 9 Greatest Fear (2) | 10 Corridor of Elders (3)

## VERIFY list (updated in v6; see docs/STORY_SPEC.md and docs/V6_CHANGES.md)
- Still unconfirmed: how Kai wins unfairly in ch.2; the result of the Thunderblade race; what Chen promised about Kai's parents; the letter's content; whether Kai's betrayal in ch.7 is a ruse; which Serpentine / generals appear in ch.10 (only General Arcturus is a confirmed spirit); how the team travels to the island; Zane's exact situation during his dream.
- Resolved in v6: Chamille / Clouse names; Thunderblade = roller-skating contest; D.B. Express = Nya's mobile base; Skylor is Chen's spy (ch.5) and Kai learns she is Chen's daughter (ch.6); Cole yields to Jay (ch.3); Pythor's plan and Garmadon's sacrifice (ch.10).

## Next steps (not done)
1. Run in Godot / build the APK, fix compile errors first (nothing here was ever compiled).
2. Verify the VERIFY list against episodes, then replace placeholder hooks with real cinematics.
3. Later phases (controls, graphics, audio/voices) are untouched on purpose.
