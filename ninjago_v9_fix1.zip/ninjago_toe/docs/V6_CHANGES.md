# v6 changes (nothing here was compiled or run in Godot)

## Done
- Names fixed everywhere (code, data, voice map, docs): Shamil -> **Chamille**, Klaus -> **Clouse** (ids chamille / clouse).
- Ch.4: Thunderblade described as Chen's roller-skating contest; Lloyd's opponent is Chamille, Master of Form.
- Ch.3 beat 3 reworked: the Digiverse / P.I.X.A.L. rescue is gone (it was not in STORY_SPEC v2). Now Zane's blizzard dream (new "snow" mood in island.gd and cutscene_player.gd): follow the light, ice-gate lever, gather 4 sparks, meet the Titanium Dragon; the beacon starts to blink. Hooks renamed: ch03_pixal_found -> ch03_dragon_light, ch03_pixal_saved -> ch03_dragon_meet. Beat id ch03_zane_digiverse -> ch03_zane_blizzard. Achievement pixal_saved -> titanium_dream. Jay/Cole line: Chen picked the bracket.
- Ch.10 re-sequenced to STORY_SPEC v2: the Serpentine join (phase 2); Pythor arrives with the Book of Spells in phase 3 and explains the plan (Garmadon must banish himself to the Cursed Realm to call back the first Anacondrai generals); phase 3 goal = hold Chen back while the spell is prepared; Garmadon's sacrifice scene (spirits rise, curse the cultists, they are banished); victory scene = statue of Garmadon + Lloyd burns the Book of Spells.
- docs/STORY_SPEC.md and docs/GAMEPLAY_DESIGN.md added (the spec replaces the old one).
- tests/story_check.py: 0 errors; no subclass redefines a parent member; same 6 known false positives in deep_check.

## NOT done (still to implement, in this order)
1. Dareth, Eyezor, Kapau, Chope, Warden Noble, P.I.X.A.L. (ch.8-9) as real characters / NPCs.
2. Ch.5: show the Skylor-is-the-spy reveal (throne-room scene) and Nya's disguise as a Kabuki. Ch.6/7/8/9: re-check dialogue and scenes against STORY_SPEC v2 (e.g. Kai's apparent betrayal in ch.7 is VERIFY).
3. GAMEPLAY_DESIGN.md, phase 1 (arena hazards, ally rally + Corridor defense, Pythor escort, Staff duel, Jadeblades, tag-in moves), then phases 2 and 3.
4. Controls and camera rework, graphics upgrade, real voice files.
