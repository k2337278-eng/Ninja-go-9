# v8 changes (Phase 1). NOTHING here was compiled or run in Godot: only the static checks below were run.

Checks run on the final tree: `tests/story_check.py` 0 errors (10 chapters, 62 hooks = 62 real scenes, 351 voice lines, 24 speakers),
`tests/static_check.py` only the old known `weapon_` false positive, `tests/deep_check.py` only the 6 known false positives.
The new story_check also catches undeclared ALL_CAPS constants (v7's `ch09.gd` used `RUINS` without declaring it: fixed).

## A) Missing characters - done (written, not run)
- CharacterDB + Boss + voice_map + scenes + dialogue: **Eyezor, Kapau, Chope, Warden Noble, Wu** (plus Garmadon as a playable DB entry
  and General Arcturus as a named speaker). `tools/gen_voice_csv.py` / `docs/VOICE_LINES.csv` updated (351 lines).
- Eyezor: ch.6 leads the men who seize the D.B. Express (mini-boss duel), ch.7 guard captain at the staff chamber. **VERIFY** both (the spec only
  places him in ch.6-8 as Chen's enforcer).
- Kapau begins the spell (hook ch08_spell_begins) and Chope completes it (ch08_transformation, followers turn into Anacondrai): per STORY_SPEC.
  Both are mini-boss duels (scripted end) in the gameplay. Kapau/Chope also cameo in ch.6 with Eyezor (**VERIFY**).
- Warden Noble: ch.9 Kryptarium gate scene + dialogue. Wu: ch.9 scene (meets the ninja before the prison), joins the party, speaks in the prison.

## B) Chapters 6-8 reviewed against STORY_SPEC v2 - done (see docs/STORY_PROGRESS.md for the per-chapter list)
## C) Phase 1 gameplay (GAMEPLAY_DESIGN) - done (written, not run)
| item | where | status |
|---|---|---|
| Chen's buttons + arena traps (flame / wind / slab) | `hazard.gd`, `hazard_button.gd`, ch.2 Karlof, ch.3 Ash, ch.4 Chamille (`trap_duel`) | done. **Deviation:** the design also lists platforms; a falling slab is built instead |
| Jay vs Cole with no punches | ch.3 `_no_hit_match` (3 trap rounds, keep Cole safe, then accept his concession) | done; falling too low only repeats the round (both healed) |
| Guarding Pythor + freeing inmates | ch.9 `escort` (tiny Pythor) and `prison_riot` (inmates are a third team: they fight the cultists and you) | done |
| Staff of Elements multi-stage fight + Kai chooses WHEN to break it | ch.7 `_b2` (fire/ice/lightning stages, status per stage) and `_b3` (drain meter 45-85 percent is the best window; never a hard fail) | done |
| Rally allies + defend the Corridor | ch.10 `_b0` (3 short missions: citizens escort, Serpentine lever+stealth, Masters plate+siege) and `_b1` (3 gates, `DefensePoint`/`DefenseSlot`, 4 waves, a lost gate repeats only that wave) | done. Gate mechanic is a simple numeric stand-in |
| Playing Garmadon in his last moments | ch.10 `_b3` (player = garmadon, `ritual` circle 40 s) | done |
| Jadeblades | `GameState.award_jade`, one per chapter (hidden finds, perfect timing, friendship), rewards: skill points, weapon +1 at 4 and 8, Jade Gi at 5, achievement at 10; shown in the inventory | done |
| Tag-in cooperation moves | `Player.try_tag` + new TAG button (7 s cooldown; hit then tag = PERFECT: double damage, heal, ally power resets); tutorial toast + optional goal in ch.2 | done. **Deviation:** it is a cooperation strike with a position swap, NOT a full change of the controlled character |
Every addition shows in the goals list, has a nearby `checkpoint()`, and failing never restarts the whole chapter.
Phases 2 and 3 (stealth/chase/skating/vehicles/flight) were NOT started, as requested.

## Estimates (cost model in story_check, never measured): ch1 11.1 | ch2 10.6 | ch3 11.8 | ch4 11.2 | ch5 11.4 | ch6 15.2 | ch7 17.2 | ch8 15.9 | ch9 13.5 | ch10 19.6 minutes

## Risks / unverified (expect compile or placement problems)
- Positions of hazards, buttons, gates and the 3 defense points are on-paper coordinates (arena 17.5 m around (0,-6)); the Kryptarium stand-in is the old serpent ruins area.
- `Hazard` moves fighters in wind zones by changing `global_position`; `prison_riot` relies on `team = "prisoner"` making inmates hostile to followers and player.
- `Player.try_tag` uses `Companion._active_ability()` and swaps positions; the TAG button sits at (sx-445, s.y-425) in `touch_controls.gd` (not visually checked).
- ch.10 `_defend_wave` has an unreachable final `return` (GDScript warning).
- Voice: no recorded files; temporary TTS needs an Arabic voice on the device.
