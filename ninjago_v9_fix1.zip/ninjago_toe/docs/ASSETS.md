# 3D assets pipeline

## What exists (real files, `assets/models/`)
- `minifig.glb`: one skinned LEGO-style minifigure: 9-bone skeleton (root, hips, torso, head, arm_l, arm_r, hand_r, leg_l, leg_r),
  separate mesh nodes for the hood head, bare head, hair, hat and robe, and 15 baked skeletal clips:
  idle, walk, run, jump, light1-3, heavy, cast, enemy_atk, dodge, stagger, block, spin, climb.
  Materials are named (suit, legs, accent, hood, skin, hair, hat, robe) and recoloured at runtime per character/enemy/boss/costume.
- `weapon_*.glb` (11 weapons, attached to the `hand_r` bone), `tree_pine.glb`, `palm.glb`, `rock.glb`.
- `docs/minifig_preview.png`: contact sheet rendered from the GLB by my own CPU-skinning renderer (poses idle/walk/run/jump/
  light1/light3/heavy/cast/dodge/block/spin/climb). It proves the skinning and animation data are sane; it is not a Godot screenshot.

## How they were made
No Blender or network was available, so `tools/gen_assets.py` writes glTF 2.0 binaries directly (pure Python + numpy).
`tools/preview_glb.py` re-parses a GLB from scratch, validates accessors/skins/animation channels and renders poses.
Regenerate: `python3 tools/gen_assets.py` then `python3 tools/preview_glb.py assets/models/minifig.glb out.png`.

## Godot integration (`scripts/entities/minifig.gd`)
`Minifig.build()` first tries `_try_build_model()`: loads the GLB, recolours materials, toggles head/hair/hat/robe nodes, attaches the
weapon through a BoneAttachment3D, sets clip loop modes, and drives an AnimationPlayer from the same state machine as before.
If the file is missing or invalid it silently falls back to the old procedural primitive minifigure, so nothing breaks.
Island trees, palms and rocks use the GLB meshes when present (fallback: old primitives).

## Honest limits
- These are generated, low-poly, blocky assets (appropriate to LEGO) - not hand-modelled artist assets.
- The GLBs have NOT been imported by Godot yet. Possible import issues: node/bone naming, animation names, material names.
  If recolouring does nothing, check that imported materials keep `resource_name` equal to the glTF material name.
- Still procedural primitives: island buildings (palace, temple, cave, arena), puzzles, doors, crates, shrines.

## Sceneplane / Blender-in-the-cloud
Checked https://sceneplane.online: it exposes a remote MCP server (`https://mcp.sceneplane.online/v1`) that needs an account and
OAuth sign-in by the user. It is not in the connector directory available to me and I cannot sign in on your behalf, so it is NOT connected.
If you later add it yourself as a custom connector (Claude settings > Connectors), a future session could drive Blender to author
higher-quality models and export GLB into `assets/models/` (the Godot side already loads `minifig.glb` by name).
