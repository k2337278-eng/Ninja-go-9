# بناء APK من هاتف Android فقط (بدون كمبيوتر)

لم يُبنَ APK داخل بيئة التطوير (لا يوجد Godot هناك). الطريقة التالية تبني APK حقيقيًا على خوادم GitHub المجانية.

1. افتح github.com من متصفح الهاتف وأنشئ حسابًا مجانيًا، ثم New repository (اسم أي شيء، Public أو Private).
2. داخل المستودع: Add file > Upload files، وارفع `ninjago_toe_prototype.zip` كما هو (بدون فك الضغط)، ثم Commit changes.
3. Add file > Create new file. في خانة الاسم اكتب: `.github/workflows/build-apk.yml`
   والصق محتوى ملف `build-apk.yml` المرفق (نسخة منه داخل الـZIP في `.github/workflows/`). ثم Commit.
4. تبويب Actions > Build Android APK > Run workflow. انتظر نحو 5-15 دقيقة.
5. بعد النجاح: من صفحة المستودع افتح Releases واضغط ملف `ninjago_toe.apk` لتنزيله مباشرة.
   (بديل: من صفحة تشغيل Actions نزّل Artifact باسم ninjago-apk، وهو ZIP يحوي الـAPK.)
6. ثبّت الـAPK: اسمح بالتثبيت من هذا المصدر عند الطلب. الـAPK موقّع بمفتاح debug وهذا كافٍ للتثبيت الشخصي.

إذا فشل البناء: افتح تشغيل Actions الفاشل ونزّل Artifact باسم build-logs وأرسل لي محتوى import.log و export.log. هذا يكشف أخطاء السكربتات التي لم تُجرَّب بعد.
