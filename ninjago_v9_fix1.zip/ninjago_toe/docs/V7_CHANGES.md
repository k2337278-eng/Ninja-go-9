# v7 changes (nothing here was compiled or run in Godot)

## Done in v7
- **Camera** (scripts/entities/camera_rig.gd): vertical range widened (look down to -77 deg and UP to +26 deg), vertical sensitivity = horizontal, camera collision against ground/walls (ray from the pivot, fighters excluded), optional **lock-on** (toggle_lock: nearest living enemy within 22 m; a manual drag releases it).
- **Touch controls** (scripts/ui/touch_controls.gd): buttons rearranged into a thumb arc and enlarged, dark backing + tinted fill + clear white ring, vector icons for ATK/JMP/DGE, new **LCK** (lock-on) button, haptic tick on press (Input.vibrate_handheld; export preset now has permissions/vibrate=true).
- **Ch.5**: new hook/scene ch05_skylor_spy (throne room: Skylor reports on the alliance to Chen, per STORY_SPEC v2); Nya's disguise mentioned.
- **Ch.4**: Dareth added (CharacterDB entry, voice_map slot, lines when Nya reaches the island); hook text now says Nya disguises the D.B. Express as a noodle truck.
- **Ch.9**: reskinned from "serpent ruins" to the Kryptarium prison with a tiny (scale 0.6) Pythor; at the end Chen's followers seize Pythor (he escapes Chen in ch.10 with the Book of Spells). Gameplay structure unchanged (internal ids like ch09_ruins / isl.ruins_gate are leftovers).
- tests/story_check.py: 0 errors (10 chapters, 49 hooks, 289 voice lines, 19 speakers); no subclass redefines a parent member.

## Still NOT done (in this order)
1. GAMEPLAY_DESIGN.md phases 1-3 (arena hazards, ally rally + Corridor defense, Pythor escort, Staff duel, Jadeblades, tag-in moves; then stealth/prison break; then skating race, vehicles, dragon flight).
2. Characters still missing as real NPCs/enemies: Eyezor, Kapau, Chope, Warden Noble; Wu on screen in ch.9.
3. Ch.6/7/8 dialogue and scenes still need a full pass against STORY_SPEC v2.
4. Graphics upgrade (PBR plastic look, HDRI, fog/glow), real voice files (docs/VOICE_LINES.csv), audio/camera sensitivity sliders.
