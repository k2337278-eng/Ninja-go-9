# Build fixes (from the GitHub Actions log of v9)
The APK was produced but `island.gd` failed to load, so the game would not have started. Two root errors (both mine, from v5/v8), everything else in the log was a cascade:
1. `const D = CutsceneDefs` in `scripts/cutscenes/cutscene_defs_a..g.gd`: "Assigned value for constant D isn't a constant expression". Fixed: the alias is gone and the 725 calls now use `CutsceneDefs.` directly.
2. `scripts/world/chapters/ch03.gd:135`: `var low := ...` inferred from a Variant (`isl` is a Node3D). Fixed: `var low: bool = ...`. Also made `var r: int = await _defend_wave(...)` explicit in ch10 as a precaution.
Tools updated for the new prefix: tests/story_check.py, tools/gen_voice_csv.py, tools/pad_scenes.py.
Checks after the fix: story_check 0 errors (62 scenes, 369 voice lines), structure_check 0, layout_check 0, static_check only the old `weapon_` false positive.
NOT verified: whether more parse errors appear once these two are gone (Godot reports the first error per script and stops loading dependents). Send the next log.
