# v9 changes (nothing here was compiled or run in Godot)

## A) Clean-up / fixes
- ch10 `_defend_wave`: the unreachable trailing `return` is gone (loop is `while ok_alive()`, then `return -1`).
- Enemies vs the "prisoner" team: verified by reading the code, not by playing. `Fighter.nearest_foe()` picks the nearest fighter whose `team` differs from its own, so "enemy" and "prisoner" fighters target each other as well as the player's team.
- Buttons: computed the geometry of all 10 buttons (viewport 720 high): no overlaps (>= 8 px gap) incl. TAG; BLK was 4 px from the bottom edge -> moved up, PWR nudged to keep its gap.
- **Tag-in is now a real swap** (was: strike + swap places): for 18 s the player takes the ally's look, stats and ability and the ally takes the player's (`Fighter.swap_identity_with`; health keeps its ratio; skill tree re-applied; swaps back automatically via `Player._tag_end`, with a rebuild fallback if the ally vanished). No second tag while swapped.
- Kryptarium (ch9) is still on the old ruins spot, but is now dressed as a prison (dark yard slab + two rows of cell bars, no collision): `ChapterBase.dress_prison()/undress_prison()`.
- New tools: `tools/layout_check.py` (coordinates on the island plane, rail path lengths vs obstacle distances) and `tools/structure_check.py` (brackets, indentation, duplicate funcs/vars/members, missing helper calls, members the new code relies on). Both pass. They cannot see props/buildings or types.

## B) Phase 2 (simple new mechanics)
- ch4 noodle-factory escape: two conveyor belts (`Conveyor`) push you while patrols sweep; collect 3 keys (stealth mode) before the lever.
- ch5: Nya crosses the yard in a Kabuki-style disguise (`disguise_run`: a watch zone drains a 5 s disguise meter instead of ending the stage); new beat `ch05_spy_hunt` (3 clues, then accuse one of three suspects, wrong picks only retry; `deduce`). The characters keep their suspicion to themselves (Kai only learns in ch6).
- ch6: new beats `ch06_nya_chase` (play Nya, lose Chen's hunters across 3 hideouts) and `ch06_flashback` (short playable Anacondrai-war memory with General Arcturus at your side).
- ch8: inner trials: Zane stands in a ritual circle in a whiteout (snow mood) while doubts press in; Kai masters his anger among flames. (Lloyd's dragon is unlocked in ch6, so he has no trial here.)

## C) Phase 3 (big mechanics, one new rail mode: `RailRun`)
- ch4 Thunderblade: roller-skate race vs Chamille (stick steers, JMP jumps barriers, DGE boosts; boost pads; she drops barriers in your lane; if she wins or you crash you restart from a quarter-checkpoint). Result VERIFY.
- ch8 rescue run: vehicle mode (3 armor, no pit stops). One shared vehicle, not one per ninja.
- ch8 dragon escape: flight mode (stick steers and climbs, ATK = fire breath clears rocks ahead, DGE boosts).
- Each run lasts about 20-30 s of base-speed driving (see `tools/layout_check.py`), plus retries: shorter than the 3-6 min of the design table.

## NOT done / known gaps
- Chamille does not change shape (only the barrier tricks); no per-ninja vehicles; no Lloyd trial; the Kabuki disguise is used only in the yard.
- Positions of belts, patrols, clue notes, hideouts and the rail paths are chosen on paper (flat 700x700 ground); only a real playtest can show clashes with buildings/props.
- Still open from earlier: graphics upgrade (PBR plastic look, HDRI, fog/glow), real voice files, audio and camera-sensitivity sliders, more weight for the GAMEPLAY_DESIGN set-pieces that remain lighter than designed (rally, defense).
