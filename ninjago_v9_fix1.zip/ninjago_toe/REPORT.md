# Status report - v5 (all chapters, 48 scenes, audio settings). See docs/CHAPTER_CHECKLIST.md. Nothing compiled or run; minutes are estimates.

# (v4 report below)
# Status report - v4 (delivery A: cutscene engine + chapters 1-5 + voice)
See docs/STORY_PROGRESS.md. Nothing in v4 has been compiled or run (no Godot here); playtime per chapter is an ESTIMATE from the amount of content, not measured.

# (v3 report below)

## Verification status (read first)
- NOTHING in v3 has been run or compiled. No Godot, no APK build in the authoring environment.
- Run and passing: `tests/static_check.py` (only the old known false positive about `weapon_`), `tests/story_check.py`
  (0 errors: chapter files, speaker ids, boss/enemy ids, isl/hud methods, no subclass var redeclared, no leftover invented bosses),
  `tests/deep_check.py` (6 errors = the same 6 known false positives as v2; none new).
- Written but NOT executed: `tests/test_data.gd`. Expect compile errors on first open in Godot.
- See `docs/STORY_PROGRESS.md` for per-chapter status and the VERIFY list.

---
# (older reports below)
# Status report - third development pass

## Verification status (read first)
- The game has NEVER been run. No Godot, no APK build, no device test exists in the authoring environment.
- The only checks run are STATIC, written by me, and they are not a compiler:
  `tests/static_check.py` (tabs, brackets, res:// paths, unique class_names) -> passes;
  `tests/deep_check.py` (indentation structure, cross-class method existence, autoload members,
  `%` format counts, connect targets) -> reports 6 known FALSE POSITIVES (multi-line bracket
  continuations and Callable parameter names); no real errors found by it.
  Extra cross-checks passed: all Loc.t keys exist, all GameState members used exist, all `.emit()`
  signals are declared, all scene paths exist.
- One real bug found by manual review and fixed: main-menu settings lambdas captured a null local.
- `tests/test_data.gd` (Godot headless) is written, not executed.
- Backup of the project before this pass: `ninjago_backup_before_phase3.tgz`.

## Added this pass (written, not run)
Map screen (terrain, landmarks, discovered zone names, player/companions/objective) and Inventory screen
(party status, resources, powers, relic checklist, re-readable scrolls, chapter ratings), both opened from the
pause menu; procedural weapons for ninja, Skylor, enemies and bosses (follow arm swings); pillar flame
particles (Medium/High); projectile glow light; safe-area (notch) insets for touch controls; 60 fps cap.

## Not done (cannot be done here)
Real 3D models/skeletal animations (no Blender/assets/internet; visuals stay procedural primitives),
APK build, any real playtest, performance measurement, verification of story against the show.
Cinematics remain camera + dialogue scenes. Key/locked-door content is supported but unused.

## Known risks
First open in Godot will likely show script errors (never compiled); GL Compatibility limits (few lights);
climb/crate-push tuning untested; Arabic text relies on Android system fallback font.

---
## Fourth pass: real 3D assets (written + self-validated, NOT imported by Godot yet)
- Generated 15 real GLB files (rigged/animated minifig, 11 weapons, pine, palm, rock) with `tools/gen_assets.py`.
- Validated by an independent parser (`tools/preview_glb.py`: accessor bounds/min-max, joint indices, weights, unit quaternions,
  increasing animation times) and visually checked in `docs/minifig_preview.png`.
- Godot code integrated: skeletal model mode + weapons + freeze on death (minifig.gd, fighter.gd), GLB trees/palms/rocks (island.gd),
  export preset excludes tools/docs/tests.
- No tests, no APK build were run in this pass (by instruction). Sceneplane could not be connected (see docs/ASSETS.md).
